# TORIWEAR — Engineering Review & Launch Gate (9 November 2026)

## Review outcome

**NOT READY FOR A public production launch.** This archive is a source-code package, not a deployed or production-verified store. The changes in this archive are fail-closed safeguards; they do not complete third-party integrations or establish a production environment.

## Changes made in this review

1. Removed the bundled `.env` file from the distributable archive. It contained populated values for database credentials, session/2FA secrets, payment credentials and a shipping webhook token. Treat every credential in that file as exposed and rotate/revoke it before deployment.
2. Removed the bundled `backups/` data export from the distributable archive to avoid shipping potentially sensitive operational/customer data.
3. Payment service: production payment-intent creation now fails closed because the current implementation does not create a real Razorpay order using Razorpay's API. Production simulated payment verification is rejected. Production payment webhooks fail closed if their signing secret is absent.
4. Shipping service: production shipment creation now fails closed because the current implementation generates synthetic tracking/AWB identifiers rather than creating a shipment with a live carrier/Shiprocket API.
5. Google Cloud Storage adapter: removed false-success behavior. It now reports that GCS upload is not implemented instead of returning a fabricated successful upload URL.
6. Production `/ready` endpoint: it now returns HTTP 503 when only the in-memory database fallback is available, rather than reporting the service as ready.

## Critical remaining launch blockers

### Security and identity
- `server/authStore.ts` contains hardcoded default passwords for partner/staff accounts and seeds in-memory credentials. Replace this with one-time invitation/reset flows and persistent password hashes; invalidate all default credentials.
- `server/middleware/authMiddleware.ts` accepts a legacy in-memory session after persistent session validation fails. Remove this fallback for production; database errors must fail closed, not authenticate from process memory.
- `server/repositories/userRepository.ts` contains fallback users with a fixed hash/salt and uses in-memory fallbacks when database operations fail. Remove production fallback authentication and ensure authorization is sourced from persistent records.
- Review and protect every administrative/brand-management route, including the brand logo upload route, with server-side authentication, authorization, CSRF/rate-limit controls as appropriate.
- Verify 2FA enrollment, encrypted secret persistence, replay protection, recovery-code one-time use, password reset and session revocation using real persistent storage.
- Rotate all secrets from the removed `.env`; do not reuse them.

### Database and hosting
- The project includes a Prisma schema and a single initial migration, but the runtime startup script `server/db/start-postgres.ts` uses an embedded PostgreSQL cluster, hardcoded local DB credentials and `prisma db push` on an empty database. This is not a production database architecture.
- Configure managed PostgreSQL, apply reviewed Prisma migrations through a deployment/release step, and verify backups and restore.
- Confirm all repositories use the production database and do not silently fall back to in-memory stores.
- Deploy to the chosen host, configure domain + HTTPS, production environment variables, Firebase authorized domains and health monitoring. The ZIP does not prove any of these are configured.

### Payments, shipping and media
- Implement real Razorpay order creation, signature verification, webhook signature validation, idempotency, refunds and reconciliation. Run live low-value end-to-end tests before enabling checkout.
- Implement and test Shiprocket/carrier API authentication, shipment creation, labels, tracking webhooks, cancellations and RTO flows. Current synthetic AWB generation is not a live integration.
- Implement a real persistent media adapter (e.g. Google Cloud Storage using its SDK and service identity). The current GCS adapter was returning success without uploading bytes; this review changed it to fail closed.
- Confirm COD, prepaid, stock reservation/release, duplicate webhook and overselling behavior against the real database.

### Storefront and legal/customer operations
- Test product publishing, variants/sizes, inventory, cart, wishlist, customer Google login, checkout, order confirmation and order history on the deployed domain.
- Verify shipping fees, delivery estimates, returns/refunds, privacy policy, terms, contact details and customer support channels.
- Confirm product artwork, fonts, photographs and other assets are owned or licensed for commercial use.

## Verification limitations

- This review was based on static inspection of the supplied ZIP.
- The archive does not include `node_modules`; a dependency install, TypeScript check, production build, automated test suite, database migration test and browser/device QA have **not** been run in this review.
- No production deployment, payment gateway, Shiprocket account, managed database, cloud storage bucket or domain configuration was accessible for live verification.
- Therefore no claim is made that all tests pass or that the app is launch-ready.

## Recommended next release gate

Do not enable public orders or accept live payments until every Critical blocker above is resolved and verified in a staging environment that mirrors production. Keep the storefront in a controlled coming-soon/maintenance state until then.
