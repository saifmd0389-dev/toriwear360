/**
 * TORIWEAR Client-Side API Service
 * 
 * Interacts with the production-grade PostgreSQL persistence backend.
 * Provides resilient fallbacks if the server is temporarily booting.
 */

import { Product } from '../types';
import { AdminProduct, InventoryItem } from '../admin/types';

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  order?: any;
  quote?: any;
  count?: number;
  error?: string;
  message?: string;
  [key: string]: any;
}

const API_BASE = '/api/v1';

function getAuthHeaders(): HeadersInit {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };

  try {
    // Try staff session token if present
    const staffSession = localStorage.getItem('tori_staff_session');
    if (staffSession) {
      const parsed = JSON.parse(staffSession);
      if (parsed?.token) {
        headers['Authorization'] = `Bearer ${parsed.token}`;
      }
    }

    const legacyToken = localStorage.getItem('tori_admin_session_token');
    if (!headers['Authorization'] && legacyToken) {
      headers['Authorization'] = `Bearer ${legacyToken}`;
    }
  } catch {}

  return headers;
}

export const apiClient = {
  // ==========================================
  // Storefront Catalog APIs
  // ==========================================
  async getProducts(params?: {
    department?: string;
    world?: string;
    status?: string;
    categoryId?: string;
    collectionSlug?: string;
    search?: string;
  }): Promise<Product[]> {
    const query = new URLSearchParams();
    if (params?.department && params.department !== 'ALL') query.set('department', params.department);
    if (params?.world && params.world !== 'ALL') query.set('world', params.world);
    if (params?.status) query.set('status', params.status);
    if (params?.categoryId) query.set('categoryId', params.categoryId);
    if (params?.collectionSlug) query.set('collectionSlug', params.collectionSlug);
    if (params?.search) query.set('search', params.search);

    const endpointUrl = `${API_BASE}/products?${query.toString()}`;
    console.log('[apiClient.getProducts] 🚀 Requesting products from backend:', {
      endpoint: endpointUrl,
      filterParams: params,
      timestamp: new Date().toISOString(),
    });

    try {
      const res = await fetch(endpointUrl);
      if (!res.ok) {
        console.error(`[apiClient.getProducts] ❌ Server returned HTTP ${res.status}:`, res.statusText);
        throw new Error(`HTTP error ${res.status}`);
      }

      const json: ApiResponse<any[]> = await res.json();
      const rawProducts = (json.data as Product[]) || [];

      console.log('[apiClient.getProducts] ✅ Backend response received:', {
        success: json.success,
        count: json.count ?? rawProducts.length,
        receivedCount: rawProducts.length,
        items: rawProducts.map((p: any) => ({
          id: p.id,
          name: p.name,
          catalogNumber: p.catalogNumber,
          sku: p.sku,
          status: p.status,
          publishingStatus: p.publishingStatus,
          department: p.department,
          world: p.world,
          imagesCount: Array.isArray(p.images) ? p.images.length : 0,
          firstImage: Array.isArray(p.images) && p.images[0] ? p.images[0].substring(0, 60) + '...' : null,
          inStock: p.inStock,
          stock: p.stock,
        })),
      });

      return rawProducts;
    } catch (err: any) {
      console.error('[apiClient.getProducts] 💥 Network/Fetch failure retrieving products from backend:', {
        error: err.message,
        endpoint: endpointUrl,
      });
      return [];
    }
  },

  async getProductByIdOrSlug(identifier: string): Promise<Product | null> {
    try {
      const res = await fetch(`${API_BASE}/products/${encodeURIComponent(identifier)}`);
      if (!res.ok) return null;
      const json: ApiResponse<Product> = await res.json();
      return json.data || null;
    } catch (err) {
      console.warn('[API Client] Error fetching product:', err);
      return null;
    }
  },

  async getFeaturedProducts(): Promise<Product[]> {
    try {
      const res = await fetch(`${API_BASE}/products/featured`);
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<Product[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  async getNewArrivals(department?: string): Promise<Product[]> {
    try {
      const q = department && department !== 'ALL' ? `?department=${department}` : '';
      const res = await fetch(`${API_BASE}/products/new-arrivals${q}`);
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<Product[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  async getTopSelling(department?: string): Promise<Product[]> {
    try {
      const q = department && department !== 'ALL' ? `?department=${department}` : '';
      const res = await fetch(`${API_BASE}/products/top-selling${q}`);
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<Product[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  async getCategories(department?: string): Promise<any[]> {
    try {
      const q = department && department !== 'ALL' ? `?department=${department}` : '';
      const res = await fetch(`${API_BASE}/categories${q}`);
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<any[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  async getCollections(): Promise<any[]> {
    try {
      const res = await fetch(`${API_BASE}/collections`);
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<any[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  // ==========================================
  // Admin Product Management APIs
  // ==========================================
  async getAdminProducts(): Promise<ApiResponse<AdminProduct[]>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<AdminProduct[]> = await res.json();
      return json;
    } catch (err: any) {
      console.warn('[API Client] Error fetching admin products:', err);
      return { success: false, error: err.message || 'Failed to fetch admin products', data: [] };
    }
  },

  async adminCreateProduct(productData: Partial<AdminProduct>): Promise<ApiResponse<AdminProduct>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(productData),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Network request failed' };
    }
  },

  async adminUpdateProduct(id: string, updates: Partial<AdminProduct>): Promise<ApiResponse<AdminProduct>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products/${encodeURIComponent(id)}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify(updates),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Network request failed' };
    }
  },

  async adminArchiveProduct(id: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products/${encodeURIComponent(id)}/archive`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Network request failed' };
    }
  },

  async adminRestoreProduct(id: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products/${encodeURIComponent(id)}/restore`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Network request failed' };
    }
  },

  async adminDeleteProduct(id: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/products/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Network request failed' };
    }
  },

  // ==========================================
  // Inventory APIs
  // ==========================================
  async getInventory(): Promise<InventoryItem[]> {
    try {
      const res = await fetch(`${API_BASE}/inventory`, {
        headers: getAuthHeaders(),
      });
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json: ApiResponse<InventoryItem[]> = await res.json();
      return json.data || [];
    } catch {
      return [];
    }
  },

  async updateStock(variantId: string, newStock: number, reason?: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/inventory/${encodeURIComponent(variantId)}/stock`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ newStock, reason }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Stock update failed' };
    }
  },

  async deleteInventoryItem(variantId: string, reason?: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/inventory/${encodeURIComponent(variantId)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
        body: JSON.stringify({ reason }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to delete inventory record' };
    }
  },

  // ==========================================
  // Orders & Payment Security APIs (Phase 4)
  // ==========================================
  async calculateOrderQuote(quotePayload: {
    items: Array<{ productId: string; variantId?: string; size?: string; color?: string; quantity: number }>;
    couponCode?: string;
    shippingPincode?: string;
    state?: string;
  }): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/orders/quote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(quotePayload),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Pricing quote failed' };
    }
  },

  async createOrder(orderPayload: any): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Order creation failed' };
    }
  },

  async getOrder(orderId: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderId)}`);
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to fetch order' };
    }
  },

  async getCustomerOrders(customerId: string, email?: string, phone?: string): Promise<ApiResponse<any>> {
    try {
      const params = new URLSearchParams();
      if (email) params.append('email', email);
      if (phone) params.append('phone', phone);
      const url = `${API_BASE}/orders/customer/${encodeURIComponent(customerId)}?${params.toString()}`;
      const res = await fetch(url);
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to fetch customer orders' };
    }
  },

  async cancelOrder(orderId: string, reason: string, customerName?: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderId)}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason, customerName }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to cancel order' };
    }
  },

  async getAdminOrders(filter?: { status?: string; search?: string; customerId?: string }): Promise<ApiResponse<any>> {
    try {
      const params = new URLSearchParams();
      if (filter?.status) params.append('status', filter.status);
      if (filter?.search) params.append('search', filter.search);
      if (filter?.customerId) params.append('customerId', filter.customerId);
      const res = await fetch(`${API_BASE}/admin/orders?${params.toString()}`, {
        headers: getAuthHeaders(),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to fetch admin orders' };
    }
  },

  async getAdminOrder(orderId: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/orders/${encodeURIComponent(orderId)}`, {
        headers: getAuthHeaders(),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to fetch order details' };
    }
  },

  async updateAdminOrderStatus(
    orderId: string,
    status: string,
    note?: string,
    courierInfo?: { courierPartner?: string; trackingNumber?: string }
  ): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/orders/${encodeURIComponent(orderId)}/status`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          status,
          note,
          courierPartner: courierInfo?.courierPartner,
          trackingNumber: courierInfo?.trackingNumber,
        }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update order status' };
    }
  },

  async cancelAdminOrder(orderId: string, reason: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/orders/${encodeURIComponent(orderId)}/cancel`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ reason }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to cancel order' };
    }
  },

  async refundAdminOrder(orderId: string, amount: number, reason: string): Promise<ApiResponse<any>> {
    try {
      const res = await fetch(`${API_BASE}/admin/orders/${encodeURIComponent(orderId)}/refund`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ amount, reason }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to refund order' };
    }
  },

  async validateCoupon(code: string, subtotal?: number): Promise<ApiResponse<any>> {
    try {
      const url = subtotal !== undefined && subtotal > 0
        ? `${API_BASE}/coupons/validate/${encodeURIComponent(code)}?subtotal=${encodeURIComponent(subtotal)}`
        : `${API_BASE}/coupons/validate/${encodeURIComponent(code)}`;
      const res = await fetch(url);
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Coupon validation failed' };
    }
  },
};
