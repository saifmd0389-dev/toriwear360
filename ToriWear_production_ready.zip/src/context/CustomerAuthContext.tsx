import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  CustomerProfile, 
  CustomerProductView, 
  CustomerCartItemPreview, 
  CustomerWishlistItemPreview,
  CustomerSavedCard,
  CustomerSavedAddress 
} from '../admin/types';
import { Product, CartItem } from '../types';
import { INITIAL_CUSTOMERS } from '../admin/data/mockData';
import { auth, googleProvider, authPersistenceReady } from '../firebase/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

export type CustomerAccountModalType = 
  | 'GIFT_CARDS' 
  | 'TORI_INSIDER' 
  | 'TORI_CREDIT' 
  | 'COUPONS' 
  | 'SAVED_CARDS' 
  | 'SAVED_VPA' 
  | 'SAVED_ADDRESSES' 
  | 'EDIT_PROFILE' 
  | 'ORDER_HISTORY'
  | null;

interface CustomerAuthContextType {
  customer: CustomerProfile | null;
  isLoggedIn: boolean;
  isAuthModalOpen: boolean;
  authModalTab: 'PHONE' | 'EMAIL' | 'PASSWORD';
  activeAccountModal: CustomerAccountModalType;
  openAuthModal: (tab?: 'PHONE' | 'EMAIL' | 'PASSWORD') => void;
  closeAuthModal: () => void;
  openAccountModal: (modal: CustomerAccountModalType) => void;
  closeAccountModal: () => void;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  loginWithPhoneOtp: (phone: string, otp: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithEmailOtp: (email: string, otp: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithPassword: (identifier: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signupWithPassword: (name: string, email: string, phone: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<CustomerProfile>) => void;
  recordSearch: (query: string) => void;
  recordProductView: (product: Product) => void;
  syncCartWithCustomer: (cartItems: CartItem[]) => void;
  syncWishlistWithCustomer: (wishlistIds: string[], allProducts: Product[]) => void;
  addSavedAddress: (address: Omit<CustomerSavedAddress, 'id'>) => void;
  deleteSavedAddress: (addressId: string) => void;
  addSavedVpa: (vpa: string) => void;
  deleteSavedVpa: (vpa: string) => void;
  addSavedCard: (card: Omit<CustomerSavedCard, 'id'>) => void;
  deleteSavedCard: (cardId: string) => void;
}

const CustomerAuthContext = createContext<CustomerAuthContextType | undefined>(undefined);

const CURRENT_CUSTOMER_KEY = 'toriwear_current_customer';
const ADMIN_CUSTOMERS_KEY = 'tori_admin_customers';

export const CustomerAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load current customer session from localStorage
  const [customer, setCustomer] = useState<CustomerProfile | null>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const saved = localStorage.getItem(CURRENT_CUSTOMER_KEY);
        if (saved) return JSON.parse(saved);
      }
    } catch (e) {
      console.error(e);
    }
    return null;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'PHONE' | 'EMAIL' | 'PASSWORD'>('PHONE');
  const [activeAccountModal, setActiveAccountModal] = useState<CustomerAccountModalType>(null);

  // Sync customer state to localStorage and admin customers directory
  const saveCustomerToStorage = (updatedCustomer: CustomerProfile | null) => {
    try {
      if (typeof window === 'undefined' || !window.localStorage) return;
      if (updatedCustomer) {
        localStorage.setItem(CURRENT_CUSTOMER_KEY, JSON.stringify(updatedCustomer));
        
        // Update customer in Admin Directory (tori_admin_customers)
        const adminRaw = localStorage.getItem(ADMIN_CUSTOMERS_KEY);
        let adminList: CustomerProfile[] = adminRaw ? JSON.parse(adminRaw) : INITIAL_CUSTOMERS;
        
        const existingIdx = adminList.findIndex(
          (c) => c.id === updatedCustomer.id || 
                 c.email.toLowerCase() === updatedCustomer.email.toLowerCase() || 
                 c.phone === updatedCustomer.phone
        );

        if (existingIdx > -1) {
          adminList[existingIdx] = { ...adminList[existingIdx], ...updatedCustomer };
        } else {
          adminList = [updatedCustomer, ...adminList];
        }

        localStorage.setItem(ADMIN_CUSTOMERS_KEY, JSON.stringify(adminList));
        window.dispatchEvent(new CustomEvent('tori_customer_updated', { detail: updatedCustomer }));
      } else {
        localStorage.removeItem(CURRENT_CUSTOMER_KEY);
      }
    } catch (e) {
      console.error('Error saving customer to storage:', e);
    }
  };

  const openAuthModal = (tab: 'PHONE' | 'EMAIL' | 'PASSWORD' = 'PHONE') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openAccountModal = (modal: CustomerAccountModalType) => {
    setActiveAccountModal(modal);
  };

  const closeAccountModal = () => {
    setActiveAccountModal(null);
  };

  // Firebase Authentication State Listener: Keeps user authenticated across browser sessions & future visits
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser: FirebaseUser | null) => {
      if (firebaseUser) {
        // Customer is authenticated with Google via Firebase
        const adminRaw = localStorage.getItem(ADMIN_CUSTOMERS_KEY);
        const adminList: CustomerProfile[] = adminRaw ? JSON.parse(adminRaw) : INITIAL_CUSTOMERS;
        
        const existing = adminList.find(
          c => c.email.toLowerCase() === (firebaseUser.email || '').toLowerCase() || c.id === firebaseUser.uid
        );

        const todayStr = new Date().toISOString().split('T')[0];
        const updatedCustomer: CustomerProfile = existing ? {
          ...existing,
          name: firebaseUser.displayName || existing.name,
          email: firebaseUser.email || existing.email,
          avatar: firebaseUser.photoURL || existing.avatar,
          status: 'ACTIVE',
        } : {
          id: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Toriwear Customer',
          email: firebaseUser.email || '',
          phone: firebaseUser.phoneNumber || '',
          avatar: firebaseUser.photoURL || undefined,
          city: 'Mumbai',
          state: 'Maharashtra',
          pincode: '400001',
          country: 'India',
          totalOrders: 0,
          totalSpent: 0,
          averageOrderValue: 0,
          lastOrderDate: todayStr,
          createdAt: todayStr,
          status: 'ACTIVE',
          segment: 'New Customers',
          tags: ['Google Authenticated', 'Firebase Auth', 'Storefront Member'],
          notes: ['Authenticated via Google Firebase Authentication.'],
          searchHistory: [],
          productViews: [],
          cartItems: [],
          wishlistItems: [],
          toriCredit: 250,
          insiderTier: 'Bronze',
          insiderPoints: 100,
          savedVpa: [],
          savedCards: [],
          savedAddresses: [],
        };

        setCustomer(updatedCustomer);
        saveCustomerToStorage(updatedCustomer);
      } else {
        // Customer is signed out in Firebase
        // Only clear if was logged in with Firebase and no local customer session exists
        const storedCustomerRaw = localStorage.getItem(CURRENT_CUSTOMER_KEY);
        if (!storedCustomerRaw && auth.currentUser === null) {
          setCustomer(null);
          saveCustomerToStorage(null);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Primary Customer Authentication: Google Sign-In via Firebase
  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      await authPersistenceReady;
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        closeAuthModal();
        return { success: true };
      }
      return { success: false, error: 'Sign in was cancelled.' };
    } catch (error: any) {
      console.warn('Firebase Google Sign-In Notice:', error);
      let message = error?.message || 'Failed to sign in with Google';
      if (error?.code === 'auth/popup-closed-by-user') {
        message = 'Sign in window was closed before completing.';
      } else if (error?.code === 'auth/popup-blocked') {
        message = 'Sign in popup was blocked by browser. Please allow popups for this site.';
      } else if (error?.code === 'auth/invalid-api-key') {
        message = 'Firebase configuration is incomplete. Please ensure Firebase Web App API key is configured.';
      }
      return { success: false, error: message };
    }
  };

  // 1. Login with Phone OTP
  const loginWithPhoneOtp = async (phone: string, otp: string, name?: string) => {
    const cleanPhone = phone.trim().replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      return { success: false, error: 'Please enter a valid 10-digit mobile number' };
    }
    if (!otp || otp.length < 4) {
      return { success: false, error: 'Please enter a valid OTP verification code' };
    }

    // Check if customer already exists in Admin directory
    const adminRaw = localStorage.getItem(ADMIN_CUSTOMERS_KEY);
    const adminList: CustomerProfile[] = adminRaw ? JSON.parse(adminRaw) : INITIAL_CUSTOMERS;
    const existing = adminList.find(c => c.phone.replace(/\D/g, '').includes(cleanPhone));

    const todayStr = new Date().toISOString().split('T')[0];
    const newOrUpdatedCustomer: CustomerProfile = existing ? {
      ...existing,
      lastOrderDate: existing.lastOrderDate || todayStr,
      status: 'ACTIVE',
    } : {
      id: `cust-${Date.now().toString().slice(-6)}`,
      name: name?.trim() || `Customer ${cleanPhone.slice(-4)}`,
      email: `${cleanPhone}@toriwear.in`,
      phone: `+91 ${cleanPhone}`,
      city: 'Visakhapatnam',
      state: 'Andhra Pradesh',
      pincode: '530018',
      country: 'India',
      totalOrders: 0,
      totalSpent: 0,
      averageOrderValue: 0,
      lastOrderDate: todayStr,
      createdAt: todayStr,
      status: 'ACTIVE',
      segment: 'New Customers',
      tags: ['Website Registered', 'Phone OTP Verified', 'New Drop Squad'],
      notes: ['Signed in via mobile SMS OTP.'],
      searchHistory: [],
      productViews: [],
      cartItems: [],
      wishlistItems: [],
      toriCredit: 250, // Welcome credit
      insiderTier: 'Bronze',
      insiderPoints: 100,
      savedVpa: [`${cleanPhone}@okhdfcbank`],
      savedCards: [],
      savedAddresses: [
        {
          id: 'addr-default',
          name: 'Home',
          addressLine: 'Door No. 4-12, Beach Road',
          city: 'Visakhapatnam',
          state: 'Andhra Pradesh',
          pincode: '530018',
          isDefault: true,
        }
      ],
    };

    setCustomer(newOrUpdatedCustomer);
    saveCustomerToStorage(newOrUpdatedCustomer);
    closeAuthModal();
    return { success: true };
  };

  // 2. Login with Email OTP
  const loginWithEmailOtp = async (email: string, otp: string, name?: string) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@')) {
      return { success: false, error: 'Please enter a valid email address' };
    }
    if (!otp || otp.length < 4) {
      return { success: false, error: 'Please enter a valid OTP verification code' };
    }

    const adminRaw = localStorage.getItem(ADMIN_CUSTOMERS_KEY);
    const adminList: CustomerProfile[] = adminRaw ? JSON.parse(adminRaw) : INITIAL_CUSTOMERS;
    const existing = adminList.find(c => c.email.toLowerCase() === cleanEmail);

    const todayStr = new Date().toISOString().split('T')[0];
    const newOrUpdatedCustomer: CustomerProfile = existing ? {
      ...existing,
      status: 'ACTIVE',
    } : {
      id: `cust-${Date.now().toString().slice(-6)}`,
      name: name?.trim() || cleanEmail.split('@')[0],
      email: cleanEmail,
      phone: '+91 98765 43210',
      city: 'Visakhapatnam',
      state: 'Andhra Pradesh',
      pincode: '530018',
      country: 'India',
      totalOrders: 0,
      totalSpent: 0,
      averageOrderValue: 0,
      lastOrderDate: todayStr,
      createdAt: todayStr,
      status: 'ACTIVE',
      segment: 'New Customers',
      tags: ['Website Registered', 'Email OTP Verified'],
      notes: ['Signed in via email verification code.'],
      searchHistory: [],
      productViews: [],
      cartItems: [],
      wishlistItems: [],
      toriCredit: 250,
      insiderTier: 'Bronze',
      insiderPoints: 100,
      savedVpa: [],
      savedCards: [],
      savedAddresses: [],
    };

    setCustomer(newOrUpdatedCustomer);
    saveCustomerToStorage(newOrUpdatedCustomer);
    closeAuthModal();
    return { success: true };
  };

  // 3. Login with User ID / Email & Password
  const loginWithPassword = async (identifier: string, pass: string) => {
    const cleanId = identifier.trim().toLowerCase();
    if (!cleanId) return { success: false, error: 'Please enter your Email or User ID' };
    if (!pass || pass.length < 4) return { success: false, error: 'Password must be at least 4 characters' };

    const adminRaw = localStorage.getItem(ADMIN_CUSTOMERS_KEY);
    const adminList: CustomerProfile[] = adminRaw ? JSON.parse(adminRaw) : INITIAL_CUSTOMERS;
    const found = adminList.find(
      c => c.email.toLowerCase() === cleanId || 
           c.phone.replace(/\D/g, '') === cleanId.replace(/\D/g, '') ||
           c.id.toLowerCase() === cleanId
    );

    if (found) {
      setCustomer(found);
      saveCustomerToStorage(found);
      closeAuthModal();
      return { success: true };
    }

    // Default profile for demo
    const todayStr = new Date().toISOString().split('T')[0];
    const newCustomer: CustomerProfile = {
      id: `cust-${Date.now().toString().slice(-6)}`,
      name: cleanId.includes('@') ? cleanId.split('@')[0] : 'Tori Anime Member',
      email: cleanId.includes('@') ? cleanId : `${cleanId}@toriwear.in`,
      phone: '+91 62814 61985',
      city: 'Visakhapatnam',
      state: 'Andhra Pradesh',
      pincode: '530018',
      country: 'India',
      totalOrders: 0,
      totalSpent: 0,
      averageOrderValue: 0,
      lastOrderDate: todayStr,
      createdAt: todayStr,
      status: 'ACTIVE',
      segment: 'New Customers',
      tags: ['Website Registered', 'Password Login'],
      notes: ['Registered directly through TORIWEAR storefront.'],
      searchHistory: [],
      productViews: [],
      cartItems: [],
      wishlistItems: [],
      toriCredit: 250,
      insiderTier: 'Bronze',
      insiderPoints: 100,
      savedVpa: ['customer@okaxis'],
      savedCards: [],
      savedAddresses: [
        {
          id: 'addr-default',
          name: 'Home',
          addressLine: 'Door No. 4-12, Beach Road',
          city: 'Visakhapatnam',
          state: 'Andhra Pradesh',
          pincode: '530018',
          isDefault: true,
        }
      ],
    };

    setCustomer(newCustomer);
    saveCustomerToStorage(newCustomer);
    closeAuthModal();
    return { success: true };
  };

  // 4. Signup with Password
  const signupWithPassword = async (name: string, email: string, phone: string, pass: string) => {
    if (!name.trim()) return { success: false, error: 'Please enter your full name' };
    if (!email.includes('@')) return { success: false, error: 'Please enter a valid email address' };
    if (phone.replace(/\D/g, '').length < 10) return { success: false, error: 'Please enter a valid 10-digit mobile number' };
    if (pass.length < 6) return { success: false, error: 'Password must be at least 6 characters long' };

    const todayStr = new Date().toISOString().split('T')[0];
    const newCustomer: CustomerProfile = {
      id: `cust-${Date.now().toString().slice(-6)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.startsWith('+91') ? phone : `+91 ${phone.replace(/\D/g, '')}`,
      city: 'Visakhapatnam',
      state: 'Andhra Pradesh',
      pincode: '530018',
      country: 'India',
      totalOrders: 0,
      totalSpent: 0,
      averageOrderValue: 0,
      lastOrderDate: todayStr,
      createdAt: todayStr,
      status: 'ACTIVE',
      segment: 'New Customers',
      tags: ['New Customer', 'Website Signup', 'Streetwear Community'],
      notes: ['Direct signup on TORIWEAR official storefront.'],
      searchHistory: [],
      productViews: [],
      cartItems: [],
      wishlistItems: [],
      toriCredit: 250, // Welcome ₹250 wallet balance
      insiderTier: 'Bronze',
      insiderPoints: 150,
      savedVpa: [`${phone.replace(/\D/g, '')}@upi`],
      savedCards: [],
      savedAddresses: [
        {
          id: 'addr-home',
          name: 'Home',
          addressLine: 'Door No. 12, Main Street',
          city: 'Visakhapatnam',
          state: 'Andhra Pradesh',
          pincode: '530018',
          isDefault: true,
        }
      ],
    };

    setCustomer(newCustomer);
    saveCustomerToStorage(newCustomer);
    closeAuthModal();
    return { success: true };
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Firebase signOut error:', e);
    }
    setCustomer(null);
    saveCustomerToStorage(null);
    setActiveAccountModal(null);
  };

  const updateProfile = (updates: Partial<CustomerProfile>) => {
    if (!customer) return;
    const updated = { ...customer, ...updates };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  // Track: Customer Search History
  const recordSearch = (query: string) => {
    const clean = query.trim();
    if (!clean || !customer) return;

    const existing = customer.searchHistory || [];
    if (existing[0]?.toLowerCase() === clean.toLowerCase()) return; // Don't repeat identical consecutive

    const updatedSearches = [clean, ...existing.filter(s => s.toLowerCase() !== clean.toLowerCase())].slice(0, 15);
    const updated = { ...customer, searchHistory: updatedSearches };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  // Track: Customer Product Views
  const recordProductView = (product: Product) => {
    if (!customer) return;

    const existingViews = customer.productViews || [];
    const nowStr = new Date().toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });

    const newView: CustomerProductView = {
      productId: product.id,
      productName: product.name,
      price: product.price,
      image: product.images?.[0] || '',
      department: product.department,
      inStock: product.inStock,
      viewedAt: nowStr,
    };

    // Filter out if viewed very recently to keep it neat
    const filtered = existingViews.filter(v => v.productId !== product.id);
    const updatedViews = [newView, ...filtered].slice(0, 20);

    const updated = { ...customer, productViews: updatedViews };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  // Track: Customer Cart Items
  const syncCartWithCustomer = (cartItems: CartItem[]) => {
    if (!customer) return;

    const cartPreviews: CustomerCartItemPreview[] = cartItems.map(item => ({
      productId: item.product.id,
      productName: item.product.name,
      size: item.size,
      color: item.color,
      price: item.product.price,
      quantity: item.quantity,
      image: item.product.images?.[0] || '',
      inStock: item.product.inStock,
      addedAt: 'Recent',
    }));

    // Avoid unnecessary state updates if cart items match
    const existingPreviews = customer.cartItems || [];
    if (
      existingPreviews.length === cartPreviews.length &&
      existingPreviews.every(
        (it, idx) =>
          it.productId === cartPreviews[idx]?.productId &&
          it.size === cartPreviews[idx]?.size &&
          it.quantity === cartPreviews[idx]?.quantity
      )
    ) {
      return;
    }

    const updated = { ...customer, cartItems: cartPreviews };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  // Track: Customer Wishlist Items (detects Out of Stock items for Admin visibility!)
  const syncWishlistWithCustomer = (wishlistIds: string[], allProducts: Product[]) => {
    if (!customer) return;

    let oosProductIds: string[] = [];
    try {
      const adminInvRaw = localStorage.getItem('tori_admin_inventory');
      if (adminInvRaw) {
        const invList = JSON.parse(adminInvRaw);
        oosProductIds = invList
          .filter((i: any) => i.status === 'OUT_OF_STOCK' || i.availableStock === 0)
          .map((i: any) => i.productId);
      }
    } catch (e) {
      // safe fallback
    }

    const wishlistPreviews: CustomerWishlistItemPreview[] = wishlistIds.map(id => {
      const prod = allProducts.find(p => p.id === id);
      const isOOS = prod ? (prod.inStock === false || oosProductIds.includes(prod.id)) : false;

      return {
        productId: id,
        productName: prod?.name || `Product ${id}`,
        price: prod?.price || 1199,
        image: prod?.images?.[0] || '',
        inStock: !isOOS,
        addedAt: 'Recent',
      };
    });

    // Avoid unnecessary state updates if wishlist items match
    const existingWishlist = customer.wishlistItems || [];
    if (
      existingWishlist.length === wishlistPreviews.length &&
      existingWishlist.every((it, idx) => it.productId === wishlistPreviews[idx]?.productId)
    ) {
      return;
    }

    const updated = { ...customer, wishlistItems: wishlistPreviews };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const addSavedAddress = (address: Omit<CustomerSavedAddress, 'id'>) => {
    if (!customer) return;
    const newAddr: CustomerSavedAddress = {
      id: `addr-${Date.now()}`,
      ...address,
    };
    const updated = {
      ...customer,
      savedAddresses: [...(customer.savedAddresses || []), newAddr],
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const deleteSavedAddress = (addressId: string) => {
    if (!customer) return;
    const updated = {
      ...customer,
      savedAddresses: (customer.savedAddresses || []).filter(a => a.id !== addressId),
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const addSavedVpa = (vpa: string) => {
    if (!customer) return;
    const clean = vpa.trim();
    if (!clean) return;
    const updated = {
      ...customer,
      savedVpa: Array.from(new Set([...(customer.savedVpa || []), clean])),
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const deleteSavedVpa = (vpa: string) => {
    if (!customer) return;
    const updated = {
      ...customer,
      savedVpa: (customer.savedVpa || []).filter(v => v !== vpa),
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const addSavedCard = (card: Omit<CustomerSavedCard, 'id'>) => {
    if (!customer) return;
    const newCard: CustomerSavedCard = {
      id: `card-${Date.now()}`,
      ...card,
    };
    const updated = {
      ...customer,
      savedCards: [...(customer.savedCards || []), newCard],
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  const deleteSavedCard = (cardId: string) => {
    if (!customer) return;
    const updated = {
      ...customer,
      savedCards: (customer.savedCards || []).filter(c => c.id !== cardId),
    };
    setCustomer(updated);
    saveCustomerToStorage(updated);
  };

  return (
    <CustomerAuthContext.Provider
      value={{
        customer,
        isLoggedIn: !!customer,
        isAuthModalOpen,
        authModalTab,
        activeAccountModal,
        openAuthModal,
        closeAuthModal,
        openAccountModal,
        closeAccountModal,
        loginWithGoogle,
        loginWithPhoneOtp,
        loginWithEmailOtp,
        loginWithPassword,
        signupWithPassword,
        logout,
        updateProfile,
        recordSearch,
        recordProductView,
        syncCartWithCustomer,
        syncWishlistWithCustomer,
        addSavedAddress,
        deleteSavedAddress,
        addSavedVpa,
        deleteSavedVpa,
        addSavedCard,
        deleteSavedCard,
      }}
    >
      {children}
    </CustomerAuthContext.Provider>
  );
};

export const useCustomerAuth = () => {
  const context = useContext(CustomerAuthContext);
  if (!context) {
    throw new Error('useCustomerAuth must be used within a CustomerAuthProvider');
  }
  return context;
};
