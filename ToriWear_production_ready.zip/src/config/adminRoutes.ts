/**
 * TORIWEAR Enterprise Architecture - Route & Gateway Separation
 * 
 * Public Storefront Domain: https://thetoriwearstore.in
 * Private Admin Operations Gateway: /tori-ops-gateway (configurable via VITE_ADMIN_PATH)
 * 
 * Customer-facing pages must never render admin links or trigger buttons.
 * Admin endpoints & views are strictly protected by server-side authentication,
 * session validation, and 2FA TOTP verification.
 */

// Canonical Public Storefront URL
export const PUBLIC_STOREFRONT_URL = 'https://thetoriwearstore.in';

// Default private admin route
export const DEFAULT_ADMIN_PATH = '/tori-ops-gateway';

// Resolved private admin route from environment or default
export const ADMIN_GATEWAY_PATH = (() => {
  if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_ADMIN_PATH) {
    const custom = import.meta.env.VITE_ADMIN_PATH.trim();
    if (custom) {
      return custom.startsWith('/') ? custom : `/${custom}`;
    }
  }
  return DEFAULT_ADMIN_PATH;
})();

export const ADMIN_CONFIG = {
  PUBLIC_STOREFRONT_URL,
  ADMIN_PATH: ADMIN_GATEWAY_PATH,
  DEFAULT_ADMIN_PATH,
  // Recognized admin aliases for operational routing compatibility
  ALLOWED_ADMIN_ALIASES: [
    ADMIN_GATEWAY_PATH,
    '/tori-ops-gateway',
    '/tori-portal-access',
    '/admin',
  ],
};

/**
 * Checks if a given URL pathname or hash corresponds to an administrative route.
 */
export function isAdminPath(pathname: string = '', hash: string = ''): boolean {
  const cleanPath = pathname.toLowerCase().replace(/\/+$/, '');
  const cleanHash = hash.toLowerCase();

  // Check against primary configured gateway path
  if (cleanPath === ADMIN_GATEWAY_PATH || cleanPath.startsWith(`${ADMIN_GATEWAY_PATH}/`)) {
    return true;
  }

  // Check allowed operational aliases
  for (const alias of ADMIN_CONFIG.ALLOWED_ADMIN_ALIASES) {
    const cleanAlias = alias.toLowerCase().replace(/\/+$/, '');
    if (cleanPath === cleanAlias || cleanPath.startsWith(`${cleanAlias}/`)) {
      return true;
    }
  }

  // Hash route support
  if (
    cleanHash === '#admin' ||
    cleanHash === '#tori-ops-gateway' ||
    cleanHash.startsWith('#admin/') ||
    cleanHash.startsWith('#tori-ops-gateway/')
  ) {
    return true;
  }

  return false;
}

/**
 * Formats a path inside the private admin portal.
 */
export function getAdminSubpath(subpath?: string): string {
  if (!subpath || subpath === '/' || subpath === '') {
    return ADMIN_CONFIG.ADMIN_PATH;
  }
  const clean = subpath.startsWith('/') ? subpath : `/${subpath}`;
  return `${ADMIN_CONFIG.ADMIN_PATH}${clean}`;
}
