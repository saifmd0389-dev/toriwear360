import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, Check, ChevronDown, ChevronUp, ChevronLeft, ChevronRight,
  ZoomIn, ZoomOut, RotateCw, X, ArrowRight, Sparkles, AlertCircle
} from 'lucide-react';
import { Product } from '../types';
import { useCustomerAuth } from '../context/CustomerAuthContext';
import { RecentlyViewedSection } from './RecentlyViewedSection';

interface ProductDetailPageProps {
  product: Product;
  allProducts: Product[];
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onAddToCart: (product: Product, size: string, color: string) => void;
  onBuyNow: (product: Product, size: string, color: string) => void;
  onBackToCatalog: () => void;
  onNavigateHome?: () => void;
  onSelectDepartment?: (dept: 'MEN' | 'KIDS') => void;
  onSelectWorld?: (world: string) => void;
  onSelectProduct: (product: Product) => void;
  onOpenSizeGuide: () => void;
  onOpenCombo?: (product: Product) => void;
  recentlyViewedIds?: string[];
  wishlistIds?: string[];
  onRemoveFromRecent?: (productId: string) => void;
  onClearAllRecent?: () => void;
}

interface GalleryImageItem {
  url: string;
  tagTopLeft?: string;
  tagBottomLeft?: string;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  allProducts,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onBackToCatalog,
  onNavigateHome,
  onSelectDepartment,
  onSelectWorld,
  onSelectProduct,
  onOpenSizeGuide,
  recentlyViewedIds = [],
  wishlistIds = [],
  onRemoveFromRecent,
  onClearAllRecent,
}) => {
  // Available sizes matching The Souled Store standard
  const menSizes = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'];
  const kidsSizes = ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '7-8Y', '9-10Y', '11-12Y'];
  const availableSizes = product.department === 'KIDS' ? kidsSizes : menSizes;

  const [selectedSize, setSelectedSize] = useState<string>('L');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors?.[0]?.name || 'Black');
  const [quantity, setQuantity] = useState<number>(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const [pincode, setPincode] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<string | null>(null);
  const [shareToast, setShareToast] = useState<string | null>(null);

  // Accordion states
  const [isDetailsOpen, setIsDetailsOpen] = useState(true);
  const [isDescOpen, setIsDescOpen] = useState(false);

  // Zoom Lightbox State (Screenshot 5)
  const [isZoomOpen, setIsZoomOpen] = useState(false);
  const [zoomImgIndex, setZoomImgIndex] = useState(0);
  const [zoomScale, setZoomScale] = useState(1);
  const [panPosition, setPanPosition] = useState({ x: 50, y: 50 });
  const [isHoverZooming, setIsHoverZooming] = useState(false);
  const zoomContainerRef = useRef<HTMLDivElement>(null);

  // Customer tracking
  const { recordProductView } = useCustomerAuth();

  // Scroll to top on product change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setSelectedSize(product.department === 'KIDS' ? '5-6Y' : 'L');
    if (product.colors?.[0]?.name) setSelectedColor(product.colors[0].name);
    setQuantity(1);
    setPincodeStatus(null);
    setZoomScale(1);
    recordProductView(product);
  }, [product.id]);

  // Keyboard navigation for zoom modal and page back
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isZoomOpen) {
          setIsZoomOpen(false);
        } else {
          onBackToCatalog();
        }
      } else if (isZoomOpen && e.key === 'ArrowLeft') {
        setZoomImgIndex((prev) => (prev > 0 ? prev - 1 : galleryImages.length - 1));
        setZoomScale(1);
      } else if (isZoomOpen && e.key === 'ArrowRight') {
        setZoomImgIndex((prev) => (prev < galleryImages.length - 1 ? prev + 1 : 0));
        setZoomScale(1);
      } else if (isZoomOpen && (e.key === '+' || e.key === '=')) {
        setZoomScale((s) => Math.min(3.5, s + 0.5));
      } else if (isZoomOpen && e.key === '-') {
        setZoomScale((s) => Math.max(1, s - 0.5));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isZoomOpen, onBackToCatalog]);

  // Lock body scroll when zoom lightbox is open
  useEffect(() => {
    if (isZoomOpen) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isZoomOpen]);

  // Construct 6 detailed multi-angle gallery images as shown in Screenshot 1 & 2
  const galleryImages: GalleryImageItem[] = React.useMemo(() => {
    const rawImages = product.images && product.images.length > 0 ? product.images : [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=1000&auto=format&fit=crop&q=85',
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1000&auto=format&fit=crop&q=85',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1000&auto=format&fit=crop&q=85',
    ];

    // High resolution streetwear companions for macro details (puff print, cut & sew sleeve, back, neck collar)
    const detailShots = [
      rawImages[0],
      rawImages[1] || 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=1000&auto=format&fit=crop&q=85',
      rawImages[2] || 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1000&auto=format&fit=crop&q=85',
      rawImages[3] || 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=1000&auto=format&fit=crop&q=85',
      rawImages[4] || rawImages[1] || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=1000&auto=format&fit=crop&q=85',
      rawImages[5] || rawImages[0] || 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?w=1000&auto=format&fit=crop&q=85',
    ];

    return [
      {
        url: detailShots[0],
        tagTopLeft: 'OVERSIZED FIT',
        tagBottomLeft: 'PREMIUM HEAVY GAUGE FABRIC',
      },
      {
        url: detailShots[1],
      },
      {
        url: detailShots[2],
      },
      {
        url: detailShots[3],
      },
      {
        url: detailShots[4],
      },
      {
        url: detailShots[5],
      },
    ];
  }, [product.images]);

  // Variant looks (current look + alternate sibling styles e.g. green variant or other color)
  const variantLooks = React.useMemo(() => {
    const siblings = allProducts
      .filter((p) => p.id !== product.id && (p.world === product.world || p.department === product.department))
      .slice(0, 1);

    const looks = [
      {
        id: product.id,
        name: product.name,
        image: galleryImages[0]?.url,
        isActive: true,
        product: product,
      },
    ];

    if (siblings[0]) {
      looks.push({
        id: siblings[0].id,
        name: siblings[0].name,
        image: siblings[0].images?.[0] || 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=400&auto=format&fit=crop&q=80',
        isActive: false,
        product: siblings[0],
      });
    }

    return looks;
  }, [allProducts, product, galleryImages]);

  // "Others Also Bought" recommendation carousel (Screenshots 3 & 4)
  const othersAlsoBought = React.useMemo(() => {
    return allProducts
      .filter((p) => p.id !== product.id)
      .slice(0, 8);
  }, [allProducts, product.id]);

  const [carouselIndex, setCarouselIndex] = useState(0);
  const visibleCarouselItems = othersAlsoBought.slice(carouselIndex, carouselIndex + 4);

  const handleNextCarousel = () => {
    if (carouselIndex + 4 < othersAlsoBought.length) {
      setCarouselIndex((i) => i + 1);
    } else {
      setCarouselIndex(0);
    }
  };

  const handlePrevCarousel = () => {
    if (carouselIndex > 0) {
      setCarouselIndex((i) => i - 1);
    } else {
      setCarouselIndex(Math.max(0, othersAlsoBought.length - 4));
    }
  };

  const handleAdd = () => {
    for (let i = 0; i < quantity; i++) {
      onAddToCart(product, selectedSize, selectedColor);
    }
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2400);
  };

  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    if (pincode.trim().length === 6 && /^\d+$/.test(pincode.trim())) {
      setPincodeStatus(`✓ Delivery available for PIN ${pincode.trim()} within 2-4 business days. Free shipping applies.`);
    } else {
      setPincodeStatus('Please enter a valid 6-digit PIN code.');
    }
  };

  const handleShareClick = (platform: string) => {
    try {
      const url = window.location.href;
      const title = `${product.name} - Boxy Fit Streetwear T-Shirt`;
      
      if (platform === 'whatsapp') {
        window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(title + ' ' + url)}`, '_blank');
      } else if (platform === 'facebook') {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
      } else if (platform === 'x') {
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`, '_blank');
      } else if (platform === 'instagram' || platform === 'copy') {
        if (navigator?.clipboard) {
          navigator.clipboard.writeText(url).catch(() => {});
          setShareToast('Link copied to clipboard! Share on Instagram');
          setTimeout(() => setShareToast(null), 2500);
        }
      }
    } catch {
      // Safe fallback
    }
  };

  // Open zoom modal on click of any image in the gallery
  const handleOpenZoom = (index: number) => {
    setZoomImgIndex(index);
    setZoomScale(1.8); // Default to a sharp 1.8x zoom on click for instant clear view of design!
    setIsZoomOpen(true);
  };

  // Handle mouse move inside the zoom container for super-sharp design inspection
  const handleZoomMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!zoomContainerRef.current) return;
    const rect = zoomContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPanPosition({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) });
  };

  // Toggle zoom level when clicking directly on the zoomed image
  const handleToggleZoomScale = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomScale((prev) => {
      if (prev <= 1.2) return 2.2;
      if (prev <= 2.2) return 3.2;
      return 1;
    });
  };

  return (
    <div className="min-h-screen bg-white text-neutral-900 font-sans selection:bg-neutral-900 selection:text-white pb-0">
      
      {/* 1. Breadcrumbs Strip (Clean The Souled Store aesthetic) */}
      <div className="border-b border-neutral-200/80 bg-white">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between">
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-[11px] sm:text-xs text-neutral-500 overflow-x-auto no-scrollbar whitespace-nowrap">
            <button
              onClick={onBackToCatalog}
              className="inline-flex items-center gap-1 text-neutral-700 hover:text-black font-bold transition cursor-pointer pr-1"
              title="Return to Catalog"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
            <span className="text-neutral-300">|</span>
            <button
              onClick={() => onNavigateHome ? onNavigateHome() : onBackToCatalog()}
              className="text-neutral-500 hover:text-black hover:underline transition cursor-pointer"
            >
              Home
            </button>
            <span className="text-neutral-400">/</span>
            <button
              onClick={() => onSelectDepartment ? onSelectDepartment(product.department) : onBackToCatalog()}
              className="text-neutral-500 hover:text-black hover:underline transition cursor-pointer"
            >
              {product.department === 'KIDS' ? 'Kids Boxy Fit T-shirts' : 'Men Boxy Fit T-shirts'}
            </button>
            <span className="text-neutral-400">/</span>
            <button
              onClick={() => onSelectWorld ? onSelectWorld(product.world) : onBackToCatalog()}
              className="text-neutral-500 hover:text-black hover:underline transition cursor-pointer"
            >
              {product.world || 'Anime Streetwear'}
            </button>
            <span className="text-neutral-400">/</span>
            <span className="text-neutral-600 font-medium truncate max-w-[200px] sm:max-w-md">
              {product.name}
            </span>
          </nav>
        </div>
      </div>

      {/* 2. Main 2-Column Product Presentation Stage */}
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">

          {/* ========================================================== */}
          {/* LEFT: 2-Column Multi-Angle Image Grid (Screenshot 1 & 2)  */}
          {/* ========================================================== */}
          <div className="lg:col-span-7">
            <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
              {galleryImages.map((img, idx) => (
                <div
                  key={idx}
                  onClick={() => handleOpenZoom(idx)}
                  className="relative group bg-[#F5F5F3] overflow-hidden cursor-zoom-in aspect-[3/4] select-none"
                  title="Click to zoom in for clear view of design"
                >
                  <img
                    src={img.url}
                    alt={`${product.name} angle ${idx + 1}`}
                    className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-[1.02]"
                    loading={idx < 2 ? 'eager' : 'lazy'}
                  />

                  {/* Top-Left Tag e.g. "OVERSIZED FIT" */}
                  {img.tagTopLeft && (
                    <div className="absolute top-2.5 left-2.5 z-10">
                      <span className="bg-black/60 backdrop-blur-xs text-white text-[9px] sm:text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-none shadow-xs">
                        {img.tagTopLeft}
                      </span>
                    </div>
                  )}

                  {/* Bottom-Left Tag e.g. "PREMIUM HEAVY GAUGE FABRIC" */}
                  {img.tagBottomLeft && (
                    <div className="absolute bottom-2.5 left-2.5 z-10">
                      <span className="bg-black/80 text-white text-[9px] sm:text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-none shadow-xs">
                        {img.tagBottomLeft}
                      </span>
                    </div>
                  )}

                  {/* Subtle hover icon indicating zoom */}
                  <div className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 text-white p-1.5 rounded-full backdrop-blur-xs">
                    <ZoomIn className="w-3.5 h-3.5" />
                  </div>
                </div>
              ))}
            </div>

            <p className="text-center text-xs text-neutral-400 mt-2 flex items-center justify-center gap-1.5">
              <ZoomIn className="w-3.5 h-3.5 text-neutral-500" />
              <span>Click any image to zoom and inspect design details</span>
            </p>
          </div>

          {/* ========================================================== */}
          {/* RIGHT: Commerce Info, Variant, Size, Add to Cart (Sticky)  */}
          {/* ========================================================== */}
          <div className="lg:col-span-5 lg:sticky lg:top-16 space-y-5">
            
            {/* 1. Title, Subtitle, Price */}
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight leading-snug">
                {product.name}
              </h1>

              <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">
                {product.department === 'KIDS' ? 'Kids Boxy Fit T-Shirts' : 'Men Boxy Fit T-Shirts'}
              </p>

              <div className="mt-3">
                <span className="text-xl sm:text-2xl font-bold text-neutral-900">
                  ₹ {product.price.toLocaleString('en-IN')}
                </span>
                <p className="text-[11px] sm:text-xs text-neutral-400 mt-0.5">
                  Price incl. of all taxes
                </p>
              </div>
            </div>

            {/* 2. Shop by Variant/Look (Screenshot 1 & 2) */}
            {variantLooks.length > 0 && (
              <div>
                <h3 className="text-xs font-bold text-neutral-900 mb-2">
                  Shop by Variant/Look
                </h3>
                <div className="flex items-center gap-3">
                  {variantLooks.map((look) => (
                    <button
                      key={look.id}
                      onClick={() => onSelectProduct(look.product)}
                      className={`relative w-14 h-18 sm:w-16 sm:h-20 overflow-hidden rounded-xs border transition cursor-pointer ${
                        look.isActive 
                          ? 'border-2 border-black ring-1 ring-black' 
                          : 'border-neutral-300 hover:border-neutral-600 opacity-80 hover:opacity-100'
                      }`}
                      title={look.name}
                    >
                      <img 
                        src={look.image} 
                        alt={look.name} 
                        className="w-full h-full object-cover object-center" 
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 3. Please select a size. & SIZE CHART */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-neutral-900">
                  Please select a size.
                </span>
                <button
                  onClick={onOpenSizeGuide}
                  className="text-[#0066cc] font-semibold hover:underline cursor-pointer tracking-tight"
                >
                  SIZE CHART
                </button>
              </div>

              {/* Size boxes: XXS, XS, S, M, L, XL, XXL, XXXL */}
              <div className="flex flex-wrap gap-2">
                {availableSizes.map((size) => {
                  const isSelected = selectedSize === size;
                  const varForSize = (product.variants || []).find((v: any) => v.size === size);
                  const isSizeOutOfStock = varForSize && varForSize.stock === 0;

                  return (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[42px] px-3 py-2 text-xs text-center border transition cursor-pointer font-medium relative ${
                        isSelected
                          ? 'border-2 border-black bg-neutral-50 font-bold text-black shadow-xs'
                          : isSizeOutOfStock
                          ? 'border-neutral-200 text-neutral-300 bg-neutral-50 line-through'
                          : 'border-neutral-300 text-neutral-700 hover:border-black bg-white'
                      }`}
                    >
                      {size}
                    </button>
                  );
                })}
              </div>

              {/* Stock status indicator */}
              {(() => {
                const selectedVariant = (product.variants || []).find((v: any) => v.size === selectedSize);
                const currentStock = selectedVariant ? selectedVariant.stock : (product.stock !== undefined ? product.stock : 20);
                const isItemOutOfStock = product.inStock === false || (product.stock !== undefined && product.stock === 0) || currentStock === 0;
                const isItemLowStock = !isItemOutOfStock && currentStock <= 5;

                if (isItemOutOfStock) {
                  return (
                    <div className="mt-2.5 px-3 py-2 bg-red-50 border border-red-200 text-red-700 rounded text-xs font-mono font-medium flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                      <span>Currently Out of Stock in size {selectedSize}. Please choose another size.</span>
                    </div>
                  );
                }

                if (isItemLowStock) {
                  return (
                    <div className="mt-2.5 px-3 py-1.5 bg-amber-50 border border-amber-200 text-amber-800 rounded text-xs font-mono font-medium flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                      <span>Hurry! Only {currentStock} {currentStock === 1 ? 'item' : 'items'} left in stock.</span>
                    </div>
                  );
                }

                return null;
              })()}
            </div>

            {/* 4. Quantity Dropdown (Screenshot 1 & 2) */}
            <div className="flex items-center gap-3">
              <label htmlFor="pdp-qty-select" className="text-xs text-neutral-700 font-medium">
                Quantity
              </label>
              <div className="relative inline-block">
                <select
                  id="pdp-qty-select"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="appearance-none border border-neutral-300 bg-white text-xs font-medium py-1.5 pl-3 pr-8 rounded-none hover:border-black cursor-pointer focus:outline-none focus:border-black"
                >
                  {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n}>
                      {String(n).padStart(2, '0')}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-neutral-600 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            {/* 5. ADD TO CART and WISHLIST buttons (The Souled Store signature layout) */}
            <div className="flex items-center gap-3 pt-1">
              {(() => {
                const selectedVariant = (product.variants || []).find((v: any) => v.size === selectedSize);
                const currentStock = selectedVariant ? selectedVariant.stock : (product.stock !== undefined ? product.stock : 20);
                const isItemOutOfStock = product.inStock === false || (product.stock !== undefined && product.stock === 0) || currentStock === 0;

                return (
                  <button
                    id="pdp-add-to-cart-red-btn"
                    disabled={isItemOutOfStock}
                    onClick={handleAdd}
                    className={`flex-1 py-3.5 px-6 font-bold text-xs uppercase tracking-wider transition shadow-xs rounded-none flex items-center justify-center gap-2 ${
                      isItemOutOfStock
                        ? 'bg-neutral-200 text-neutral-400 cursor-not-allowed'
                        : 'bg-[#e11b23] hover:bg-[#c6171e] text-white cursor-pointer active:scale-[0.99]'
                    }`}
                  >
                    <span>{isItemOutOfStock ? 'OUT OF STOCK' : (addedNotice ? 'ADDED TO CART! ✓' : 'ADD TO CART')}</span>
                  </button>
                );
              })()}

              <button
                id="pdp-wishlist-outline-btn"
                onClick={() => onToggleWishlist(product.id)}
                className={`flex-1 py-3.5 px-6 border transition cursor-pointer text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 rounded-none ${
                  isWishlisted
                    ? 'border-[#e11b23] text-[#e11b23] bg-red-50/50'
                    : 'border-neutral-900 text-neutral-900 bg-white hover:bg-neutral-50'
                }`}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#e11b23] text-[#e11b23]' : 'text-neutral-900'}`} />
                <span>{isWishlisted ? 'WISHLISTED' : 'WISHLIST'}</span>
              </button>
            </div>

            {/* 6. Share Row */}
            <div className="flex items-center gap-3 text-xs text-neutral-600 pt-1">
              <span className="font-medium text-neutral-700">Share</span>
              <div className="flex items-center gap-2.5">
                {/* WhatsApp */}
                <button
                  onClick={() => handleShareClick('whatsapp')}
                  className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center hover:opacity-90 transition cursor-pointer"
                  title="Share on WhatsApp"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                  </svg>
                </button>

                {/* Facebook */}
                <button
                  onClick={() => handleShareClick('facebook')}
                  className="w-7 h-7 rounded-full bg-[#1877F2] text-white flex items-center justify-center hover:opacity-90 transition cursor-pointer"
                  title="Share on Facebook"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </button>

                {/* X / Twitter */}
                <button
                  onClick={() => handleShareClick('x')}
                  className="w-7 h-7 rounded-full bg-black text-white flex items-center justify-center hover:opacity-90 transition cursor-pointer"
                  title="Share on X"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                </button>

                {/* Instagram / Copy Link */}
                <button
                  onClick={() => handleShareClick('instagram')}
                  className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#f9ce34] via-[#ee2a7b] to-[#6228d7] text-white flex items-center justify-center hover:opacity-90 transition cursor-pointer"
                  title="Share / Copy for Instagram"
                >
                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </button>
              </div>

              {shareToast && (
                <span className="text-[11px] text-emerald-600 font-medium ml-2">
                  {shareToast}
                </span>
              )}
            </div>

            {/* 7. Delivery Details & Pincode Checker (Screenshot 1 & 2) */}
            <div className="pt-2">
              <h3 className="text-xs font-bold text-neutral-900 mb-2">
                Delivery Details
              </h3>
              
              <form onSubmit={handleCheckPincode} className="relative flex items-center">
                <input
                  type="text"
                  maxLength={6}
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="Enter Pincode"
                  className="w-full border border-neutral-300 py-2 px-3 text-xs focus:outline-none focus:border-black rounded-none placeholder:text-neutral-400 bg-white"
                />
                <button
                  type="submit"
                  className="absolute right-3 text-xs font-bold text-[#0066cc] hover:underline cursor-pointer"
                >
                  CHECK
                </button>
              </form>

              {pincodeStatus && (
                <p className={`text-[11px] mt-1.5 leading-relaxed ${
                  pincodeStatus.startsWith('✓') ? 'text-emerald-700 font-medium' : 'text-red-600'
                }`}>
                  {pincodeStatus}
                </p>
              )}

              {/* Return Policy Notice Box with circle icon */}
              <div className="mt-3 p-3 bg-neutral-50 border border-neutral-200/80 flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full border border-neutral-400 text-neutral-600 flex items-center justify-center shrink-0 mt-0.5">
                  <RotateCw className="w-3 h-3" />
                </div>
                <p className="text-[11px] text-neutral-600 leading-snug">
                  This product is eligible for return or exchange under our 30-day return or exchange policy. No questions asked.
                </p>
              </div>
            </div>

            {/* 8. Collapsible Accordions (Product Details & Product Description) */}
            <div className="border-t border-neutral-200 divide-y divide-neutral-200 pt-1">
              
              {/* Accordion 1: Product Details */}
              <div className="py-3">
                <button
                  onClick={() => setIsDetailsOpen(!isDetailsOpen)}
                  className="w-full flex items-center justify-between text-xs font-bold text-neutral-900 cursor-pointer"
                >
                  <span>Product Details</span>
                  {isDetailsOpen ? (
                    <ChevronUp className="w-4 h-4 text-neutral-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-500" />
                  )}
                </button>

                {isDetailsOpen && (
                  <div className="mt-3 space-y-3 text-xs text-neutral-700 leading-relaxed animate-in fade-in duration-200">
                    <div>
                      <strong className="block text-neutral-900 font-semibold mb-0.5">Material & Care:</strong>
                      <p>100% Cotton</p>
                      <p>Machine Wash</p>
                    </div>

                    <div>
                      <strong className="block text-neutral-900 font-semibold mb-0.5">Country of Origin:</strong>
                      <p>India (and proud)</p>
                    </div>

                    <div>
                      <strong className="block text-neutral-900 font-semibold mb-0.5">Manufactured & Sold By:</strong>
                      <p>TORIWEAR Originals Pvt. Ltd.</p>
                      <p>Studio Shibuya &amp; Anime Apparel Axis</p>
                      <p>Mumbai &amp; Tokyo</p>
                      <p className="text-neutral-900 font-medium">support@toriwear.com</p>
                      <p>Official Brand Care: +91 98201 45112</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Accordion 2: Product Description */}
              <div className="py-3">
                <button
                  onClick={() => setIsDescOpen(!isDescOpen)}
                  className="w-full flex items-center justify-between text-xs font-bold text-neutral-900 cursor-pointer"
                >
                  <span>Product Description</span>
                  {isDescOpen ? (
                    <ChevronUp className="w-4 h-4 text-neutral-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-500" />
                  )}
                </button>

                {isDescOpen && (
                  <div className="mt-3 space-y-2 text-xs text-neutral-600 leading-relaxed animate-in fade-in duration-200">
                    <p>{product.description}</p>
                    {product.storyQuote && (
                      <p className="italic text-neutral-500">"{product.storyQuote}"</p>
                    )}
                    <ul className="list-disc pl-4 space-y-1 text-neutral-600 pt-1">
                      <li>Fit: {product.fit}</li>
                      <li>Fabric: {product.fabric || '100% Combed Heavy Cotton'}</li>
                      <li>Weight: {product.gsm || 240} GSM Heavyweight drape</li>
                      <li>Print: {product.print || 'High Density Puff & Screen Ink'}</li>
                    </ul>
                  </div>
                )}
              </div>

            </div>

          </div>
        </div>

        {/* ========================================================== */}
        {/* 3. "Others Also Bought" Carousel Section (Screenshot 3 & 4) */}
        {/* ========================================================== */}
        <div className="mt-16 pt-10 border-t border-neutral-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm sm:text-base font-bold text-neutral-900">
              Others Also Bought
            </h2>
            <div className="flex items-center gap-1">
              <button
                onClick={handlePrevCarousel}
                className="w-7 h-7 rounded-full border border-neutral-300 flex items-center justify-center text-neutral-600 hover:text-black hover:border-black transition cursor-pointer"
                aria-label="Previous items"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNextCarousel}
                className="w-7 h-7 rounded-full border border-neutral-300 flex items-center justify-center text-neutral-600 hover:text-black hover:border-black transition cursor-pointer"
                aria-label="Next items"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
            {visibleCarouselItems.map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectProduct(item)}
                className="group cursor-pointer select-none"
              >
                <div className="relative aspect-[3/4] bg-[#F5F5F3] overflow-hidden mb-2">
                  <img
                    src={item.images?.[0] || 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80'}
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    loading="lazy"
                  />
                  {/* Badges on card */}
                  <div className="absolute top-2 left-2">
                    <span className="bg-black/60 text-white text-[8px] font-bold px-1.5 py-0.5 tracking-wider uppercase">
                      OVERSIZED FIT
                    </span>
                  </div>
                  <div className="absolute bottom-2 left-2">
                    <span className="bg-black/80 text-white text-[8px] font-bold px-1.5 py-0.5 tracking-wider uppercase">
                      PREMIUM HEAVY GAUGE FABRIC
                    </span>
                  </div>
                </div>

                <h3 className="text-xs font-bold text-neutral-900 truncate group-hover:text-[#e11b23] transition">
                  {item.name}
                </h3>
                <p className="text-[11px] text-neutral-500 truncate">
                  {item.department === 'KIDS' ? "Kids T-Shirts_Others" : "Men T-Shirts_Others"}
                </p>
                <div className="text-xs font-bold text-neutral-900 mt-0.5">
                  ₹ {item.price.toLocaleString('en-IN')}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recently Viewed Shelf (Filtered to exclude currently displayed product) */}
        {recentlyViewedIds.filter((id) => id !== product.id).length > 0 && (
          <div className="mt-14 pt-8 border-t border-neutral-800">
            <RecentlyViewedSection
              recentlyViewedIds={recentlyViewedIds.filter((id) => id !== product.id)}
              allProducts={allProducts}
              wishlist={wishlistIds}
              onSelectProduct={onSelectProduct}
              onToggleWishlist={(prod) => onToggleWishlist(prod.id)}
              onAddToCart={onAddToCart}
              onRemoveFromRecent={onRemoveFromRecent}
              onClearAllRecent={onClearAllRecent}
              title="RECENTLY VIEWED PIECES"
              subtitle="Quickly return to other anime streetwear designs you were checking out"
              className="py-6 bg-transparent border-0"
            />
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* 4. FULLSCREEN ZOOM LIGHTBOX MODAL WITH ULTRA CLEAR DESIGN ZOOM (Snip 5)   */}
      {/* ========================================================================= */}
      {isZoomOpen && (
        <div 
          style={{ zIndex: 9999 }}
          className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-sm flex flex-col items-center justify-between select-none animate-in fade-in duration-200"
          onClick={() => setIsZoomOpen(false)}
        >
          {/* Top Bar with Zoom Controls & Close Button (Screenshot 5) */}
          <div 
            className="w-full max-w-6xl px-4 py-3 flex items-center justify-between text-white z-20"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Zoom Tool Controls */}
            <div className="flex items-center gap-2 bg-neutral-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-neutral-700 text-xs">
              <button
                onClick={() => setZoomScale((s) => Math.max(1, s - 0.4))}
                className="p-1 hover:text-red-400 transition cursor-pointer"
                title="Zoom Out (-)"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              <span className="font-mono font-semibold text-neutral-200 min-w-[45px] text-center">
                {Math.round(zoomScale * 100)}%
              </span>

              <button
                onClick={() => setZoomScale((s) => Math.min(3.5, s + 0.4))}
                className="p-1 hover:text-red-400 transition cursor-pointer"
                title="Zoom In (+)"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              <div className="w-[1px] h-3.5 bg-neutral-700 mx-1" />

              <button
                onClick={() => setZoomScale(1)}
                className="text-[10px] text-neutral-400 hover:text-white transition cursor-pointer px-1"
                title="Reset Zoom"
              >
                Reset
              </button>
            </div>

            <div className="text-[11px] text-neutral-400 hidden sm:block">
              Click image to toggle zoom • Move mouse to inspect print details &amp; fabric
            </div>

            {/* Close Button with Circle Border (Exact Screenshot 5) */}
            <button
              onClick={() => setIsZoomOpen(false)}
              className="min-w-[40px] min-h-[40px] rounded-full border border-white/60 bg-black/50 hover:bg-white hover:text-black transition flex items-center justify-center cursor-pointer"
              aria-label="Close zoom preview"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Central Main Zoom Stage */}
          <div 
            className="relative flex-1 w-full max-w-4xl flex items-center justify-center px-4 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Left Circular Navigation Arrow (Screenshot 5) */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setZoomImgIndex((prev) => (prev > 0 ? prev - 1 : galleryImages.length - 1));
                setZoomScale(1.8);
              }}
              className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/90 hover:bg-white text-black shadow-xl flex items-center justify-center transition active:scale-95 cursor-pointer"
              aria-label="Previous picture"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Right Circular Navigation Arrow (Screenshot 5) */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setZoomImgIndex((prev) => (prev < galleryImages.length - 1 ? prev + 1 : 0));
                setZoomScale(1.8);
              }}
              className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white/90 hover:bg-white text-black shadow-xl flex items-center justify-center transition active:scale-95 cursor-pointer"
              aria-label="Next picture"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Zoomable Image Container with Smooth Pan Follow on Cursor */}
            <div 
              ref={zoomContainerRef}
              onMouseMove={handleZoomMouseMove}
              onMouseEnter={() => setIsHoverZooming(true)}
              onMouseLeave={() => setIsHoverZooming(false)}
              onClick={handleToggleZoomScale}
              className={`relative max-h-[74vh] aspect-[3/4] overflow-hidden bg-neutral-950 flex items-center justify-center rounded-xs shadow-2xl ${
                zoomScale > 1 ? 'cursor-move' : 'cursor-zoom-in'
              }`}
            >
              <img
                src={galleryImages[zoomImgIndex]?.url}
                alt={`${product.name} zoom view`}
                style={{
                  transformOrigin: `${panPosition.x}% ${panPosition.y}%`,
                  transform: `scale(${zoomScale})`,
                  transition: isHoverZooming && zoomScale > 1 ? 'none' : 'transform 0.25s ease-out',
                }}
                className="w-full h-full object-contain pointer-events-none select-none"
              />
            </div>
          </div>

          {/* Bottom Thumbnail Strip (Screenshot 5) */}
          <div 
            className="w-full bg-white py-3 px-4 flex items-center justify-center gap-2.5 sm:gap-3 overflow-x-auto no-scrollbar z-20"
            onClick={(e) => e.stopPropagation()}
          >
            {galleryImages.map((thumb, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setZoomImgIndex(idx);
                  setZoomScale(1.8);
                }}
                className={`relative w-12 h-16 sm:w-14 sm:h-18 rounded-xs overflow-hidden transition cursor-pointer bg-neutral-100 shrink-0 ${
                  zoomImgIndex === idx
                    ? 'border-2 border-black scale-105 shadow-md'
                    : 'border border-neutral-300 opacity-60 hover:opacity-100'
                }`}
              >
                <img
                  src={thumb.url}
                  alt={`Thumbnail ${idx + 1}`}
                  className="w-full h-full object-cover object-center"
                />
              </button>
            ))}
          </div>

        </div>
      )}

    </div>
  );
};

export default ProductDetailPage;
