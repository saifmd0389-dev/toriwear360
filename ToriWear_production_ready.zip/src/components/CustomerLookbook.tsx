import React from 'react';
import { Camera, Star, CheckCircle, ArrowRight, Sparkles } from 'lucide-react';
import { Product } from '../types';

interface CustomerLookbookProps {
  products: Product[];
  onOpenProductDetail: (product: Product) => void;
}

export const CustomerLookbook: React.FC<CustomerLookbookProps> = ({
  products,
  onOpenProductDetail,
}) => {
  const looks = [
    {
      id: 'look-1',
      name: 'Devansh K.',
      city: 'Bengaluru',
      image: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=700&auto=format&fit=crop&q=80',
      productName: 'Void Walker Graphic Tee',
      productMatch: 'Void Walker',
      sizeWorn: 'Wearing Size XL (5’11”)',
      rating: 5,
      review: 'The 240 GSM weight is unreal. The shadow print has this velvety matte finish that looks ten times more expensive than standard anime merch.',
      tag: 'MEN // DARK SHONEN',
    },
    {
      id: 'look-2',
      name: 'Rohan & Kabir (Dad & Son)',
      city: 'Mumbai',
      image: 'https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=700&auto=format&fit=crop&q=80',
      productName: 'Kami & Zero Hero Tee',
      productMatch: 'Kami & Zero',
      sizeWorn: 'Wearing Size 6–7Y & Men L',
      rating: 5,
      review: 'Got the matching theme tees. My 6-year-old loves Kami the sneaker cloud! Super soft cotton and hasn’t shrunk after 5 washes.',
      tag: 'KIDS // CUTE ADVENTURE',
    },
    {
      id: 'look-3',
      name: 'Meera S.',
      city: 'Delhi NCR',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700&auto=format&fit=crop&q=80',
      productName: 'Neon Ronin Heavyweight Tee',
      productMatch: 'Neon Ronin',
      sizeWorn: 'Wearing Size M (Oversized fit, 5’6”)',
      rating: 5,
      review: 'I love that it’s not an obvious anime rip-off. It feels like high-end cyberpunk techwear with genuine original art. People constantly ask me where I got it.',
      tag: 'MEN // CYBERPUNK',
    },
    {
      id: 'look-4',
      name: 'Arjun V.',
      city: 'Pune',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=700&auto=format&fit=crop&q=80',
      productName: 'Broken Blade Samurai Tee',
      productMatch: 'Broken Blade',
      sizeWorn: 'Wearing Size XXL (6’2”)',
      rating: 5,
      review: 'The ribbed collar doesn’t bacon or sag. Premium drop shoulder cut that actually hangs properly without looking boxy or stiff.',
      tag: 'MEN // SAMURAI',
    },
  ];

  return (
    <section id="customer-lookbook-section" className="py-20 bg-[#090a0f] border-b border-neutral-800/80 relative select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] font-mono uppercase tracking-widest text-[#FF2028] mb-3">
              <Camera className="w-3.5 h-3.5" />
              <span>COMMUNITY STREET STYLE</span>
            </div>
            <h2 className="font-heading text-4xl sm:text-5xl font-black text-white uppercase tracking-tight">
              SEEN IN THE <span className="text-[#FF2028]">REAL WORLD</span>
            </h2>
            <p className="mt-1 font-mono text-sm text-neutral-400">
              Real people. Real fits. Real Toriwear. Tag @toriwear.apparel to be featured.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
            <span className="flex items-center text-amber-400">★★★★★</span>
            <span>4.9 / 5.0 Average Community Fit Rating</span>
          </div>
        </div>

        {/* Lookbook Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {looks.map((look) => (
            <div
              key={look.id}
              className="rounded-2xl bg-[#111219] border border-neutral-800 hover:border-neutral-600 transition-all duration-300 overflow-hidden flex flex-col justify-between group shadow-lg"
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-neutral-900">
                <img
                  src={look.image}
                  alt={look.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                <div className="absolute top-3 left-3">
                  <span className="text-[9px] font-mono font-bold tracking-wider bg-black/80 backdrop-blur-md text-white px-2 py-0.5 rounded uppercase border border-neutral-700">
                    {look.tag}
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3">
                  <div className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                    <span>{look.name}</span>
                    <span className="text-neutral-400 font-normal">({look.city})</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 ml-auto" />
                  </div>
                  <div className="text-[10px] font-mono text-[#FF2028]">
                    {look.sizeWorn}
                  </div>
                </div>
              </div>

              <div className="p-4 flex flex-col justify-between flex-grow">
                <div>
                  <div className="flex items-center text-amber-400 text-xs mb-2">
                    {'★'.repeat(look.rating)}
                  </div>
                  <p className="text-xs text-neutral-300 font-sans italic leading-relaxed">
                    “{look.review}”
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-neutral-200 line-clamp-1">
                    {look.productName}
                  </span>
                  {(() => {
                    const match = products.find((p) => p.name.toLowerCase().includes(look.productMatch.toLowerCase()));
                    if (!match) return null;
                    return (
                      <button
                        onClick={() => onOpenProductDetail(match)}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-[#FF2028] text-white transition flex-shrink-0 cursor-pointer"
                        title="Shop this look"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    );
                  })()}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
