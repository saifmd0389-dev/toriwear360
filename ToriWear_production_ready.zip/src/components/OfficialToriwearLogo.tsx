import React, { useState } from 'react';

export interface OfficialToriwearLogoProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  className?: string;
  alt?: string;
  suppressWarning?: boolean;
}

/**
 * Official TORIWEAR Logo Component
 * 
 * Strict Brand Requirements:
 * - Renders ONLY the actual official logo PNG image asset:
 *   /assets/branding/toriwear-official-logo.png (or /assets/toriwear-official-logo.png)
 * - NO text recreation, NO font substitute, NO CSS recreation, NO SVG recreation
 * - NO AI generated replacement logo
 * - Responsive proportional scaling with object-fit: contain
 */
export const OfficialToriwearLogo: React.FC<OfficialToriwearLogoProps> = ({
  className = '',
  alt = 'TORIWEAR — WEAR YOUR WORLD',
  suppressWarning = false,
  ...props
}) => {
  const [imgSrc, setImgSrc] = useState('/assets/toriwear-official-logo.png');
  const [loadError, setLoadError] = useState(false);

  const handleError = () => {
    if (imgSrc === '/assets/toriwear-official-logo.png') {
      setImgSrc('/assets/branding/toriwear-official-logo.png');
    } else {
      setLoadError(true);
    }
  };

  if (loadError) {
    if (suppressWarning) return null;
    return (
      <div 
        className={`border border-red-500/40 bg-black/90 text-white rounded p-2 text-center inline-flex flex-col items-center justify-center ${className}`}
        title="THE OFFICIAL LOGO FILE IS NOT PRESENT IN THE PROJECT ASSETS."
      >
        <span className="text-[10px] font-mono text-red-500 font-bold uppercase tracking-wider">
          THE OFFICIAL LOGO FILE IS NOT PRESENT IN THE PROJECT ASSETS.
        </span>
        <span className="text-[8px] font-mono text-neutral-400 mt-0.5">
          Expected at /assets/toriwear-official-logo.png
        </span>
      </div>
    );
  }

  return (
    <img
      src={imgSrc}
      alt={alt}
      className={`toriwear-official-logo ${className}`}
      onError={handleError}
      loading="eager"
      decoding="async"
      {...props}
    />
  );
};

export default OfficialToriwearLogo;
