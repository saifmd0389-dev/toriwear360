import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight, ChevronDown, Sparkles } from 'lucide-react';
import { ORIGINAL_CHARACTERS } from '../data/constants';
import { HeroSettings } from '../admin/types';

interface HeroProps {
  onShopMen: () => void;
  onShopKids: () => void;
  onExploreChapters?: () => void;
  onOpenSearch?: () => void;
  onOpenCombo?: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onShopMen,
  onShopKids,
  onExploreChapters,
  onOpenSearch,
  onOpenCombo,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mousePosRef = useRef({ x: 0, y: 0 });
  const mouseRafRef = useRef<number | null>(null);

  const renChar = ORIGINAL_CHARACTERS.find((c) => c.name === 'REN');
  const yukiChar = ORIGINAL_CHARACTERS.find((c) => c.name === 'YUKI');

  const [heroSettings, setHeroSettings] = useState<HeroSettings | null>(() => {
    try {
      const saved = localStorage.getItem('tori_admin_heroSettings');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    let isMounted = true;
    fetch('/api/v1/cms/hero')
      .then((res) => res.json())
      .then((json) => {
        if (isMounted && json?.data) {
          setHeroSettings(json.data);
        }
      })
      .catch(() => {});

    const handleStorage = (e?: StorageEvent | Event) => {
      try {
        if (e && 'key' in e && e.key && e.key !== 'tori_admin_heroSettings') return;
        const saved = localStorage.getItem('tori_admin_heroSettings');
        if (saved) {
          const parsed = JSON.parse(saved);
          setHeroSettings(prev => {
            if (JSON.stringify(prev) === saved) return prev;
            return parsed;
          });
        }
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleStorage);
    window.addEventListener('tori_hero_updated', handleStorage);
    window.addEventListener('tori-cms-updated', handleStorage);
    window.addEventListener('focus', handleStorage);
    return () => {
      isMounted = false;
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('tori_hero_updated', handleStorage);
      window.removeEventListener('tori-cms-updated', handleStorage);
      window.removeEventListener('focus', handleStorage);
    };
  }, []);

  // Handle smooth mouse parallax via direct CSS variables for 60fps smoothness
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    mousePosRef.current = { x, y };

    if (mouseRafRef.current === null) {
      mouseRafRef.current = requestAnimationFrame(() => {
        mouseRafRef.current = null;
        if (containerRef.current) {
          containerRef.current.style.setProperty('--mx', `${x}`);
          containerRef.current.style.setProperty('--my', `${y}`);
        }
      });
    }
  };

  // Subtle atmospheric particle canvas animation and global mouse tracking
  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      mousePosRef.current = { x, y };

      if (mouseRafRef.current === null) {
        mouseRafRef.current = requestAnimationFrame(() => {
          mouseRafRef.current = null;
          if (containerRef.current) {
            containerRef.current.style.setProperty('--mx', `${x}`);
            containerRef.current.style.setProperty('--my', `${y}`);
          }
        });
      }
    };
    window.addEventListener('mousemove', handleGlobalMouseMove, { passive: true });

    const canvas = canvasRef.current;
    if (!canvas) return () => window.removeEventListener('mousemove', handleGlobalMouseMove);
    const ctx = canvas.getContext('2d');
    if (!ctx) return () => window.removeEventListener('mousemove', handleGlobalMouseMove);

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    const particleCount = 18;
    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.2,
      vy: -0.15 - Math.random() * 0.2,
      size: Math.random() * 1.5 + 0.5,
      opacity: Math.random() * 0.35 + 0.1,
    }));

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const mx = mousePosRef.current.x;
      particles.forEach((p) => {
        p.x += p.vx + mx * 0.04;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(244, 242, 237, ${p.opacity * 0.4})`;
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (mouseRafRef.current) cancelAnimationFrame(mouseRafRef.current);
    };
  }, []);

  return (
    <section
      id="hero-section"
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative min-h-[calc(90vh+5cm)] sm:min-h-[calc(94vh+5cm)] w-full max-w-full box-border flex flex-col justify-between overflow-hidden bg-[#050505] border-b border-[#171717] select-none text-white pt-[calc(7rem+5cm)] sm:pt-[calc(8rem+5cm)]"
    >
      {/* Editorial Streetwear Atmosphere Backdrop */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden max-w-full">
        <img
          src="https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1600&auto=format&fit=crop&q=80"
          alt="TORI-WEAR Anime Streetwear Editorial"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-25 filter grayscale contrast-125 scale-105"
        />
        {/* Cinematic Scrim & Vignette Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/85 to-[#050505]/75" />
        <div className="absolute inset-0 bg-radial-at-center from-transparent via-[#050505]/60 to-[#050505]" />
      </div>

      {/* Interactive Particle Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* Subtle brand typography watermark in background */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-[0.035] overflow-hidden max-w-full px-4">
        <span className="font-heading text-[13.5vw] sm:text-[14vw] lg:text-[14.5vw] font-black tracking-tight text-[#FFFFFF] uppercase whitespace-nowrap">
          TORIWEAR
        </span>
      </div>

      {/* Editorial Left Character Anchor (Ren - Dark Shonen) - Desktop only */}
      <div
        className="absolute top-[calc(6rem+5cm)] left-6 xl:left-14 w-44 xl:w-52 aspect-[3/4] rounded-2xl overflow-hidden border border-neutral-800/90 bg-[#151515] pointer-events-none opacity-40 lg:opacity-85 transition-transform duration-300 ease-out z-10 hidden lg:block shadow-2xl"
        style={{
          transform: 'translate3d(calc(var(--mx, 0) * -14px), calc(var(--my, 0) * -10px), 0)',
        }}
      >
        <div className="relative w-full h-full p-4 flex flex-col justify-end">
          <img
            src={heroSettings?.leftCardImage || renChar?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80'}
            alt={heroSettings?.leftCardTitle || 'REN'}
            className="absolute inset-0 w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-[#FF2028] font-bold block tracking-wider uppercase mb-0.5">
              {heroSettings?.leftCardTag || 'ORIGINAL LORE · 01'}
            </span>
            <span className="text-sm font-heading font-black text-white uppercase tracking-tight block">
              {heroSettings?.leftCardTitle || 'REN // DARK SHONEN'}
            </span>
            <span className="text-[11px] text-neutral-300 font-sans block mt-1 line-clamp-2">
              {heroSettings?.leftCardDesc || '“Some people run from the darkness. He learned to walk through it.”'}
            </span>
          </div>
        </div>
      </div>

      {/* Editorial Right Character Anchor (Yuki - Cyberpunk) - Desktop only */}
      <div
        className="absolute top-[calc(6rem+5cm)] right-6 xl:right-14 w-44 xl:w-52 aspect-[3/4] rounded-2xl overflow-hidden border border-neutral-800/90 bg-[#151515] pointer-events-none opacity-40 lg:opacity-85 transition-transform duration-300 ease-out z-10 hidden lg:block shadow-2xl"
        style={{
          transform: 'translate3d(calc(var(--mx, 0) * 14px), calc(var(--my, 0) * 10px), 0)',
        }}
      >
        <div className="relative w-full h-full p-4 flex flex-col justify-end">
          <img
            src={heroSettings?.rightCardImage || yukiChar?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80'}
            alt={heroSettings?.rightCardTitle || 'YUKI'}
            className="absolute inset-0 w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="relative z-10">
            <span className="text-[10px] font-mono text-cyan-400 font-bold block tracking-wider uppercase mb-0.5">
              {heroSettings?.rightCardTag || 'ORIGINAL LORE · 02'}
            </span>
            <span className="text-sm font-heading font-black text-white uppercase tracking-tight block">
              {heroSettings?.rightCardTitle || 'YUKI // CYBERPUNK'}
            </span>
            <span className="text-[11px] text-neutral-300 font-sans block mt-1 line-clamp-2">
              {heroSettings?.rightCardDesc || '“Midnight runs through rain-slicked neon alleys of Neo Tokyo.”'}
            </span>
          </div>
        </div>
      </div>

      {/* Center Stage Container */}
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 sm:pt-16 pb-8 sm:pb-12 relative z-20 text-center flex flex-col items-center justify-center flex-grow box-border">
        {/* Pre-header Tag */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-neutral-900/90 border border-neutral-800 text-[10px] sm:text-[11px] font-mono font-medium tracking-[0.2em] sm:tracking-[0.25em] text-neutral-300 uppercase mb-4 backdrop-blur-md max-w-full">
          <span>{heroSettings?.preheaderTag || 'ORIGINAL TOKYO-INSPIRED STREETWEAR'}</span>
          <span className="text-neutral-600">·</span>
          <span className="text-red-500 font-bold">{heroSettings?.preheaderHighlight || '240 GSM'}</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-heading font-black tracking-tighter text-white uppercase leading-[0.9] max-w-3xl mx-auto my-3 sm:my-5">
          <span>WEAR YOUR </span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-amber-500">
            WORLD
          </span>
        </h1>

        {/* Supporting Description */}
        <p className="mt-4 sm:mt-6 text-sm sm:text-base text-neutral-300 font-normal w-full max-w-lg mx-auto px-2 sm:px-0 leading-relaxed tracking-wide font-sans">
          {heroSettings?.subheadline || 'Original anime-inspired streetwear created for people who live between imagination and reality.'}
        </p>

        {/* Primary Action Buttons: SHOP MEN, SHOP KIDS, TRY COMBO */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 w-full max-w-[300px] sm:max-w-none mx-auto">
          {/* Primary CTA: SHOP MEN */}
          <button
            id="hero-shop-men-btn"
            onClick={onShopMen}
            className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-neutral-200 text-black font-black text-sm uppercase tracking-wider rounded-xl transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer shadow-xl"
          >
            <span>{heroSettings?.ctaText || 'SHOP MEN'}</span>
            <ArrowRight className="w-4 h-4 text-black" />
          </button>

          {/* Secondary CTA: SHOP KIDS */}
          <button
            id="hero-shop-kids-btn"
            onClick={onShopKids}
            className="w-full sm:w-auto px-8 py-4 bg-[#151515] hover:bg-[#222222] text-white border border-neutral-700 hover:border-neutral-500 font-bold text-sm uppercase tracking-wider rounded-xl transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>{heroSettings?.secondaryCtaText || 'SHOP KIDS'}</span>
            <Sparkles className="w-4 h-4 text-sky-400" />
          </button>

          {/* Tertiary CTA: TRY COMBO TWINNING */}
          {onOpenCombo && (
            <button
              id="hero-try-combo-btn"
              onClick={onOpenCombo}
              className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-transparent hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{heroSettings?.tertiaryCtaText || 'TRY TWIN COMBO 👯'}</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">{heroSettings?.tertiaryCtaBadge || 'SAVE 10%'}</span>
            </button>
          )}
        </div>

        {/* Quality Commitments Strip */}
        <div className="mt-6 sm:mt-10 flex flex-wrap items-center justify-center gap-2 sm:gap-6 text-neutral-400 text-[10px] sm:text-[11px] font-mono tracking-wide px-2 text-center">
          <span>{heroSettings?.trustBadge1 || '240 GSM Combed Cotton'}</span>
          <span className="text-neutral-700 hidden sm:inline">·</span>
          <span>{heroSettings?.trustBadge2 || '100% Original Japanese Anime IP'}</span>
          <span className="text-neutral-700 hidden sm:inline">·</span>
          <span>{heroSettings?.trustBadge3 || 'Free Pan-India Delivery Over ₹999'}</span>
        </div>
      </div>

      {/* Bottom Scroll Indicator */}
      <div className="relative z-20 pb-4 sm:pb-5 text-center">
        <button
          onClick={() => {
            const el = document.getElementById('choose-your-world-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="inline-flex flex-col items-center gap-1 text-[10px] font-mono tracking-[0.2em] text-neutral-500 hover:text-white transition uppercase cursor-pointer"
        >
          <span>CHOOSE YOUR WORLD</span>
          <ChevronDown className="w-3.5 h-3.5 animate-bounce text-neutral-400" />
        </button>
      </div>
    </section>
  );
};
