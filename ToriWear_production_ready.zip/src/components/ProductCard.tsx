import React, { useState } from 'react';
import { Product } from '../types';
import { Heart, ShoppingBag, Eye, Star, Check, Sparkles, Maximize2, ZoomIn, Users } from 'lucide-react';
import { TwinningBadgeButton } from './TwinningBadgeButton';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onOpenPopoutZoom?: (product: Product) => void;
  onOpenCombo?: (product: Product) => void;
  onQuickAddToCart: (product: Product, size: 'S' | 'M' | 'L' | 'XL' | 'XXL' | 'XXXL') => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onSelectProduct,
  onOpenPopoutZoom,
  onOpenCombo,
  onQuickAddToCart,
}) => {
  const [selectedSize, setSelectedSize] = useState<'S' | 'M' | 'L' | 'XL' | 'XXL' | 'XXXL'>('L');
  const [addedNotice, setAddedNotice] = useState(false);
  // 3-Stage Visual State: 0 = Flat Front, 1 = Model On-Body, 2 = Animated Graphic Close-Up
  const [visualStage, setVisualStage] = useState<0 | 1 | 2>(0);

  const discountPercent = product?.originalPrice && product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAddToCart(product, selectedSize);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 1800);
  };

  const handleNextStage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setVisualStage((prev) => ((prev + 1) % 3) as 0 | 1 | 2);
  };

  // Image mapped to stage with safe fallback
  const images = Array.isArray(product?.images) && product.images.length > 0 
    ? product.images 
    : ['/assets/branding/toriwear-official-logo.png'];
  const currentImage = images[visualStage % images.length] || images[0];

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => onSelectProduct(product)}
      className="group cursor-pointer rounded-2xl bg-[#121217] border border-neutral-800/80 hover:border-neutral-700 transition-all duration-300 flex flex-col overflow-hidden hover:shadow-2xl hover:shadow-black/70 relative"
    >
      {/* Product Image Stage Area */}
      <div 
        className="relative aspect-[4/5] bg-neutral-900 overflow-hidden"
        onMouseEnter={() => setVisualStage((prev) => (prev === 0 ? 1 : prev))}
      >
        <img
          src={currentImage}
          alt={product.name}
          className="w-full h-full object-cover object-center transition-all duration-500 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/assets/branding/toriwear-official-logo.png';
          }}
        />

        {/* Subtle Category Badge Top-Left */}
        <div className="absolute top-2.5 left-2.5 z-10 flex items-center gap-1.5">
          <span className="bg-black/75 backdrop-blur-md border border-neutral-700/60 text-neutral-300 text-[9px] font-medium font-mono px-2 py-0.5 rounded uppercase tracking-wider shadow-sm">
            {product.licenseType === 'Original IP' ? 'ORIGINAL IP' : (product.department || 'TORI')}
          </span>
        </div>

        {/* Clean Wishlist / Remove Button Top-Right */}
        <button
          id={`wishlist-btn-${product.id}`}
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-md transition-all z-20 cursor-pointer shadow-lg active:scale-90 ${
            isWishlisted
              ? 'bg-[#FF2028] text-white hover:bg-red-600'
              : 'bg-black/70 text-neutral-300 hover:text-white hover:bg-black'
          }`}
          aria-label={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
          title={isWishlisted ? 'Remove from Wishlist' : 'Save to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Product Information */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-grow justify-between">
        <div>
          {/* Franchise & Fit */}
          <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400 mb-1">
            <span className="text-neutral-300 font-medium uppercase tracking-wider">{product.franchise}</span>
            <span className="text-neutral-400 text-[10px]">
              {product.fit}
            </span>
          </div>

          {/* Product Name */}
          <h3 className="font-heading text-base sm:text-lg font-bold text-white group-hover:text-[#FF2028] transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Soft Highlight Option: Try Combo Men and Kid Pair with Same Design */}
          {onOpenCombo && (
            <div className="mt-2" onClick={(e) => e.stopPropagation()}>
              <TwinningBadgeButton
                product={product}
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenCombo(product);
                }}
                theme="dark"
              />
            </div>
          )}

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1.5 text-xs text-neutral-400 font-mono">
            <div className="flex items-center text-amber-400">
              <Star className="w-3 h-3 fill-current" />
              <span className="font-semibold text-neutral-200 text-xs ml-1">{product.rating}</span>
            </div>
            <span className="text-neutral-600">·</span>
            <span className="text-[11px] text-neutral-500">({product.reviewsCount})</span>
          </div>

          {/* Pricing */}
          <div className="mt-2.5 pt-2.5 border-t border-neutral-800/80 flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="font-heading text-lg sm:text-xl font-black text-white tabular-nums">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-neutral-500 line-through tabular-nums font-mono">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            </div>

            <span className="text-[10px] font-mono font-bold text-red-400">
              {discountPercent}% OFF
            </span>
          </div>
        </div>

        {/* Size Selection & Clean Move to Bag Action */}
        <div className="mt-3 pt-3 border-t border-neutral-800/80" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 mb-1.5">
            <span>SIZE:</span>
            <span className="text-white font-bold">{selectedSize}</span>
          </div>

          <div className="flex items-center gap-1 py-0.5 mb-2.5">
            {(product.department === 'KIDS'
              ? (['4-5Y', '6-7Y', '8-9Y', '10-11Y'] as const)
              : (['S', 'M', 'L', 'XL', 'XXL'] as const)
            ).map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => setSelectedSize(sz as any)}
                className={`flex-1 py-1 rounded text-[10px] font-mono font-bold transition cursor-pointer text-center ${
                  selectedSize === sz
                    ? 'bg-[#FF2028] text-white shadow-sm'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>

          <button
            id={`quick-add-btn-${product.id}`}
            type="button"
            onClick={handleQuickAdd}
            className={`w-full py-2 px-3 rounded-xl text-xs font-bold font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer active:scale-95 ${
              addedNotice
                ? 'bg-emerald-600 text-white'
                : 'bg-white text-black hover:bg-neutral-200'
            }`}
          >
            {addedNotice ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>ADDED TO BAG</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>MOVE TO BAG</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

