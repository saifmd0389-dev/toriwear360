import React, { useState, useEffect } from 'react';
import { useAdmin } from '../AdminDataContext';
import { AdminProduct, AdminProductVariant, LicenseRightsStatus, PublishingStatus } from '../types';
import { AnimeFranchise, PopUniverse, FitType } from '../../types';
import { isValidProductImageUrl } from '../../utils/productFilters';
import { MEN_WORLDS, KIDS_WORLDS } from '../../data/constants';
import { 
  X, 
  Package, 
  DollarSign, 
  Layers, 
  Image as ImageIcon, 
  ShieldCheck, 
  AlertTriangle, 
  Check, 
  Plus, 
  Trash2,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface ProductEditorModalProps {
  product: AdminProduct | null; // If null, create mode
  isOpen: boolean;
  onClose: () => void;
}

export const ProductEditorModal: React.FC<ProductEditorModalProps> = ({ product, isOpen, onClose }) => {
  const { addProduct, updateProduct, settings } = useAdmin();

  const [activeTab, setActiveTab] = useState<'GENERAL' | 'PRICING' | 'VARIANTS' | 'MEDIA'>('GENERAL');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  
  // Form state
  const [isSaving, setIsSaving] = useState(false);
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [department, setDepartment] = useState<'MEN' | 'KIDS'>('MEN');
  const [world, setWorld] = useState<string>('DARK SHONEN');
  const [franchise, setFranchise] = useState<AnimeFranchise>('Toriwear Originals');
  const [universe, setUniverse] = useState<PopUniverse>('ORIGINALS');
  const [category, setCategory] = useState<'T-Shirts' | 'Oversized Tees' | 'Hoodies' | 'Cargoes' | 'Accessories'>('Oversized Tees');
  const [fit, setFit] = useState<FitType>('Oversized');
  const [gsm, setGsm] = useState(240);
  const [fabric, setFabric] = useState('100% Combed Heavyweight Cotton');
  const [description, setDescription] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [storyQuote, setStoryQuote] = useState('');
  const [drop, setDrop] = useState('DROP 002 — SHINOBI');
  
  // Pricing & IP
  const [price, setPrice] = useState(1199);
  const [mrp, setMrp] = useState(1599);
  const [costPrice, setCostPrice] = useState(450);
  const [gstRate, setGstRate] = useState(5);
  const [licenseRightsStatus, setLicenseRightsStatus] = useState<LicenseRightsStatus>('Owned IP');

  // Media
  const [imageUrl1, setImageUrl1] = useState('');
  const [imageUrl2, setImageUrl2] = useState('');
  const [publishingStatus, setPublishingStatus] = useState<PublishingStatus>('PUBLISHED');

  // Variants
  const [variants, setVariants] = useState<AdminProductVariant[]>([]);

  useEffect(() => {
    if (product) {
      setName(product.name);
      setSku(product.sku);
      const dept = product.department || (product.universe === 'KIDS' ? 'KIDS' : 'MEN');
      setDepartment(dept);
      setWorld(product.world || (dept === 'KIDS' ? 'CUTE ADVENTURE' : 'DARK SHONEN'));
      setFranchise(product.franchise || 'Toriwear Originals');
      setUniverse(product.universe || (dept === 'KIDS' ? 'KIDS' : 'ORIGINALS'));
      setCategory(product.category);
      setFit(product.fit);
      setGsm(product.gsm);
      setFabric(product.fabric);
      setDescription(product.description);
      setShortDescription(product.shortDescription);
      setStoryQuote(product.storyQuote || '');
      setDrop(product.drop);
      setPrice(product.price);
      setMrp(product.mrp);
      setCostPrice(product.costPrice);
      setGstRate(product.gstRate);
      setLicenseRightsStatus(product.licenseRightsStatus);
      setImageUrl1(product.images[0] || '');
      setImageUrl2(product.images[1] || '');
      setPublishingStatus(product.publishingStatus);
      setVariants(product.variants || []);
    } else {
      // New product defaults
      setName('');
      setSku(`TORI-${Date.now().toString().slice(-4)}`);
      setDepartment('MEN');
      setWorld('DARK SHONEN');
      setFranchise('Toriwear Originals');
      setUniverse('ORIGINALS');
      setCategory('Oversized Tees');
      setFit('Oversized');
      setGsm(240);
      setFabric('100% Combed Heavyweight Cotton');
      setDescription('Crafted from premium 240 GSM combed cotton with high-density screen printing.');
      setShortDescription('Heavyweight drop-shoulder oversized streetwear silhouette.');
      setStoryQuote('Wear Your World.');
      setDrop('DROP 002 — SHINOBI');
      setPrice(1199);
      setMrp(1599);
      setCostPrice(420);
      setGstRate(5);
      setLicenseRightsStatus('Owned IP');
      setImageUrl1('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80');
      setImageUrl2('https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=900&auto=format&fit=crop&q=80');
      setPublishingStatus('PUBLISHED');
      setVariants([
        { id: `var-s-${Date.now()}`, sku: 'TORI-NEW-S', size: 'S', colorName: 'Obsidian Black', colorHex: '#111115', price: 1199, stock: 20, reserved: 0, barcode: '8901001', weightGrams: 320 },
        { id: `var-m-${Date.now()}`, sku: 'TORI-NEW-M', size: 'M', colorName: 'Obsidian Black', colorHex: '#111115', price: 1199, stock: 35, reserved: 0, barcode: '8901002', weightGrams: 340 },
        { id: `var-l-${Date.now()}`, sku: 'TORI-NEW-L', size: 'L', colorName: 'Obsidian Black', colorHex: '#111115', price: 1199, stock: 40, reserved: 0, barcode: '8901003', weightGrams: 360 },
        { id: `var-xl-${Date.now()}`, sku: 'TORI-NEW-XL', size: 'XL', colorName: 'Obsidian Black', colorHex: '#111115', price: 1199, stock: 25, reserved: 0, barcode: '8901004', weightGrams: 380 },
      ]);
    }
    setFormError(null);
    setFormSuccess(null);
    setActiveTab('GENERAL');
  }, [product, isOpen]);

  // Adjust defaults when department toggles in Create Mode
  const handleDepartmentChange = (newDept: 'MEN' | 'KIDS') => {
    setDepartment(newDept);
    if (!product) {
      if (newDept === 'KIDS') {
        setWorld('CUTE ADVENTURE');
        setUniverse('KIDS');
        setGsm(180);
        setFit('Comfort Fit');
        setImageUrl1('https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900&auto=format&fit=crop&q=80');
        setVariants([
          { id: `var-45y-${Date.now()}`, sku: `${sku}-4-5Y`, size: '4–5Y' as any, colorName: 'Solar Yellow', colorHex: '#eab308', price, stock: 20, reserved: 0, barcode: '8902001', weightGrams: 180 },
          { id: `var-67y-${Date.now()}`, sku: `${sku}-6-7Y`, size: '6–7Y' as any, colorName: 'Solar Yellow', colorHex: '#eab308', price, stock: 30, reserved: 0, barcode: '8902002', weightGrams: 200 },
          { id: `var-89y-${Date.now()}`, sku: `${sku}-8-9Y`, size: '8–9Y' as any, colorName: 'Solar Yellow', colorHex: '#eab308', price, stock: 25, reserved: 0, barcode: '8902003', weightGrams: 220 },
        ]);
      } else {
        setWorld('DARK SHONEN');
        setUniverse('ORIGINALS');
        setGsm(240);
        setFit('Oversized');
        setImageUrl1('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80');
        setVariants([
          { id: `var-s-${Date.now()}`, sku: `${sku}-S`, size: 'S', colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 20, reserved: 0, barcode: '8901001', weightGrams: 320 },
          { id: `var-m-${Date.now()}`, sku: `${sku}-M`, size: 'M', colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 35, reserved: 0, barcode: '8901002', weightGrams: 340 },
          { id: `var-l-${Date.now()}`, sku: `${sku}-L`, size: 'L', colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 40, reserved: 0, barcode: '8901003', weightGrams: 360 },
          { id: `var-xl-${Date.now()}`, sku: `${sku}-XL`, size: 'XL', colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 25, reserved: 0, barcode: '8901004', weightGrams: 380 },
        ]);
      }
    }
  };

  if (!isOpen) return null;

  const autoDiscount = mrp > 0 ? Math.round(((mrp - price) / mrp) * 100) : 0;
  const estimatedProfit = price - costPrice;
  const marginPercent = price > 0 ? Math.round((estimatedProfit / price) * 100) : 0;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validation checks
    const cleanName = name.trim();
    if (!cleanName) {
      setFormError('Product Name / Title is required.');
      setActiveTab('GENERAL');
      return;
    }

    const cleanSku = sku.trim();
    if (!cleanSku) {
      setFormError('Base SKU is required (e.g. TORI-TSHIRT-01).');
      setActiveTab('GENERAL');
      return;
    }

    if (!price || price <= 0) {
      setFormError('Selling price must be greater than ₹0.');
      setActiveTab('PRICING');
      return;
    }

    // Default streetwear fallback image if empty
    const defaultImage = department === 'KIDS'
      ? 'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900&auto=format&fit=crop&q=80'
      : 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80';

    const images = [imageUrl1, imageUrl2].map(img => img.trim()).filter(Boolean);
    const validImages = images.filter(isValidProductImageUrl);
    const finalImages = validImages.length > 0 ? validImages : [imageUrl1.trim() || defaultImage];

    // Ensure variants exist
    const finalVariants = variants.length > 0 ? variants : [
      { id: `var-s-${Date.now()}`, sku: `${cleanSku}-S`, size: 'S' as const, colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 20, reserved: 0, barcode: `890${Date.now().toString().slice(-6)}1`, weightGrams: 320 },
      { id: `var-m-${Date.now()}`, sku: `${cleanSku}-M`, size: 'M' as const, colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 35, reserved: 0, barcode: `890${Date.now().toString().slice(-6)}2`, weightGrams: 340 },
      { id: `var-l-${Date.now()}`, sku: `${cleanSku}-L`, size: 'L' as const, colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 40, reserved: 0, barcode: `890${Date.now().toString().slice(-6)}3`, weightGrams: 360 },
      { id: `var-xl-${Date.now()}`, sku: `${cleanSku}-XL`, size: 'XL' as const, colorName: 'Obsidian Black', colorHex: '#111115', price, stock: 25, reserved: 0, barcode: `890${Date.now().toString().slice(-6)}4`, weightGrams: 380 },
    ];

    const productPayload: Partial<AdminProduct> = {
      name: cleanName,
      sku: cleanSku,
      department,
      world,
      franchise: franchise || (world as any) || 'Toriwear Originals',
      universe,
      category,
      fit,
      gsm,
      fabric,
      description: description.trim() || 'Premium heavyweight streetwear silhouette by TORIWEAR.',
      shortDescription: shortDescription.trim() || `${gsm} GSM combed cotton streetwear fit.`,
      storyQuote: storyQuote.trim() || 'Wear Your World.',
      drop: drop.trim() || 'DROP 002 — SHINOBI',
      price: Number(price),
      mrp: Number(mrp) || Math.round(Number(price) * 1.3),
      costPrice: Number(costPrice) || 450,
      discountPercent: autoDiscount,
      gstRate: Number(gstRate) || 5,
      licenseRightsStatus,
      images: finalImages,
      publishingStatus,
      variants: finalVariants,
    };

    setIsSaving(true);
    try {
      if (product) {
        const res = await updateProduct(product.id, productPayload);
        if (!res.success) {
          setFormError(res.message || 'Failed to update product in database.');
          setIsSaving(false);
          return;
        }
        setIsSaving(false);
        onClose();
      } else {
        const res = await addProduct(productPayload);
        if (!res.success) {
          setFormError(res.message || 'Failed to persist product to database.');
          setIsSaving(false);
          return;
        }
        setIsSaving(false);
        onClose();
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred while saving the product to the database.');
      setIsSaving(false);
    }
  };

  const handleUpdateVariantStock = (idx: number, newStock: number) => {
    setVariants(prev => prev.map((v, i) => i === idx ? { ...v, stock: Math.max(0, newStock) } : v));
  };

  const handleAddSizeVariant = (sizeLabel: string) => {
    const existing = variants.find(v => v.size === sizeLabel);
    if (existing) {
      setFormError(`Size ${sizeLabel} already exists in variants.`);
      return;
    }
    setVariants(prev => [
      ...prev,
      {
        id: `var-${sizeLabel.toLowerCase()}-${Date.now()}`,
        sku: `${sku || 'TORI'}-${sizeLabel}`,
        size: sizeLabel as any,
        colorName: 'Obsidian Black',
        colorHex: '#111115',
        price,
        stock: 25,
        reserved: 0,
        barcode: `890${Date.now().toString().slice(-6)}`,
        weightGrams: department === 'KIDS' ? 200 : 340,
      }
    ]);
  };

  const currentWorlds = department === 'KIDS' ? KIDS_WORLDS : MEN_WORLDS;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="w-full max-w-4xl bg-[#14141c] border border-neutral-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-[#181824]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-600/10 text-red-500 border border-red-500/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                {product ? `Edit Product: ${product.name}` : 'Create New Streetwear Product'}
              </h2>
              <p className="text-xs text-neutral-400">
                Configure specs, IP licensing, pricing tiers, and size inventory.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-neutral-800 bg-neutral-900/40 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('GENERAL')}
            className={`py-3 px-4 border-b-2 font-medium flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'GENERAL'
                ? 'border-red-500 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>1. General Specs</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PRICING')}
            className={`py-3 px-4 border-b-2 font-medium flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'PRICING'
                ? 'border-red-500 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>2. Pricing & IP Rights</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('VARIANTS')}
            className={`py-3 px-4 border-b-2 font-medium flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'VARIANTS'
                ? 'border-red-500 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>3. Sizes & Inventory ({variants.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('MEDIA')}
            className={`py-3 px-4 border-b-2 font-medium flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'MEDIA'
                ? 'border-red-500 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>4. Media & Publishing</span>
          </button>
        </div>

        {/* Modal Body & Form */}
        <form noValidate onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* In-Modal Error Banner */}
          {formError && (
            <div className="p-3.5 bg-red-950/70 border border-red-800 rounded-xl text-red-200 text-xs flex items-center gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <div className="flex-1 font-medium">{formError}</div>
              <button
                type="button"
                onClick={() => setFormError(null)}
                className="text-red-400 hover:text-white text-xs cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* TAB 1: GENERAL SPECS */}
          <div className={activeTab === 'GENERAL' ? 'space-y-4' : 'hidden'}>
            {/* Department Switcher */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                Department Target *
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleDepartmentChange('MEN')}
                  className={`p-3 rounded-xl border text-xs text-left cursor-pointer transition-all flex items-center justify-between ${
                    department === 'MEN'
                      ? 'border-red-500 bg-red-600/15 text-white font-bold ring-1 ring-red-500'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">Men's Streetwear</div>
                    <div className="text-[10px] text-neutral-400 mt-0.5">240 GSM Oversized & Drop-Shoulder</div>
                  </div>
                  <span className="text-lg">🔥</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDepartmentChange('KIDS')}
                  className={`p-3 rounded-xl border text-xs text-left cursor-pointer transition-all flex items-center justify-between ${
                    department === 'KIDS'
                      ? 'border-sky-500 bg-sky-600/15 text-white font-bold ring-1 ring-sky-500'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div>
                    <div className="font-bold text-sm">Kids' Anime Apparel</div>
                    <div className="text-[10px] text-neutral-400 mt-0.5">180 GSM Soft Combed Cotton (4Y–9Y)</div>
                  </div>
                  <span className="text-lg">👶</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Product Title *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Shadow Monarch Oversized Tee"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Base SKU *
                </label>
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="TORI-TSHIRT-01"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Target World / Fictional Realm *
                </label>
                <select
                  value={world}
                  onChange={(e) => setWorld(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500 cursor-pointer"
                >
                  {currentWorlds.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.subtitle})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Franchise / Saga
                </label>
                <input
                  type="text"
                  value={franchise}
                  onChange={(e) => setFranchise(e.target.value as AnimeFranchise)}
                  placeholder="Solo Leveling, Naruto, etc."
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Drop Series
                </label>
                <input
                  type="text"
                  value={drop}
                  onChange={(e) => setDrop(e.target.value)}
                  placeholder="DROP 002 — SHINOBI"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Fabric GSM Weight
                </label>
                <input
                  type="number"
                  value={gsm}
                  onChange={(e) => setGsm(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Fit Type
                </label>
                <input
                  type="text"
                  value={fit}
                  onChange={(e) => setFit(e.target.value as FitType)}
                  placeholder="Oversized, Relaxed, etc."
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Fabric Composition
                </label>
                <input
                  type="text"
                  value={fabric}
                  onChange={(e) => setFabric(e.target.value)}
                  placeholder="100% Combed Heavyweight Cotton"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Product Story Quote (Character Lore)
              </label>
              <input
                type="text"
                value={storyQuote}
                onChange={(e) => setStoryQuote(e.target.value)}
                placeholder="e.g. Arise. Shadows obey only the true monarch."
                className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Full Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Product narrative, fabric feel, printing technique, and styling notes..."
                className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500 resize-none"
              />
            </div>
          </div>

          {/* TAB 2: PRICING & IP RIGHTS */}
          <div className={activeTab === 'PRICING' ? 'space-y-5' : 'hidden'}>
            {/* Financial calculations preview bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-neutral-900/80 border border-neutral-800">
              <div>
                <div className="text-[10px] uppercase text-neutral-400 font-semibold">Selling Price</div>
                <div className="text-base font-bold text-white font-mono">₹{price}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-neutral-400 font-semibold">Discount vs MRP</div>
                <div className="text-base font-bold text-emerald-400 font-mono">{autoDiscount}% OFF</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-neutral-400 font-semibold">Gross Profit / Unit</div>
                <div className="text-base font-bold text-blue-400 font-mono">₹{estimatedProfit}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-neutral-400 font-semibold">Operating Margin</div>
                <div className="text-base font-bold text-purple-400 font-mono">{marginPercent}%</div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Selling Price (₹ INR) *
                </label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  MRP / List Price (₹ INR)
                </label>
                <input
                  type="number"
                  value={mrp}
                  onChange={(e) => setMrp(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Cost Price (COGS in ₹)
                </label>
                <input
                  type="number"
                  value={costPrice}
                  onChange={(e) => setCostPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  Apparel GST Slab
                </label>
                <select
                  value={gstRate}
                  onChange={(e) => setGstRate(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500 cursor-pointer"
                >
                  <option value={5}>5% GST (Apparel under ₹1,000 / Standard)</option>
                  <option value={12}>12% GST (Apparel over ₹1,000 / Premium)</option>
                  <option value={0}>0% Tax Exempt</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                  IP & Commercial License Rights Status *
                </label>
                <select
                  value={licenseRightsStatus}
                  onChange={(e) => setLicenseRightsStatus(e.target.value as LicenseRightsStatus)}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500 cursor-pointer"
                >
                  <option value="Owned IP">Owned IP (100% Original Toriwear Artwork)</option>
                  <option value="Licensed">Licensed Commercial Partner</option>
                  <option value="Pending Authorization">Pending Authorization (Legal Review)</option>
                  <option value="Not Authorized">Not Authorized (Blocked from Sale)</option>
                </select>
              </div>
            </div>

            {/* IP Safeguard Banner */}
            {licenseRightsStatus === 'Not Authorized' && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 flex-shrink-0 text-red-400 mt-0.5" />
                <div>
                  <span className="font-bold block text-red-200">Intellectual Property Safeguard Active:</span>
                  Products marked as "Not Authorized" cannot be published or sold on the live storefront to ensure strict copyright and trademark compliance.
                </div>
              </div>
            )}

            {licenseRightsStatus === 'Owned IP' && (
              <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-xs text-purple-300 flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 flex-shrink-0 text-purple-400" />
                <span>100% Owned Toriwear Intellectual Property. Cleared for worldwide D2C and wholesale.</span>
              </div>
            )}
          </div>

          {/* TAB 3: SIZES & VARIANTS */}
          <div className={activeTab === 'VARIANTS' ? 'space-y-4' : 'hidden'}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Size Variants & On-Hand Inventory
                </h3>
                <p className="text-[11px] text-neutral-400">
                  Total stock: {variants.reduce((a, b) => a + (b.stock || 0), 0)} units across {variants.length} sizes
                </p>
              </div>

              {/* Quick Add Size Buttons */}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[10px] text-neutral-400 font-mono mr-1">Quick Add:</span>
                {(department === 'KIDS' ? ['3–4Y', '4–5Y', '6–7Y', '8–9Y', '10–11Y'] : ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL']).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => handleAddSizeVariant(sz)}
                    className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[10px] font-mono font-bold cursor-pointer transition border border-neutral-700"
                  >
                    +{sz}
                  </button>
                ))}
              </div>
            </div>

            <div className="border border-neutral-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs text-neutral-300">
                <thead className="bg-neutral-900 text-neutral-400 uppercase text-[10px] tracking-wider border-b border-neutral-800">
                  <tr>
                    <th className="p-3">Size</th>
                    <th className="p-3">Variant SKU</th>
                    <th className="p-3">Color</th>
                    <th className="p-3">Stock Units</th>
                    <th className="p-3">Weight (g)</th>
                    <th className="p-3 text-right">Remove</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800">
                  {variants.map((v, idx) => (
                    <tr key={v.id} className="hover:bg-neutral-800/30">
                      <td className="p-3 font-bold text-white font-mono">{v.size}</td>
                      <td className="p-3 font-mono text-neutral-400">{v.sku}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <span 
                            className="w-3.5 h-3.5 rounded-full border border-neutral-700" 
                            style={{ backgroundColor: v.colorHex }}
                          />
                          <span>{v.colorName}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <input
                          type="number"
                          value={v.stock}
                          onChange={(e) => handleUpdateVariantStock(idx, Number(e.target.value))}
                          className="w-20 px-2 py-1 bg-neutral-900 border border-neutral-700 rounded text-white font-mono text-xs focus:outline-none focus:border-red-500"
                        />
                      </td>
                      <td className="p-3 font-mono text-neutral-400">{v.weightGrams}g</td>
                      <td className="p-3 text-right">
                        <button
                          type="button"
                          onClick={() => setVariants(prev => prev.filter((_, i) => i !== idx))}
                          className="p-1 rounded text-neutral-500 hover:text-red-400 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* TAB 4: MEDIA & PUBLISHING */}
          <div className={activeTab === 'MEDIA' ? 'space-y-5' : 'hidden'}>
            <div className="p-3 bg-neutral-900/90 border border-neutral-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span className="font-bold">HD 100% ZOOM & STOREFRONT READY</span>
              </div>
              <span className="text-[11px] font-mono text-neutral-400">
                Web URLs (http/https), uploads, or local assets
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Primary Product Image (URL or File Upload) *
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={imageUrl1}
                  onChange={(e) => setImageUrl1(e.target.value)}
                  placeholder="https://images.unsplash.com/... or upload file"
                  className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
                <label className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-mono font-bold cursor-pointer transition flex items-center gap-1.5 whitespace-nowrap border border-neutral-700">
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Upload HD</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (typeof reader.result === 'string') setImageUrl1(reader.result);
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                Secondary / Detail Showcase Image (URL or File Upload)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={imageUrl2}
                  onChange={(e) => setImageUrl2(e.target.value)}
                  placeholder="https://images.unsplash.com/... or upload file"
                  className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
                />
                <label className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-mono font-bold cursor-pointer transition flex items-center gap-1.5 whitespace-nowrap border border-neutral-700">
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Upload HD</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          if (typeof reader.result === 'string') setImageUrl2(reader.result);
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              </div>
            </div>

            {/* Image Preview Thumbnails */}
            <div className="flex gap-3">
              {imageUrl1 && (
                <div className="relative group">
                  <img
                    src={imageUrl1}
                    alt="Primary Preview"
                    className="w-24 h-24 rounded-xl object-cover border border-neutral-700 bg-neutral-900"
                  />
                  <span className="absolute bottom-1 left-1 bg-black/80 text-[10px] text-white px-1.5 rounded font-mono">
                    Primary
                  </span>
                </div>
              )}
              {imageUrl2 && (
                <div className="relative group">
                  <img
                    src={imageUrl2}
                    alt="Secondary Preview"
                    className="w-24 h-24 rounded-xl object-cover border border-neutral-700 bg-neutral-900"
                  />
                  <span className="absolute bottom-1 left-1 bg-black/80 text-[10px] text-white px-1.5 rounded font-mono">
                    Detail
                  </span>
                </div>
              )}
            </div>

            {/* Publishing Status Control */}
            <div className="pt-4 border-t border-neutral-800">
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                Publishing Lifecycle Status *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {(['DRAFT', 'REVIEW', 'APPROVED', 'SCHEDULED', 'PUBLISHED', 'ARCHIVED'] as PublishingStatus[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setPublishingStatus(st)}
                    className={`p-3 rounded-xl border text-xs text-left cursor-pointer transition-all ${
                      publishingStatus === st
                        ? 'border-red-500 bg-red-600/10 text-white font-semibold ring-1 ring-red-500'
                        : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="uppercase tracking-wider font-mono text-[11px] font-bold">{st}</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">
                      {st === 'PUBLISHED' ? 'Live on storefront immediately' : st === 'DRAFT' ? 'Internal only' : st === 'SCHEDULED' ? 'Scheduled drop' : st === 'ARCHIVED' ? 'Hidden / Archived' : 'Verification step'}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-4 border-t border-neutral-800 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className={`px-5 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-xs transition-colors flex items-center gap-2 shadow-md shadow-red-600/20 ${isSaving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
            >
              <Check className="w-4 h-4" />
              <span>{isSaving ? 'Saving to Database...' : product ? 'Save Product Changes' : 'Create & Publish Product'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
