import React, { useState, useEffect } from 'react';
import { useAdmin } from '../AdminDataContext';
import { WebsiteSection, HeroSettings } from '../types';
import { 
  Layout, 
  Eye, 
  EyeOff, 
  ArrowUp, 
  ArrowDown, 
  Save, 
  Monitor, 
  Smartphone, 
  Sparkles, 
  Sliders, 
  Image as ImageIcon,
  CheckCircle2,
  Shield,
  Upload,
  AlertCircle,
  FileImage,
  RotateCcw,
  Download,
  Megaphone,
  FolderTree,
  BookOpen,
  Compass
} from 'lucide-react';
import { OfficialToriwearLogo } from '../../components/OfficialToriwearLogo';
import { 
  loadFrontPageCmsData, 
  saveFrontPageCmsData, 
  fetchFrontPageCmsDataFromServer,
  saveFrontPageCmsDataToServer,
  DEFAULT_FRONTPAGE_CMS_DATA, 
  FrontPageCmsData 
} from '../data/frontPageCmsData';
import { CmsAdsManager } from './cms/CmsAdsManager';
import { CmsTabsManager } from './cms/CmsTabsManager';
import { CmsContentManager } from './cms/CmsContentManager';

export const WebsiteCMSView: React.FC = () => {
  const { 
    websiteSections, 
    saveWebsiteSections, 
    heroSettings, 
    saveHeroSettings,
    settings,
    updateSettings,
    showToast
  } = useAdmin();

  const [activeTab, setActiveTab] = useState<'SECTIONS' | 'HERO' | 'ADS_PROMOS' | 'TABS_NAV' | 'CONTENT_VAULT' | 'BRAND_LOCK'>('SECTIONS');
  const [cmsData, setCmsData] = useState<FrontPageCmsData>(() => loadFrontPageCmsData());
  const [sections, setSections] = useState<WebsiteSection[]>(() => {
    const loaded = loadFrontPageCmsData();
    return loaded.sections && loaded.sections.length > 0 ? loaded.sections : websiteSections;
  });
  const [hero, setHero] = useState<HeroSettings>(() => {
    const loaded = loadFrontPageCmsData();
    return loaded.hero || heroSettings;
  });
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [logoStatus, setLogoStatus] = useState<{ exists: boolean; sizeBytes: number } | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  // Authoritative server fetch on mount
  useEffect(() => {
    let isMounted = true;
    fetchFrontPageCmsDataFromServer().then((serverData) => {
      if (isMounted && serverData) {
        setCmsData(serverData);
        if (serverData.sections && serverData.sections.length > 0) {
          setSections(serverData.sections);
        }
        if (serverData.hero) {
          setHero(serverData.hero);
        }
      }
    }).catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  const handleSaveAllFrontPageChanges = async () => {
    const updatedData: FrontPageCmsData = {
      ...cmsData,
      sections,
      hero,
    };
    setCmsData(updatedData);
    saveWebsiteSections(sections);
    saveHeroSettings(hero);
    await saveFrontPageCmsDataToServer(updatedData);
    showToast('All Front Page configurations successfully published & saved!');
  };

  const handleResetDefaults = async () => {
    setCmsData(DEFAULT_FRONTPAGE_CMS_DATA);
    setSections(DEFAULT_FRONTPAGE_CMS_DATA.sections);
    setHero(DEFAULT_FRONTPAGE_CMS_DATA.hero);
    saveWebsiteSections(DEFAULT_FRONTPAGE_CMS_DATA.sections);
    saveHeroSettings(DEFAULT_FRONTPAGE_CMS_DATA.hero);
    await saveFrontPageCmsDataToServer(DEFAULT_FRONTPAGE_CMS_DATA);
    showToast('Reset all front page configurations to factory defaults.');
  };

  const handleExportJson = () => {
    const toExport = { ...cmsData, sections, hero };
    const blob = new Blob([JSON.stringify(toExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `toriwear-frontpage-cms-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showToast('Exported front page CMS backup JSON.');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (parsed) {
          setCmsData(parsed);
          if (parsed.sections) setSections(parsed.sections);
          if (parsed.hero) setHero(parsed.hero);
          saveFrontPageCmsData(parsed);
          if (parsed.sections) saveWebsiteSections(parsed.sections);
          if (parsed.hero) saveHeroSettings(parsed.hero);
          showToast('Imported front page configuration from JSON!');
        }
      } catch (err) {
        showToast('Failed to parse CMS JSON file.');
      }
    };
    reader.readAsText(file);
  };

  const fetchLogoStatus = async () => {
    try {
      const res = await fetch('/api/brand/logo-status');
      const data = await res.json();
      if (data.success) {
        setLogoStatus(data.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLogoStatus();
  }, []);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingLogo(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const res = await fetch('/api/brand/upload-logo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ imageBase64: base64 }),
        });
        const json = await res.json();
        if (json.success) {
          showToast('Official TORIWEAR Logo saved directly to /public/assets/toriwear-official-logo.png!');
          await fetchLogoStatus();
        } else {
          showToast(json.error || 'Failed to save logo asset');
        }
      } catch (err: any) {
        showToast(err.message || 'Upload error');
      } finally {
        setUploadingLogo(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleToggleSection = (id: string) => {
    setSections(prev => prev.map(s => s.id === id ? { ...s, isEnabled: !s.isEnabled } : s));
  };

  const handleMoveSection = (index: number, direction: 'UP' | 'DOWN') => {
    const targetIdx = direction === 'UP' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= sections.length) return;

    const updated = [...sections];
    const temp = updated[index];
    updated[index] = updated[targetIdx];
    updated[targetIdx] = temp;

    // update order numbers
    updated.forEach((s, i) => { s.order = i + 1; });
    setSections(updated);
  };

  const handleSaveSections = () => {
    saveWebsiteSections(sections);
  };

  const handleSaveHero = (e: React.FormEvent) => {
    e.preventDefault();
    saveHeroSettings(hero);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Layout className="w-5 h-5 text-indigo-500" />
            <span>Storefront CMS & Interactive Scene Architect</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Configure homepage sections order, hero billboard copy, video assets, and announcement bars.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs font-mono transition flex items-center gap-1.5 cursor-pointer"
            title="Reset all front page content to factory defaults"
          >
            <RotateCcw className="w-3.5 h-3.5 text-neutral-400" />
            <span>Reset Defaults</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs font-mono transition flex items-center gap-1.5 cursor-pointer"
            title="Backup all front page CMS configuration as JSON"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            <span>Backup JSON</span>
          </button>

          <label className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 text-xs font-mono transition flex items-center gap-1.5 cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-amber-400" />
            <span>Restore JSON</span>
            <input
              type="file"
              accept="application/json"
              onChange={handleImportJson}
              className="hidden"
            />
          </label>

          <button
            type="button"
            onClick={handleSaveAllFrontPageChanges}
            className="px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition flex items-center gap-1.5 shadow-md shadow-red-950/60 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save All Front Page Changes</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 text-xs overflow-x-auto">
        <button
          onClick={() => setActiveTab('SECTIONS')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'SECTIONS' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <Layout className="w-3.5 h-3.5" />
          <span>Sections Architecture ({sections.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('HERO')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'HERO' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Hero & Spotlight Scene</span>
        </button>

        <button
          onClick={() => setActiveTab('ADS_PROMOS')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'ADS_PROMOS' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5 text-amber-400" />
          <span>Ads & Banners ({cmsData.advertisements.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('TABS_NAV')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'TABS_NAV' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <FolderTree className="w-3.5 h-3.5 text-blue-400" />
          <span>Tabs & Navigation ({cmsData.tabs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('CONTENT_VAULT')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'CONTENT_VAULT' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
          <span>Content Hub (Realms, Lore, Characters)</span>
        </button>

        <button
          onClick={() => setActiveTab('BRAND_LOCK')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'BRAND_LOCK' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>Master Logo Lock</span>
        </button>
      </div>

      {/* TAB 1: HOMEPAGE SECTIONS ARCHITECTURE */}
      {activeTab === 'SECTIONS' && (
        <div className="space-y-4">
          <div className="bg-[#14141c] border border-neutral-800 rounded-2xl p-4 text-xs text-neutral-400">
            Drag or use arrow buttons to rearrange the customer storefront render order. Toggle eye icon to show/hide sections.
          </div>

          <div className="space-y-2">
            {sections.map((sec, idx) => (
              <div
                key={sec.id}
                className={`p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                  sec.isEnabled 
                    ? 'bg-[#14141c] border-neutral-800 text-white' 
                    : 'bg-neutral-950/60 border-neutral-900 text-neutral-500 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded bg-neutral-900 border border-neutral-800 flex items-center justify-center font-mono text-xs text-neutral-400 font-bold">
                    {idx + 1}
                  </span>
                  <div>
                    <div className="font-bold text-sm">{sec.title}</div>
                    <div className="text-[11px] text-neutral-400 font-mono">{sec.type}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {(sec.title?.includes('Choose Your World') || sec.type === 'choose_your_world' || sec.id === 'sec-4') && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('CONTENT_VAULT')}
                      className="px-2.5 py-1 rounded-lg bg-red-600/20 hover:bg-red-600/30 text-red-400 font-mono text-[11px] font-bold flex items-center gap-1.5 cursor-pointer border border-red-500/30 transition shadow-sm"
                      title="Edit the 5 World cards in Content Hub"
                    >
                      <Compass className="w-3.5 h-3.5 text-red-400" />
                      <span>Edit 5 World Cards</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleToggleSection(sec.id)}
                    className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                      sec.isEnabled 
                        ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10' 
                        : 'border-neutral-800 text-neutral-500 bg-neutral-900'
                    }`}
                    title={sec.isEnabled ? 'Section is Visible' : 'Section is Hidden'}
                  >
                    {sec.isEnabled ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>

                  <button
                    disabled={idx === 0}
                    onClick={() => handleMoveSection(idx, 'UP')}
                    className="p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>

                  <button
                    disabled={idx === sections.length - 1}
                    onClick={() => handleMoveSection(idx, 'DOWN')}
                    className="p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: HERO SCENE & BILLBOARD EDITOR */}
      {activeTab === 'HERO' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Form */}
          <form onSubmit={handleSaveHero} className="lg:col-span-7 bg-[#14141c] border border-neutral-800 rounded-2xl p-5 space-y-5 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div>
                <h3 className="font-bold text-white text-sm">Hero Scene &amp; Spotlight Cards Configuration</h3>
                <p className="text-[11px] text-neutral-400 mt-0.5">Customize the main hero billboard, the two side spotlight boxes, and the CTA buttons.</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-red-600/20 text-red-400 border border-red-500/30">
                HOMEPAGE HERO
              </span>
            </div>

            {/* SECTION A: MAIN HEADLINE & BANNER */}
            <div className="space-y-3 p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <span className="font-bold text-neutral-200 text-xs uppercase tracking-wider block">
                1. Center Billboard Headline &amp; Pill Tag
              </span>

              {/* Circled Top: Preheader Pill Badge */}
              <div className="p-2.5 rounded-lg bg-neutral-950/70 border border-neutral-800 space-y-2">
                <span className="text-[11px] font-bold text-red-400 uppercase tracking-wider block">
                  Top Pill Badge (Circled in Red)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[10px]">
                      Tag Label
                    </label>
                    <input
                      type="text"
                      value={hero.preheaderTag || 'ORIGINAL TOKYO-INSPIRED STREETWEAR'}
                      onChange={(e) => setHero(prev => ({ ...prev, preheaderTag: e.target.value }))}
                      placeholder="e.g. ORIGINAL TOKYO-INSPIRED STREETWEAR"
                      className="w-full px-2.5 py-1.5 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[10px]">
                      Red Highlight Text
                    </label>
                    <input
                      type="text"
                      value={hero.preheaderHighlight || '240 GSM'}
                      onChange={(e) => setHero(prev => ({ ...prev, preheaderHighlight: e.target.value }))}
                      placeholder="e.g. 240 GSM"
                      className="w-full px-2.5 py-1.5 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Main Headline *
                </label>
                <input
                  type="text"
                  required
                  value={hero.headline}
                  onChange={(e) => setHero(prev => ({ ...prev, headline: e.target.value }))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Sub-Headline Narrative *
                </label>
                <textarea
                  rows={2}
                  required
                  value={hero.subheadline}
                  onChange={(e) => setHero(prev => ({ ...prev, subheadline: e.target.value }))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Background Imagery URL
                </label>
                <input
                  type="url"
                  value={hero.bgImage}
                  onChange={(e) => setHero(prev => ({ ...prev, bgImage: e.target.value }))}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            {/* SECTION B: LEFT HERO SIDE BOX (CIRCLED LEFT) */}
            <div className="space-y-3 p-3.5 rounded-xl bg-neutral-900/60 border border-red-500/30">
              <div className="flex items-center justify-between">
                <span className="font-bold text-red-400 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  2. Left Spotlight Box (Ren // Lore 01)
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Desktop Floating Box</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Top Badge / Tag
                  </label>
                  <input
                    type="text"
                    value={hero.leftCardTag || 'ORIGINAL LORE · 01'}
                    onChange={(e) => setHero(prev => ({ ...prev, leftCardTag: e.target.value }))}
                    placeholder="e.g. ORIGINAL LORE · 01"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Title / Character / Product Name
                  </label>
                  <input
                    type="text"
                    value={hero.leftCardTitle || 'REN // DARK SHONEN'}
                    onChange={(e) => setHero(prev => ({ ...prev, leftCardTitle: e.target.value }))}
                    placeholder="e.g. REN // DARK SHONEN"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Description / Story Quote
                </label>
                <textarea
                  rows={2}
                  value={hero.leftCardDesc || '“Some people run from the darkness. He learned to walk through it.”'}
                  onChange={(e) => setHero(prev => ({ ...prev, leftCardDesc: e.target.value }))}
                  placeholder="Enter quote or product highlight"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Box Image URL or Upload
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={hero.leftCardImage || ''}
                    onChange={(e) => setHero(prev => ({ ...prev, leftCardImage: e.target.value }))}
                    placeholder="https://... image URL"
                    className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                  <label className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer shrink-0 border border-neutral-700">
                    <Upload className="w-3.5 h-3.5 text-red-400" />
                    <span>Upload</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          setHero(prev => ({ ...prev, leftCardImage: reader.result as string }));
                          showToast('Left box image selected.');
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* SECTION C: RIGHT HERO SIDE BOX (CIRCLED RIGHT) */}
            <div className="space-y-3 p-3.5 rounded-xl bg-neutral-900/60 border border-cyan-500/30">
              <div className="flex items-center justify-between">
                <span className="font-bold text-cyan-400 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  3. Right Spotlight Box (Yuki // Lore 02)
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Desktop Floating Box</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Top Badge / Tag
                  </label>
                  <input
                    type="text"
                    value={hero.rightCardTag || 'ORIGINAL LORE · 02'}
                    onChange={(e) => setHero(prev => ({ ...prev, rightCardTag: e.target.value }))}
                    placeholder="e.g. ORIGINAL LORE · 02"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Title / Character / Product Name
                  </label>
                  <input
                    type="text"
                    value={hero.rightCardTitle || 'YUKI // CYBERPUNK'}
                    onChange={(e) => setHero(prev => ({ ...prev, rightCardTitle: e.target.value }))}
                    placeholder="e.g. YUKI // CYBERPUNK"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Description / Story Quote
                </label>
                <textarea
                  rows={2}
                  value={hero.rightCardDesc || '“Midnight runs through rain-slicked neon alleys of Neo Tokyo.”'}
                  onChange={(e) => setHero(prev => ({ ...prev, rightCardDesc: e.target.value }))}
                  placeholder="Enter quote or product highlight"
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                  Box Image URL or Upload
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={hero.rightCardImage || ''}
                    onChange={(e) => setHero(prev => ({ ...prev, rightCardImage: e.target.value }))}
                    placeholder="https://... image URL"
                    className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                  <label className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg font-bold text-xs flex items-center gap-1.5 cursor-pointer shrink-0 border border-neutral-700">
                    <Upload className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Upload</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = () => {
                          setHero(prev => ({ ...prev, rightCardImage: reader.result as string }));
                          showToast('Right box image selected.');
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* SECTION D: HERO ACTION BUTTONS (CIRCLED BOTTOM) */}
            <div className="space-y-3 p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800">
              <span className="font-bold text-neutral-200 text-xs uppercase tracking-wider block">
                4. Hero Action Buttons (Circled CTAs)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Button 1 (Primary)
                  </label>
                  <input
                    type="text"
                    value={hero.ctaText || 'SHOP MEN'}
                    onChange={(e) => setHero(prev => ({ ...prev, ctaText: e.target.value }))}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Button 2 (Circled: Kids)
                  </label>
                  <input
                    type="text"
                    value={hero.secondaryCtaText || 'SHOP KIDS'}
                    onChange={(e) => setHero(prev => ({ ...prev, secondaryCtaText: e.target.value }))}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Button 3 (Circled: Combo)
                  </label>
                  <input
                    type="text"
                    value={hero.tertiaryCtaText || 'TRY TWIN COMBO 👯'}
                    onChange={(e) => setHero(prev => ({ ...prev, tertiaryCtaText: e.target.value }))}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>
            </div>

            {/* SECTION E: QUALITY & TRUST COMMITMENTS (CIRCLED BOTTOM 3) */}
            <div className="space-y-3 p-3.5 rounded-xl bg-neutral-900/60 border border-red-500/30">
              <div className="flex items-center justify-between">
                <span className="font-bold text-red-400 text-xs uppercase tracking-wider block">
                  5. Quality &amp; Trust Commitments (Circled Bottom 3 Badges)
                </span>
                <span className="text-[10px] font-mono text-neutral-400">Footer Strip under Buttons</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Badge 1 (Circled Left)
                  </label>
                  <input
                    type="text"
                    value={hero.trustBadge1 || '240 GSM Combed Cotton'}
                    onChange={(e) => setHero(prev => ({ ...prev, trustBadge1: e.target.value }))}
                    placeholder="e.g. 240 GSM Combed Cotton"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Badge 2 (Circled Center)
                  </label>
                  <input
                    type="text"
                    value={hero.trustBadge2 || '100% Original Japanese Anime IP'}
                    onChange={(e) => setHero(prev => ({ ...prev, trustBadge2: e.target.value }))}
                    placeholder="e.g. 100% Original Japanese Anime IP"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-400 uppercase tracking-wider mb-1 text-[11px]">
                    Badge 3 (Circled Right)
                  </label>
                  <input
                    type="text"
                    value={hero.trustBadge3 || 'Free Pan-India Delivery Over ₹999'}
                    onChange={(e) => setHero(prev => ({ ...prev, trustBadge3: e.target.value }))}
                    placeholder="e.g. Free Pan-India Delivery Over ₹999"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Publish Hero &amp; Spotlight Changes</span>
            </button>
          </form>

          {/* Live Device Preview Frame */}
          <div className="lg:col-span-5 bg-[#14141c] border border-neutral-800 rounded-2xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Live Viewport Simulator
                </span>
                <div className="flex items-center gap-1 bg-neutral-900 p-0.5 rounded-lg border border-neutral-800 text-xs">
                  <button
                    type="button"
                    onClick={() => setPreviewDevice('desktop')}
                    className={`p-1.5 rounded ${previewDevice === 'desktop' ? 'bg-neutral-800 text-white' : 'text-neutral-500'}`}
                  >
                    <Monitor className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewDevice('mobile')}
                    className={`p-1.5 rounded ${previewDevice === 'mobile' ? 'bg-neutral-800 text-white' : 'text-neutral-500'}`}
                  >
                    <Smartphone className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Viewport Frame */}
              <div className={`mx-auto rounded-xl overflow-hidden border border-neutral-700 relative shadow-2xl transition-all ${
                previewDevice === 'desktop' ? 'w-full h-84' : 'w-60 h-96'
              }`}>
                <img 
                  src={hero.bgImage || 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1600&auto=format&fit=crop&q=80'} 
                  alt="Hero" 
                  className="w-full h-full object-cover" 
                />
                <div 
                  className="absolute inset-0 bg-black/75"
                />

                {/* Left Card in Preview (Desktop Only) */}
                {previewDevice === 'desktop' && (
                  <div className="absolute top-4 left-3 w-28 aspect-[3/4] rounded-lg overflow-hidden border border-neutral-800 bg-[#151515] p-2 flex flex-col justify-end text-[9px] shadow-lg">
                    <img 
                      src={hero.leftCardImage || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80'} 
                      alt="Left Box"
                      className="absolute inset-0 w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                    <div className="relative z-10 text-left">
                      <span className="text-[7px] font-mono text-red-500 font-bold block">{hero.leftCardTag || 'ORIGINAL LORE · 01'}</span>
                      <span className="text-[8px] font-bold text-white block uppercase truncate">{hero.leftCardTitle || 'REN // DARK SHONEN'}</span>
                    </div>
                  </div>
                )}

                {/* Right Card in Preview (Desktop Only) */}
                {previewDevice === 'desktop' && (
                  <div className="absolute top-4 right-3 w-28 aspect-[3/4] rounded-lg overflow-hidden border border-neutral-800 bg-[#151515] p-2 flex flex-col justify-end text-[9px] shadow-lg">
                    <img 
                      src={hero.rightCardImage || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80'} 
                      alt="Right Box"
                      className="absolute inset-0 w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                    <div className="relative z-10 text-left">
                      <span className="text-[7px] font-mono text-cyan-400 font-bold block">{hero.rightCardTag || 'ORIGINAL LORE · 02'}</span>
                      <span className="text-[8px] font-bold text-white block uppercase truncate">{hero.rightCardTitle || 'YUKI // CYBERPUNK'}</span>
                    </div>
                  </div>
                )}

                {/* Center Stage Preview */}
                <div className="absolute inset-0 flex flex-col justify-center items-center text-center p-3 z-10">
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-neutral-900/90 border border-neutral-800 text-[8px] font-mono font-medium text-neutral-300 uppercase mb-1">
                    <span>{hero.preheaderTag || 'ORIGINAL TOKYO-INSPIRED STREETWEAR'}</span>
                    <span className="text-neutral-600">·</span>
                    <span className="text-red-500 font-bold">{hero.preheaderHighlight || '240 GSM'}</span>
                  </div>
                  <h4 className="text-base sm:text-lg font-black text-white tracking-tight">{hero.headline}</h4>
                  <p className="text-[10px] text-neutral-300 max-w-xs mt-0.5 line-clamp-2">{hero.subheadline}</p>

                  <div className="mt-2.5 flex items-center gap-1.5 flex-wrap justify-center">
                    <div className="px-2 py-0.5 bg-white text-black rounded font-black text-[9px] tracking-wider uppercase">
                      {hero.ctaText || 'SHOP MEN'}
                    </div>
                    <div className="px-2 py-0.5 bg-neutral-900 border border-neutral-700 text-white rounded font-bold text-[9px] tracking-wider uppercase">
                      {hero.secondaryCtaText || 'SHOP KIDS'}
                    </div>
                    <div className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded font-bold text-[8px] tracking-wider uppercase">
                      {hero.tertiaryCtaText || 'TRY TWIN COMBO 👯'}
                    </div>
                  </div>

                  {/* Trust Badges in Preview */}
                  <div className="mt-2 text-[7px] font-mono text-neutral-400 flex items-center gap-1.5 justify-center flex-wrap">
                    <span>{hero.trustBadge1 || '240 GSM Combed Cotton'}</span>
                    <span className="text-neutral-700">·</span>
                    <span>{hero.trustBadge2 || '100% Original Japanese Anime IP'}</span>
                    <span className="text-neutral-700">·</span>
                    <span>{hero.trustBadge3 || 'Free Pan-India Delivery Over ₹999'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-[11px] text-neutral-400 text-center mt-3 font-mono p-2 bg-neutral-900/60 rounded-xl border border-neutral-800">
              💡 Changes saved here update the live homepage hero and spotlight boxes immediately!
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PROMOTIONAL ADS & BANNERS */}
      {activeTab === 'ADS_PROMOS' && (
        <CmsAdsManager
          ads={cmsData.advertisements}
          onUpdateAds={(updatedAds) => {
            const next = { ...cmsData, advertisements: updatedAds };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          showToast={showToast}
        />
      )}

      {/* TAB 4: EVERY TAB & NAVIGATION LINKS */}
      {activeTab === 'TABS_NAV' && (
        <CmsTabsManager
          tabs={cmsData.tabs}
          onUpdateTabs={(updatedTabs) => {
            const next = { ...cmsData, tabs: updatedTabs };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          showToast={showToast}
        />
      )}

      {/* TAB 5: COMPLETE CONTENT VAULT (REALMS, LORE, CHARACTERS, STORIES, LOOKBOOK, FAQS, FOOTER) */}
      {activeTab === 'CONTENT_VAULT' && (
        <CmsContentManager
          realms={cmsData.realms}
          onUpdateRealms={(updatedRealms) => {
            const next = { ...cmsData, realms: updatedRealms };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          universe={cmsData.universe}
          onUpdateUniverse={(updatedUniverse) => {
            const next = { ...cmsData, universe: updatedUniverse };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          characters={cmsData.characters}
          onUpdateCharacters={(updatedChars) => {
            const next = { ...cmsData, characters: updatedChars };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          stories={cmsData.designStories}
          onUpdateStories={(updatedStories) => {
            const next = { ...cmsData, designStories: updatedStories };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          lookbook={cmsData.lookbook}
          onUpdateLookbook={(updatedLb) => {
            const next = { ...cmsData, lookbook: updatedLb };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          socialFeed={cmsData.socialFeed}
          onUpdateSocialFeed={(updatedFeed) => {
            const next = { ...cmsData, socialFeed: updatedFeed };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          faqs={cmsData.faqs}
          onUpdateFaqs={(updatedFaqs) => {
            const next = { ...cmsData, faqs: updatedFaqs };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          footer={cmsData.footer}
          onUpdateFooter={(updatedFooter) => {
            const next = { ...cmsData, footer: updatedFooter };
            setCmsData(next);
            saveFrontPageCmsData(next);
          }}
          showToast={showToast}
        />
      )}

      {/* TAB 4: OFFICIAL MASTER BRAND LOGO ASSET LOCK */}
      {activeTab === 'BRAND_LOCK' && (
        <div className="space-y-6 text-xs max-w-4xl">
          {/* Header Banner */}
          <div className="bg-[#14141c] border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-red-500/20 text-red-400 font-mono text-[10px] font-bold border border-red-500/30 uppercase mb-2">
                  <Shield className="w-3 h-3 text-red-500" />
                  <span>CRITICAL ASSET SPECIFICATION & LOCK</span>
                </div>
                <h2 className="text-lg font-bold text-white tracking-wide">
                  TORIWEAR Official Logo Master Asset Lock
                </h2>
                <p className="text-neutral-400 text-xs mt-1 leading-relaxed max-w-2xl">
                  The uploaded image asset is locked as the immutable single source of truth for the TORIWEAR brand identity. Per specification, text recreations, AI regenerations, font replacements, and aspect ratio alterations are strictly barred.
                </p>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[10px] font-mono text-neutral-400 block">ASSET PATH:</span>
                <code className="text-red-400 font-mono text-[11px] bg-black/60 px-2 py-1 rounded border border-neutral-800 block mt-1">
                  /public/assets/toriwear-official-logo.png
                </code>
              </div>
            </div>

            {/* Asset Live Preview */}
            <div className="mt-6 pt-6 border-t border-neutral-800 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="bg-black/80 border border-neutral-800 rounded-xl p-6 flex flex-col items-center justify-center min-h-[220px]">
                <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest mb-3">
                  Live Master Logo Render (&lt;OfficialToriwearLogo /&gt;)
                </span>
                <OfficialToriwearLogo 
                  className="max-h-40 w-auto object-contain drop-shadow-xl" 
                />
              </div>

              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-300">Disk Asset Status</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      logoStatus?.exists 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}>
                      {logoStatus?.exists ? 'VERIFIED ON DISK' : 'PENDING MASTER UPLOAD'}
                    </span>
                  </div>
                  {logoStatus?.exists && (
                    <div className="text-[11px] text-neutral-400 font-mono">
                      File Size: {(logoStatus.sizeBytes / 1024).toFixed(1)} KB
                    </div>
                  )}
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    The master asset is served live across Header, Hero centerpiece, Footer, Cart Drawer, and Admin Console.
                  </p>
                </div>

                {/* Direct Asset Upload Card */}
                <div className="p-4 rounded-xl bg-red-950/20 border border-red-900/40 space-y-2">
                  <span className="font-semibold text-white block">
                    Upload / Replace Master Logo File
                  </span>
                  <p className="text-[11px] text-neutral-400">
                    Select your official <code className="text-red-400 font-mono">toriwear-official-logo.png</code> from your local drive to immediately write it to the static assets directory.
                  </p>
                  <label className="mt-2 inline-flex items-center gap-2 px-3 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg font-bold text-xs cursor-pointer transition">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingLogo ? 'Writing to Disk...' : 'Select toriwear-official-logo.png'}</span>
                    <input 
                      type="file" 
                      accept="image/png,image/jpeg,image/webp" 
                      onChange={handleLogoUpload} 
                      className="hidden" 
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Compliance Checklist */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800 space-y-2">
              <span className="font-bold text-white text-xs block">Brand Typography Systems</span>
              <ul className="space-y-1 text-neutral-400 text-[11px]">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span><strong>Brand Display:</strong> Bebas Neue, Arial Black, Impact</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span><strong>Body UI:</strong> Inter, Helvetica Neue, sans-serif</span>
                </li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800 space-y-2">
              <span className="font-bold text-white text-xs block">Pixel-Faithful Rules</span>
              <ul className="space-y-1 text-neutral-400 text-[11px]">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Zero AI regeneration or font recreation</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Proportional scaling only (no cropping or stretching)</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
