import React, { useState } from 'react';
import { useAdmin } from '../AdminDataContext';
import { PaymentTransaction } from '../types';
import { 
  CreditCard, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  RotateCcw, 
  ArrowUpRight, 
  DollarSign, 
  ShieldCheck, 
  Building2,
  ExternalLink,
  Percent
} from 'lucide-react';

export const PaymentsView: React.FC = () => {
  const { payments, orders, initiateRefund } = useAdmin();

  const [searchQuery, setSearchQuery] = useState('');
  const [methodFilter, setMethodFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [reconciliationTab, setReconciliationTab] = useState<'TRANSACTIONS' | 'RECONCILIATION'>('TRANSACTIONS');

  // Stats
  const totalVolume = payments.reduce((sum, p) => sum + (p.status === 'SUCCESS' ? p.amount : 0), 0);
  const totalFees = payments.reduce((sum, p) => sum + p.fee, 0);
  const netSettlement = payments.reduce((sum, p) => sum + p.netSettlement, 0);
  const refundedVolume = payments.reduce((sum, p) => sum + (p.status === 'REFUNDED' ? p.amount : 0), 0);
  const successfulCount = payments.filter(p => p.status === 'SUCCESS').length;
  const failedCount = payments.filter(p => p.status === 'FAILED').length;

  const filtered = payments.filter((p) => {
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match = p.orderNumber.toLowerCase().includes(q) ||
                    p.customerName.toLowerCase().includes(q) ||
                    p.gatewayRefId.toLowerCase().includes(q) ||
                    p.customerEmail.toLowerCase().includes(q);
      if (!match) return false;
    }
    if (methodFilter !== 'ALL' && p.method !== methodFilter) return false;
    if (statusFilter !== 'ALL' && p.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-emerald-500" />
            <span>Payments Gateway & UPI Settlements</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Razorpay, UPI QR, NetBanking, COD settlements, MDR fees & automated refunds.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            Gateway: <strong>RAZORPAY LIVE (99.8% Uptime)</strong>
          </span>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800">
          <div className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Gross Payment Volume</div>
          <div className="text-lg font-bold text-white font-mono mt-1">₹{totalVolume.toLocaleString('en-IN')}</div>
          <div className="text-[10px] text-emerald-400 font-mono mt-0.5">{successfulCount} settled transactions</div>
        </div>

        <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800">
          <div className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Net Bank Settlements</div>
          <div className="text-lg font-bold text-emerald-400 font-mono mt-1">₹{netSettlement.toLocaleString('en-IN')}</div>
          <div className="text-[10px] text-neutral-500 font-mono mt-0.5">HDFC Escrow Account **4912</div>
        </div>

        <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800">
          <div className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Gateway Fees (MDR 2%)</div>
          <div className="text-lg font-bold text-neutral-300 font-mono mt-1">₹{totalFees.toFixed(2)}</div>
          <div className="text-[10px] text-neutral-500 font-mono mt-0.5">Automated invoice deduction</div>
        </div>

        <div className="p-4 rounded-xl bg-[#14141c] border border-neutral-800">
          <div className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Refunds Processed</div>
          <div className="text-lg font-bold text-purple-400 font-mono mt-1">₹{refundedVolume.toLocaleString('en-IN')}</div>
          <div className="text-[10px] text-purple-400/80 font-mono mt-0.5">Direct to source UPI/card</div>
        </div>
      </div>

      {/* Switcher */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2 text-xs">
        <button
          onClick={() => setReconciliationTab('TRANSACTIONS')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            reconciliationTab === 'TRANSACTIONS' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          Payment Transactions ({payments.length})
        </button>

        <button
          onClick={() => setReconciliationTab('RECONCILIATION')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
            reconciliationTab === 'RECONCILIATION' 
              ? 'bg-red-600 text-white shadow-sm' 
              : 'text-neutral-400 hover:text-white bg-neutral-900'
          }`}
        >
          Automated Gateway Reconciliation
        </button>
      </div>

      {reconciliationTab === 'TRANSACTIONS' ? (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3 bg-[#14141c] p-3.5 rounded-2xl border border-neutral-800">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by Payment ID, Order Number, or Customer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={methodFilter}
                onChange={(e) => setMethodFilter(e.target.value)}
                className="px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-300 focus:outline-none focus:border-red-500 cursor-pointer"
              >
                <option value="ALL">All Payment Methods</option>
                <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
                <option value="CREDIT_CARD">Credit Card</option>
                <option value="DEBIT_CARD">Debit Card</option>
                <option value="NET_BANKING">Net Banking</option>
                <option value="COD">Cash on Delivery (COD)</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-neutral-300 focus:outline-none focus:border-red-500 cursor-pointer"
              >
                <option value="ALL">All Statuses</option>
                <option value="SUCCESS">Success</option>
                <option value="FAILED">Failed</option>
                <option value="PENDING">Pending</option>
                <option value="REFUNDED">Refunded</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-[#14141c] border border-neutral-800 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-neutral-300">
                <thead className="bg-[#181824] text-[11px] uppercase tracking-wider text-neutral-400 border-b border-neutral-800 font-mono">
                  <tr>
                    <th className="p-3.5 pl-4">Transaction Ref</th>
                    <th className="p-3.5">Order #</th>
                    <th className="p-3.5">Customer</th>
                    <th className="p-3.5">Method</th>
                    <th className="p-3.5">Gross Amount</th>
                    <th className="p-3.5">MDR Fee</th>
                    <th className="p-3.5">Net Payout</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right pr-4">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-sans">
                  {filtered.map((tx) => (
                    <tr key={tx.id} className="hover:bg-neutral-800/40 transition-colors">
                      <td className="p-3.5 pl-4 font-mono font-bold text-emerald-400">
                        {tx.gatewayRefId}
                      </td>
                      <td className="p-3.5 font-mono text-red-400">
                        {tx.orderNumber}
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-white">{tx.customerName}</div>
                        <div className="text-[10px] text-neutral-500 font-mono">{tx.customerEmail}</div>
                      </td>
                      <td className="p-3.5 font-mono">
                        <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 text-[10px]">
                          {tx.method}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-white">
                        ₹{tx.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 font-mono text-neutral-500">
                        -₹{tx.fee.toFixed(2)}
                      </td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        ₹{tx.netSettlement.toFixed(2)}
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-semibold ${
                          tx.status === 'SUCCESS'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : tx.status === 'REFUNDED'
                            ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                            : tx.status === 'FAILED'
                            ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                            : 'bg-yellow-500/10 text-yellow-400'
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right pr-4 font-mono text-neutral-400 text-[11px]">
                        {tx.date}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* RECONCILIATION SUMMARY TAB */
        <div className="bg-[#14141c] border border-neutral-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Razorpay Settlement Cycle Reconciliation</h3>
              <p className="text-xs text-neutral-400">T+1 Automated Settlement to Toriwear HDFC Escrow Account</p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-mono">
              STATUS: ZERO VARIANCE (BALANCED)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
              <div className="text-xs font-bold text-neutral-400 uppercase">Cart Storefront Orders</div>
              <div className="text-xl font-bold text-white font-mono">₹14,923.00</div>
              <div className="text-xs text-neutral-500">Total order values captured on web</div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
              <div className="text-xs font-bold text-neutral-400 uppercase">Razorpay Payment Gateway Captured</div>
              <div className="text-xl font-bold text-emerald-400 font-mono">₹14,923.00</div>
              <div className="text-xs text-neutral-500">100% matched with order hashes</div>
            </div>

            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
              <div className="text-xs font-bold text-neutral-400 uppercase">Bank Dispatched Settlement</div>
              <div className="text-xl font-bold text-blue-400 font-mono">₹14,624.54</div>
              <div className="text-xs text-neutral-500">After deducting ₹298.46 Razorpay fee</div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-300 space-y-2">
            <div className="font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Automated Daily Reconciliation Active</span>
            </div>
            <p>
              Webhook signatures are validated using HMAC-SHA256. If a customer is charged but the browser disconnects, the automated background worker re-verifies with Razorpay's API and converts the order to <strong>PAID</strong> within 120 seconds.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
