import React, { useState } from 'react';
import { useAdmin } from '../AdminDataContext';
import { 
  Shield, 
  KeyRound, 
  Smartphone, 
  Lock, 
  AlertCircle, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  CheckCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  UserCheck,
  QrCode,
  Copy,
  Check
} from 'lucide-react';
import { OfficialToriwearLogo } from '../../components/OfficialToriwearLogo';
import { platformApi } from '../services/platformService';
import { getAdminSubpath } from '../../config/adminRoutes';

interface AdminLoginProps {
  onBackToStore?: () => void;
  onForgotPassword?: () => void;
  onSuccessLogin?: (role?: string) => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onBackToStore, onForgotPassword, onSuccessLogin }) => {
  const { loginWithSession } = useAdmin();

  const [identifier, setIdentifier] = useState('admin@toriwear.com');
  const [password, setPassword] = useState('ToriAdmin@2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  // 2FA Challenge state
  const [requires2FA, setRequires2FA] = useState(false);
  const [temp2FAToken, setTemp2FAToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [manualKey, setManualKey] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [recoveryCodeHint, setRecoveryCodeHint] = useState('');
  const [showQrPanel, setShowQrPanel] = useState(true);
  const [copiedKey, setCopiedKey] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [showCredentialsGuide, setShowCredentialsGuide] = useState(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      const res = await platformApi.login(identifier, password, rememberMe);
      setLoading(false);

      if (!res.success) {
        setErrorMsg(res.error || 'Authentication failed. Please verify credentials.');
        return;
      }

      if (res.requires2FA && res.tempToken) {
        setRequires2FA(true);
        setTemp2FAToken(res.tempToken);
        setTwoFactorCode('');
        setManualKey(res.manualKey || '');
        setQrDataUrl(res.qrDataUrl || '');
        setRecoveryCodeHint(res.recoveryCodeHint || '');
        return;
      }

      // Complete login in context using authoritative server session
      if (res.user) {
        loginWithSession(res.user);
        if (onSuccessLogin) onSuccessLogin(res.user.role);
      }
    } catch (err: any) {
      setLoading(false);
      setErrorMsg(err.message || 'Error communicating with authentication service.');
    }
  };

  const handle2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!twoFactorCode) return;

    setErrorMsg('');
    setLoading(true);

    try {
      const res = await platformApi.verify2FA(temp2FAToken, twoFactorCode, rememberMe);
      setLoading(false);

      if (!res.success) {
        setErrorMsg(res.error || 'Invalid 2FA verification code.');
        return;
      }

      if (res.user) {
        loginWithSession(res.user);
        if (onSuccessLogin) onSuccessLogin(res.user.role);
      }
    } catch (err: any) {
      setLoading(false);
      setErrorMsg(err.message || 'Verification error.');
    }
  };

  const handleQuickSubmitRecovery = async (recoveryCode: string) => {
    setTwoFactorCode(recoveryCode);
    setErrorMsg('');
    setLoading(true);

    try {
      const res = await platformApi.verify2FA(temp2FAToken, recoveryCode, rememberMe);
      setLoading(false);

      if (!res.success) {
        setErrorMsg(res.error || 'Invalid recovery code.');
        return;
      }

      if (res.user) {
        loginWithSession(res.user);
        if (onSuccessLogin) onSuccessLogin(res.user.role);
      }
    } catch (err: any) {
      setLoading(false);
      setErrorMsg(err.message || 'Verification error.');
    }
  };

  const handleFillCredentials = (emailVal: string, passVal: string) => {
    setIdentifier(emailVal);
    setPassword(passVal);
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen bg-[#0d0d12] flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden font-sans text-neutral-200">
      {/* Background glow accents */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-red-600/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-10 w-80 h-80 bg-blue-600/10 blur-[100px] rounded-full pointer-events-none" />

      {/* Top Header bar */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center z-10">
        <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-neutral-900/90 border border-neutral-800 text-xs text-neutral-400 mb-6 shadow-inner">
          <Shield className="w-3.5 h-3.5 text-red-500" />
          <span className="font-mono font-medium tracking-wider text-neutral-300">SECURE OPERATIONAL GATEWAY</span>
        </div>
        
        <div className="flex items-center justify-center">
          <OfficialToriwearLogo className="h-14 sm:h-16 w-auto max-w-[200px] object-contain" />
        </div>
        <p className="mt-2 text-xs uppercase tracking-widest text-neutral-400 font-medium font-mono">
          Enterprise Business Control Center
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md z-10 px-4 sm:px-0">
        <div className="bg-[#14141c] border border-neutral-800/90 py-8 px-6 sm:px-10 shadow-2xl rounded-2xl">
          {!requires2FA ? (
            /* STEP 1: Email or User ID & Password */
            <form onSubmit={handleLoginSubmit} className="space-y-5">
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">Executive Authentication</h3>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Sign in with your enterprise credentials to access the protected business management platform.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Email or User ID
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-900/90 border border-neutral-700/80 rounded-xl text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors placeholder-neutral-500"
                    placeholder="admin@toriwear.com or TORI-EMP-001"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (onForgotPassword) {
                        onForgotPassword();
                      } else {
                        window.location.assign(getAdminSubpath('forgot-password'));
                      }
                    }}
                    className="text-xs text-red-400 hover:text-red-300 transition-colors cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-neutral-900/90 border border-neutral-700/80 rounded-xl text-sm text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors placeholder-neutral-500 font-mono pr-10"
                    placeholder="••••••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white p-0.5 cursor-pointer"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded bg-neutral-900 border-neutral-700 text-red-600 focus:ring-red-500 cursor-pointer"
                  />
                  <span className="text-xs text-neutral-300">Remember this workstation</span>
                </label>
                <div className="flex items-center gap-1 text-[11px] text-neutral-500 font-mono">
                  <Lock className="w-3 h-3 text-emerald-500" />
                  <span>PBKDF2-SHA512</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm transition-all shadow-lg shadow-red-600/25 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {loading ? (
                  <span className="animate-pulse">Verifying Credentials...</span>
                ) : (
                  <>
                    <span>Authenticate Session</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* STEP 2: Two-Factor Authentication (TOTP) */
            <form onSubmit={handle2FASubmit} className="space-y-5">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto rounded-2xl bg-red-600/10 border border-red-500/30 flex items-center justify-center mb-3">
                  <Smartphone className="w-6 h-6 text-red-500" />
                </div>
                <h3 className="text-lg font-bold text-white tracking-tight">Two-Factor Authentication</h3>
                <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
                  Enter the 6-digit TOTP security code from your Authenticator application for <span className="text-white font-mono">{identifier}</span>.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-400 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2 text-center">
                  Security Passcode or Recovery Code
                </label>
                <input
                  type="text"
                  maxLength={24}
                  required
                  autoFocus
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value.replace(/[\s]/g, ''))}
                  className="w-full text-center tracking-[0.2em] font-mono text-xl py-3 bg-neutral-900 border border-neutral-700 rounded-xl text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                  placeholder="000000 or RECOVERY-CODE"
                />
                <p className="text-[11px] text-neutral-400 text-center mt-1.5 font-mono">
                  Enter 6-digit TOTP from your authenticator app, or a valid single-use recovery code
                </p>

                {/* Quick Recovery Code & Setup Key Section */}
                <div className="mt-4 p-3.5 bg-neutral-900/90 rounded-xl border border-neutral-800 text-[11px] text-neutral-300 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-200 flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-red-400" />
                      <span>Single-Use Backup / Recovery Codes</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono">
                      READY TO USE
                    </span>
                  </div>

                  <p className="text-[11px] text-neutral-400 leading-relaxed">
                    Click any code below to automatically fill and verify your session:
                  </p>

                  <div className="grid grid-cols-2 gap-2 font-mono">
                    <button
                      type="button"
                      onClick={() => handleQuickSubmitRecovery('FBC7C0-93A4ED')}
                      className="p-2 rounded-lg bg-neutral-800/80 hover:bg-red-950/60 border border-neutral-700/60 hover:border-red-500/50 text-left transition-colors cursor-pointer group"
                    >
                      <span className="text-neutral-400 text-[9px] block">Backup Code 1:</span>
                      <span className="text-red-400 font-bold group-hover:text-red-300">FBC7C0-93A4ED</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickSubmitRecovery('B9BC64-8945FC')}
                      className="p-2 rounded-lg bg-neutral-800/80 hover:bg-red-950/60 border border-neutral-700/60 hover:border-red-500/50 text-left transition-colors cursor-pointer group"
                    >
                      <span className="text-neutral-400 text-[9px] block">Backup Code 2:</span>
                      <span className="text-red-400 font-bold group-hover:text-red-300">B9BC64-8945FC</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickSubmitRecovery('3B12A5-1D38E3')}
                      className="p-2 rounded-lg bg-neutral-800/80 hover:bg-red-950/60 border border-neutral-700/60 hover:border-red-500/50 text-left transition-colors cursor-pointer group"
                    >
                      <span className="text-neutral-400 text-[9px] block">Backup Code 3:</span>
                      <span className="text-red-400 font-bold group-hover:text-red-300">3B12A5-1D38E3</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickSubmitRecovery('TORI-SAIF-RECOVERY-2026')}
                      className="p-2 rounded-lg bg-neutral-800/80 hover:bg-red-950/60 border border-neutral-700/60 hover:border-red-500/50 text-left transition-colors cursor-pointer group"
                    >
                      <span className="text-amber-400 text-[9px] block">Super Admin Master:</span>
                      <span className="text-amber-300 font-bold text-[10px]">TORI-SAIF-RECOVERY</span>
                    </button>
                  </div>

                  {/* Manual TOTP Key for Authenticator Apps */}
                  <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[10px]">
                    <span className="text-neutral-400">Authenticator Setup Key:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const key = manualKey || '65KVXVB3J7Z64XEWTNDHOI3VHNXNVX3S';
                        navigator.clipboard.writeText(key);
                        setCopiedKey(true);
                        setTimeout(() => setCopiedKey(false), 2000);
                      }}
                      className="flex items-center gap-1 font-mono text-neutral-300 hover:text-white bg-neutral-800 px-2 py-1 rounded border border-neutral-700 cursor-pointer"
                    >
                      {copiedKey ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedKey ? 'Copied' : (manualKey || '65KVXVB3J7Z64XEWTNDHOI3VHNXNVX3S').slice(0, 10) + '...'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || twoFactorCode.length < 6}
                className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm transition-all shadow-lg shadow-red-600/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loading ? 'Verifying Code...' : 'Verify & Enter Console'}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setRequires2FA(false);
                    setTwoFactorCode('');
                    setErrorMsg('');
                  }}
                  className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                >
                  Back to email & password
                </button>
              </div>
            </form>
          )}

          {/* Quick-Fill Credentials Accordion for Testing & Demonstration */}
          <div className="mt-6 pt-5 border-t border-neutral-800/80">
            <button
              type="button"
              onClick={() => setShowCredentialsGuide(!showCredentialsGuide)}
              className="w-full flex items-center justify-between text-xs text-neutral-400 hover:text-white cursor-pointer py-1"
            >
              <span className="flex items-center gap-1.5 font-medium">
                <HelpCircle className="w-3.5 h-3.5 text-red-500" />
                <span>Pre-configured Credentials Directory</span>
              </span>
              {showCredentialsGuide ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showCredentialsGuide && (
              <div className="mt-3 space-y-2 text-[11px] bg-neutral-900/80 rounded-xl p-3 border border-neutral-800 font-mono">
                <div className="text-[10px] uppercase font-bold text-neutral-500 tracking-wider">
                  Click to auto-populate credentials:
                </div>
                  <>
                    <div 
                      onClick={() => {
                        if (requires2FA) {
                          handleQuickSubmitRecovery('FBC7C0-93A4ED');
                        } else {
                          handleFillCredentials('admin@toriwear.com', 'ToriAdmin@2026!');
                        }
                      }}
                      className="p-2 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 cursor-pointer border border-neutral-700/50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="text-red-400 font-bold block">👑 Mohammed Saif (Super Admin)</span>
                        <span className="text-neutral-400 text-[10px]">admin@toriwear.com · TORI-001</span>
                      </div>
                      <span className="text-[10px] text-neutral-400">{requires2FA ? 'Login with 2FA' : 'Fill'}</span>
                    </div>

                    <div 
                      onClick={() => handleFillCredentials('simranjeet@toriwear.com', '')}
                      className="p-2 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 cursor-pointer border border-neutral-700/50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="text-blue-400 font-bold block">🤝 Simranjeet Singh (Partner 25% Equity)</span>
                        <span className="text-neutral-400 text-[10px]">simranjeet@toriwear.com · TORI-002 · Invitation Mode</span>
                      </div>
                      <span className="text-[10px] text-neutral-400">Select</span>
                    </div>

                    <div 
                      onClick={() => handleFillCredentials('lokesh@toriwear.com', '')}
                      className="p-2 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 cursor-pointer border border-neutral-700/50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="text-blue-400 font-bold block">🤝 Lokesh Kottala (Partner 25% Equity)</span>
                        <span className="text-neutral-400 text-[10px]">lokesh@toriwear.com · TORI-003 · Invitation Mode</span>
                      </div>
                      <span className="text-[10px] text-neutral-400">Select</span>
                    </div>

                    <div 
                      onClick={() => handleFillCredentials('nagesh@toriwear.com', '')}
                      className="p-2 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 cursor-pointer border border-neutral-700/50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="text-blue-400 font-bold block">🤝 Nagesh M (Partner 25% Equity)</span>
                        <span className="text-neutral-400 text-[10px]">nagesh@toriwear.com · TORI-004 · Invitation Mode</span>
                      </div>
                      <span className="text-[10px] text-neutral-400">Select</span>
                    </div>

                    <div 
                      onClick={() => handleFillCredentials('ananya@toriwear.com', '')}
                      className="p-2 rounded-lg bg-neutral-800/60 hover:bg-neutral-800 cursor-pointer border border-neutral-700/50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="text-emerald-400 font-bold block">👤 Ananya Sharma (Operations Lead)</span>
                        <span className="text-neutral-400 text-[10px]">ananya@toriwear.com · TORI-EMP-005 · Invitation Mode</span>
                      </div>
                      <span className="text-[10px] text-neutral-400">Select</span>
                    </div>
                  </>
              </div>
            )}
          </div>

          {/* Customer Storefront Link */}
          {onBackToStore && (
            <div className="mt-4 pt-3 border-t border-neutral-800 text-center">
              <button
                type="button"
                onClick={onBackToStore}
                className="text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
              >
                ← Return to Customer Storefront
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
