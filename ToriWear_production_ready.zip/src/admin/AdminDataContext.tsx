import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  AdminUser, 
  Role, 
  AdminProduct, 
  InventoryItem, 
  InventoryMovement, 
  AdminOrder, 
  PaymentTransaction, 
  CustomerProfile, 
  Coupon, 
  Advertisement, 
  FlashSaleCampaign, 
  WebsiteSection, 
  HeroSettings, 
  ReturnRequest, 
  AuditLog, 
  SecuritySession, 
  StoreSettings,
  OrderShippingStatus,
  PublishingStatus
} from './types';
import { platformApi, clearSessionToken, getSessionToken } from './services/platformService';
import {
  INITIAL_ADMIN_USERS,
  INITIAL_ADMIN_PRODUCTS,
  INITIAL_INVENTORY_ITEMS,
  INITIAL_INVENTORY_MOVEMENTS,
  INITIAL_ORDERS,
  INITIAL_PAYMENT_TRANSACTIONS,
  INITIAL_CUSTOMERS,
  INITIAL_COUPONS,
  INITIAL_ADVERTISEMENTS,
  INITIAL_FLASH_SALES,
  INITIAL_WEBSITE_SECTIONS,
  INITIAL_HERO_SETTINGS,
  INITIAL_RETURN_REQUESTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_SECURITY_SESSIONS,
  INITIAL_STORE_SETTINGS,
  ROLE_PERMISSIONS
} from './data/mockData';
import {
  AIDesignConcept,
  AICharacter,
  AIWorld,
  AICollection,
  AISettings,
  AIUsageLog,
} from './types/ai';
import {
  INITIAL_AI_CHARACTERS,
  INITIAL_AI_WORLDS,
  INITIAL_AI_COLLECTIONS,
  INITIAL_AI_CONCEPTS,
  INITIAL_AI_SETTINGS,
  INITIAL_AI_USAGE_LOGS,
} from './data/aiMockData';
import { conceptToProductDraft } from './services/aiService';
import { isValidProductImageUrl } from '../utils/productFilters';
import { apiClient } from '../services/apiClient';

export type AdminView = 
  | 'DASHBOARD'
  | 'FINANCE'
  | 'USER_MANAGEMENT'
  | 'SUPER_ADMIN'
  | 'APPROVALS'
  | 'COMMUNICATION'
  | 'ACCOUNT_SECURITY'
  | 'PRODUCTS'
  | 'INVENTORY'
  | 'ORDERS'
  | 'CUSTOMERS'
  | 'PAYMENTS'
  | 'MARKETING'
  | 'CATALOG'
  | 'WEBSITE'
  | 'SHIPPING'
  | 'ANALYTICS'
  | 'REPORTS'
  | 'STAFF'
  | 'NOTIFICATIONS'
  | 'SETTINGS'
  | 'SECURITY'
  | 'AI_DESIGN_LAB';

export interface AdminNotification {
  id: string;
  type: 'ORDER' | 'STOCK' | 'PAYMENT' | 'SECURITY' | 'RETURN';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  linkView?: AdminView;
}

interface AdminDataContextType {
  // Auth & Session
  currentUser: AdminUser | null;
  isAuthenticated: boolean;
  isAuthChecking: boolean;
  twoFactorRequired: boolean;
  loginEmail: string;
  loginWithSession: (user: any) => void;
  login: (email: string, pass: string, remember: boolean) => any;
  verify2FA: (code: string, tempTokenOverride?: string) => any;
  logout: () => void;
  hasPermission: (permission: string) => boolean;

  // View Navigation
  currentView: AdminView;
  setCurrentView: (view: AdminView) => void;
  selectedSubFilter?: string;
  setSelectedSubFilter: (filter?: string) => void;
  globalSearchOpen: boolean;
  setGlobalSearchOpen: (open: boolean) => void;

  // Data Collections
  products: AdminProduct[];
  inventory: InventoryItem[];
  inventoryMovements: InventoryMovement[];
  orders: AdminOrder[];
  payments: PaymentTransaction[];
  customers: CustomerProfile[];
  coupons: Coupon[];
  ads: Advertisement[];
  flashSales: FlashSaleCampaign[];
  websiteSections: WebsiteSection[];
  heroSettings: HeroSettings;
  returnRequests: ReturnRequest[];
  auditLogs: AuditLog[];
  securitySessions: SecuritySession[];
  staff: AdminUser[];
  settings: StoreSettings;
  notifications: AdminNotification[];

  // AI Design Lab
  aiConcepts: AIDesignConcept[];
  aiCharacters: AICharacter[];
  aiWorlds: AIWorld[];
  aiCollections: AICollection[];
  aiSettings: AISettings;
  aiUsageLogs: AIUsageLog[];
  selectedConcept: AIDesignConcept | null;
  setSelectedConcept: (concept: AIDesignConcept | null) => void;
  addAIConcept: (concept: AIDesignConcept) => void;
  updateAIConcept: (concept: AIDesignConcept) => void;
  deleteAIConcept: (id: string) => void;
  addAICharacter: (char: AICharacter) => void;
  updateAICharacter: (char: AICharacter) => void;
  addAIWorld: (world: AIWorld) => void;
  updateAIWorld: (world: AIWorld) => void;
  addAICollection: (col: AICollection) => void;
  updateAICollection: (col: AICollection) => void;
  updateAISettings: (settings: Partial<AISettings>) => void;
  convertConceptToProductDraft: (concept: AIDesignConcept) => Promise<{ success: boolean; message: string; productId?: string }>;

  // Operations
  addProduct: (productData: Partial<AdminProduct>) => Promise<{ success: boolean; message: string; data?: AdminProduct }>;
  updateProduct: (id: string, updates: Partial<AdminProduct>) => Promise<{ success: boolean; message: string; data?: AdminProduct }>;
  archiveProduct: (id: string) => Promise<{ success: boolean; message: string }>;
  deleteProduct: (id: string) => Promise<{ success: boolean; message: string }>;
  duplicateProduct: (id: string) => void;
  bulkUpdateProducts: (ids: string[], action: 'PUBLISH' | 'ARCHIVE' | 'DELETE' | 'DISCOUNT', val?: any) => Promise<void>;

  updateStock: (variantId: string, newStock: number, reason: string) => void;
  deleteInventoryItem: (variantId: string, reason?: string) => void;
  bulkDeleteInventoryItems: (inventoryIds: string[], reason?: string) => Promise<{ success: boolean; deletedCount: number; message: string }>;
  updateOrderStatus: (orderId: string, status: OrderShippingStatus, note?: string) => void;
  addOrderInternalNote: (orderId: string, noteText: string) => void;
  cancelOrder: (orderId: string, reason: string) => void;
  initiateRefund: (orderId: string, amount: number, reason: string) => void;

  addCoupon: (coupon: Omit<Coupon, 'id' | 'usageCount'>) => void;
  toggleCoupon: (id: string) => void;
  deleteCoupon: (id: string) => void;

  addAdvertisement: (ad: Omit<Advertisement, 'id' | 'clicks' | 'impressions'>) => void;
  updateAdvertisement: (id: string, updates: Partial<Advertisement>) => void;
  deleteAdvertisement: (id: string) => void;

  saveWebsiteSections: (sections: WebsiteSection[]) => void;
  saveHeroSettings: (hero: HeroSettings) => void;

  processReturnRequest: (id: string, newStatus: ReturnRequest['status'], note?: string) => void;

  revokeSession: (id: string) => void;
  revokeAllOtherSessions: () => void;

  addStaffMember: (user: Omit<AdminUser, 'id' | 'lastLogin'>) => void;
  updateStaffRole: (userId: string, newRole: Role) => void;
  toggleStaffStatus: (userId: string) => void;

  updateSettings: (newSettings: Partial<StoreSettings>) => void;
  toggleMaintenanceMode: () => void;

  markNotificationAsRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;

  toastMessage: string | null;
  showToast: (msg: string) => void;
  resetToDemoData: () => void;
}

/**
 * Safely writes to localStorage with automatic eviction of expendable caches
 * and payload compression/sanitization to prevent QuotaExceededError.
 */
function safeLocalStorageSet(key: string, data: any): boolean {
  if (typeof window === 'undefined') return false;

  const tryWrite = (val: string): boolean => {
    try {
      localStorage.setItem(key, val);
      return true;
    } catch {
      return false;
    }
  };

  // 1. First attempt: standard JSON stringify
  try {
    const raw = JSON.stringify(data);
    if (tryWrite(raw)) return true;
  } catch {}

  // 2. If QuotaExceededError, evict low-priority ephemeral logs and cache keys
  const expendableKeys = [
    'tori_admin_ai_usage_logs',
    'tori_admin_auditLogs',
    'tori_admin_inv_movements',
    'tori_admin_securitySessions',
    'tori_admin_ads',
    'tori_admin_flashSales',
  ];
  for (const expKey of expendableKeys) {
    if (expKey !== key) {
      try {
        localStorage.removeItem(expKey);
      } catch {}
    }
  }

  // Retry write after evicting expendable keys
  try {
    const raw = JSON.stringify(data);
    if (tryWrite(raw)) return true;
  } catch {}

  // 3. If saving products, sanitize/compact large base64 images that consume megabytes
  if (key === 'tori_admin_products' && Array.isArray(data)) {
    try {
      const sanitized = data.map((p: any) => {
        const cleanImages = Array.isArray(p.images)
          ? p.images.map((img: string) => {
              if (typeof img === 'string' && img.startsWith('data:') && img.length > 1024) {
                return 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80';
              }
              return img;
            })
          : p.images;

        return {
          id: p.id,
          catalogNumber: p.catalogNumber,
          name: p.name,
          sku: p.sku,
          department: p.department,
          world: p.world,
          franchise: p.franchise,
          universe: p.universe,
          category: p.category,
          fit: p.fit,
          price: p.price,
          mrp: p.mrp,
          costPrice: p.costPrice,
          publishingStatus: p.publishingStatus,
          licenseRightsStatus: p.licenseRightsStatus,
          stock: p.stock,
          inStock: p.inStock,
          images: cleanImages,
          variants: Array.isArray(p.variants)
            ? p.variants.map((v: any) => ({
                id: v.id,
                sku: v.sku,
                size: v.size,
                colorName: v.colorName,
                colorHex: v.colorHex,
                price: v.price,
                stock: v.stock,
              }))
            : [],
        };
      });

      const sanitizedRaw = JSON.stringify(sanitized);
      if (tryWrite(sanitizedRaw)) {
        return true;
      }
    } catch {}
  }

  // 4. Graceful degradation: The backend database and React state remain authoritative.
  console.warn(`[AdminData] Local storage quota reached. Falling back to in-memory & authoritative database for "${key}".`);
  return false;
}

const AdminDataContext = createContext<AdminDataContextType | undefined>(undefined);

export const AdminDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check LocalStorage or seed with INITIAL_*
  const loadInitial = <T,>(key: string, fallback: T): T => {
    try {
      const stored = localStorage.getItem(`tori_admin_${key}`);
      if (!stored) return fallback;
      // Purge legacy mock data strings from storage
      if (
        (key === 'orders' && (stored.includes('ord-104') || stored.includes('TORI-104'))) ||
        (key === 'payments' && (stored.includes('tx-90') || stored.includes('PAY-104') || stored.includes('pay-'))) ||
        (key === 'customers' && (stored.includes('cust-01') || stored.includes('Rohan Sharma') || stored.includes('Aarav Kapoor') || stored.includes('Kavya Nair'))) ||
        (key === 'inv_movements' && (stored.includes('mov-101') || stored.includes('Tirupur'))) ||
        (key === 'return_requests' && stored.includes('ret-101')) ||
        (key === 'returnRequests' && stored.includes('ret-101'))
      ) {
        localStorage.removeItem(`tori_admin_${key}`);
        return fallback;
      }
      return JSON.parse(stored);
    } catch (e) {
      return fallback;
    }
  };

  // CRITICAL SECURITY FIX: Never initialize unauthenticated visitor as Mohammed Saif or any Super Admin!
  // Initialize strictly to null and verify session token asynchronously against backend /api/auth/me.
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(true);
  const [pendingTempToken, setPendingTempToken] = useState<string>('');
  const [twoFactorRequired, setTwoFactorRequired] = useState<boolean>(false);
  const [loginEmail, setLoginEmail] = useState<string>('');
  const [currentView, setCurrentView] = useState<AdminView>('DASHBOARD');

  // Verify active session with authoritative server upon initialization
  useEffect(() => {
    let isMounted = true;
    const verifySession = async () => {
      const token = getSessionToken();
      if (!token) {
        if (isMounted) {
          setCurrentUser(null);
          setIsAuthChecking(false);
        }
        return;
      }

      try {
        const res = await platformApi.getMe();
        if (isMounted && res && res.authenticated && res.user) {
          const mappedUser: AdminUser = {
            id: res.user.id,
            name: res.user.name,
            email: res.user.email,
            role: res.user.role as any,
            department: res.user.department || 'Executive Leadership',
            avatarUrl: res.user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
            twoFactorEnabled: res.user.twoFactorEnabled,
            lastLogin: 'Active now',
            isActive: true,
          };
          setCurrentUser(mappedUser);
        } else if (isMounted) {
          clearSessionToken();
          setCurrentUser(null);
        }
      } catch (err) {
        if (isMounted) {
          clearSessionToken();
          setCurrentUser(null);
        }
      } finally {
        if (isMounted) {
          setIsAuthChecking(false);
        }
      }
    };

    verifySession();
    return () => {
      isMounted = false;
    };
  }, []);
  const [selectedSubFilter, setSelectedSubFilter] = useState<string | undefined>(undefined);
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);

  // States
  const [products, setProducts] = useState<AdminProduct[]>(() => loadInitial('products', INITIAL_ADMIN_PRODUCTS));
  const [inventory, setInventory] = useState<InventoryItem[]>(() => loadInitial('inventory', INITIAL_INVENTORY_ITEMS));
  const [inventoryMovements, setInventoryMovements] = useState<InventoryMovement[]>(() => loadInitial('inv_movements', INITIAL_INVENTORY_MOVEMENTS));
  const [orders, setOrders] = useState<AdminOrder[]>(() => loadInitial('orders', INITIAL_ORDERS));
  const [payments, setPayments] = useState<PaymentTransaction[]>(() => loadInitial('payments', INITIAL_PAYMENT_TRANSACTIONS));
  const [customers, setCustomers] = useState<CustomerProfile[]>(() => loadInitial('customers', INITIAL_CUSTOMERS));
  const [coupons, setCoupons] = useState<Coupon[]>(() => loadInitial('coupons', INITIAL_COUPONS));
  const [ads, setAds] = useState<Advertisement[]>(() => loadInitial('ads', INITIAL_ADVERTISEMENTS));
  const [flashSales, setFlashSales] = useState<FlashSaleCampaign[]>(() => loadInitial('flashSales', INITIAL_FLASH_SALES));
  const [websiteSections, setWebsiteSections] = useState<WebsiteSection[]>(() => loadInitial('websiteSections', INITIAL_WEBSITE_SECTIONS));
  const [heroSettings, setHeroSettings] = useState<HeroSettings>(() => loadInitial('heroSettings', INITIAL_HERO_SETTINGS));
  const [returnRequests, setReturnRequests] = useState<ReturnRequest[]>(() => loadInitial('returnRequests', INITIAL_RETURN_REQUESTS));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => loadInitial('auditLogs', INITIAL_AUDIT_LOGS));
  const [securitySessions, setSecuritySessions] = useState<SecuritySession[]>(() => loadInitial('securitySessions', INITIAL_SECURITY_SESSIONS));
  const [staff, setStaff] = useState<AdminUser[]>(() => loadInitial('staff', INITIAL_ADMIN_USERS));
  const [settings, setSettings] = useState<StoreSettings>(() => loadInitial('settings', INITIAL_STORE_SETTINGS));

  // AI Design Lab States
  const [aiConcepts, setAiConcepts] = useState<AIDesignConcept[]>(() => loadInitial('ai_concepts', INITIAL_AI_CONCEPTS));
  const [aiCharacters, setAiCharacters] = useState<AICharacter[]>(() => loadInitial('ai_characters', INITIAL_AI_CHARACTERS));
  const [aiWorlds, setAiWorlds] = useState<AIWorld[]>(() => loadInitial('ai_worlds', INITIAL_AI_WORLDS));
  const [aiCollections, setAiCollections] = useState<AICollection[]>(() => loadInitial('ai_collections', INITIAL_AI_COLLECTIONS));
  const [aiSettings, setAiSettings] = useState<AISettings>(() => loadInitial('ai_settings', INITIAL_AI_SETTINGS));
  const [aiUsageLogs, setAiUsageLogs] = useState<AIUsageLog[]>(() => loadInitial('ai_usage_logs', INITIAL_AI_USAGE_LOGS));
  const [selectedConcept, setSelectedConcept] = useState<AIDesignConcept | null>(null);

  const [notifications, setNotifications] = useState<AdminNotification[]>([]);


  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Sync to local storage safely without quota crashes
  useEffect(() => {
    safeLocalStorageSet('tori_admin_currentUser', currentUser);
    safeLocalStorageSet('tori_admin_products', products);
    safeLocalStorageSet('tori_admin_inventory', inventory);
    safeLocalStorageSet('tori_admin_orders', orders);
    safeLocalStorageSet('tori_admin_customers', customers);
    safeLocalStorageSet('tori_admin_coupons', coupons);
    safeLocalStorageSet('tori_admin_settings', settings);
    safeLocalStorageSet('tori_admin_heroSettings', heroSettings);
    safeLocalStorageSet('tori_admin_websiteSections', websiteSections);
    safeLocalStorageSet('tori_admin_ai_concepts', aiConcepts);
    safeLocalStorageSet('tori_admin_ai_characters', aiCharacters);
    safeLocalStorageSet('tori_admin_ai_worlds', aiWorlds);
    safeLocalStorageSet('tori_admin_ai_collections', aiCollections);
    safeLocalStorageSet('tori_admin_ai_settings', aiSettings);
    safeLocalStorageSet('tori_admin_ai_usage_logs', aiUsageLogs);
  }, [currentUser, products, inventory, orders, customers, coupons, settings, heroSettings, websiteSections, aiConcepts, aiCharacters, aiWorlds, aiCollections, aiSettings, aiUsageLogs]);

  // Real-time synchronization of customer signups and activities from storefront
  useEffect(() => {
    const handleCustomerSync = (e?: any) => {
      try {
        if (e && e.key && e.key !== 'tori_admin_customers') return;
        const stored = localStorage.getItem('tori_admin_customers');
        if (stored) {
          const parsed = JSON.parse(stored);
          setCustomers(prev => {
            if (JSON.stringify(prev) === stored) return prev;
            return parsed;
          });
        }
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleCustomerSync);
    window.addEventListener('tori_customer_updated', handleCustomerSync);
    return () => {
      window.removeEventListener('storage', handleCustomerSync);
      window.removeEventListener('tori_customer_updated', handleCustomerSync);
    };
  }, []);

  // Real-time synchronization of customer orders placed or updated on storefront
  useEffect(() => {
    const handleOrderSync = (e?: any) => {
      try {
        if (e && e.key && e.key !== 'tori_admin_orders') return;
        const stored = localStorage.getItem('tori_admin_orders');
        if (stored) {
          const parsed = JSON.parse(stored);
          setOrders(prev => {
            if (JSON.stringify(prev) === stored) return prev;
            return parsed;
          });
        }
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleOrderSync);
    window.addEventListener('tori_admin_orders_updated', handleOrderSync);
    return () => {
      window.removeEventListener('storage', handleOrderSync);
      window.removeEventListener('tori_admin_orders_updated', handleOrderSync);
    };
  }, []);

  // Fetch server-authoritative orders from backend API
  useEffect(() => {
    let isMounted = true;
    apiClient.getAdminOrders().then((res) => {
      if (isMounted && res.success && Array.isArray(res.data)) {
        setOrders(res.data.map((o: any) => {
          const rawMethod = String(o.paymentMethod || 'UPI').toUpperCase();
          const mappedMethod = rawMethod.includes('CARD')
            ? ('Credit Card' as const)
            : rawMethod.includes('NET')
            ? ('Net Banking' as const)
            : rawMethod === 'COD'
            ? ('COD' as const)
            : ('UPI' as const);

          const rawStatus = String(o.fulfillmentStatus || o.shippingStatus || 'CONFIRMED').toUpperCase();
          const validStatuses = ['CONFIRMED', 'PROCESSING', 'PACKED', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED', 'RETURNED'];
          const mappedShippingStatus = validStatuses.includes(rawStatus) ? (rawStatus as any) : 'CONFIRMED';

          return {
            orderId: o.id || o.orderId,
            orderNumber: o.orderNumber || `#${o.id || o.orderId}`,
            date: o.createdAt ? new Date(o.createdAt).toLocaleString('en-IN') : o.date || 'Recent',
            customerId: o.customerId || 'GUEST',
            customerName: o.customerName || 'Customer',
            customerEmail: o.customerEmail || '',
            customerPhone: o.customerPhone || '',
            shippingAddress: {
              fullName: o.shippingAddress?.fullName || o.customerName || 'Customer',
              addressLine1: o.shippingAddress?.addressLine1 || '',
              addressLine2: o.shippingAddress?.addressLine2 || undefined,
              city: o.shippingAddress?.city || '',
              state: o.shippingAddress?.state || '',
              pincode: o.shippingAddress?.pincode || '',
            },
            items: (o.items || []).map((it: any) => ({
              productId: it.productId,
              productName: it.productName,
              variantId: it.variantId || `${it.productId}-${it.size}-${it.color}`,
              sku: it.sku || `SKU-${it.productId}`,
              size: it.size,
              color: it.color,
              image: it.image || '',
              quantity: it.quantity,
              unitPrice: it.unitPrice,
              totalPrice: it.totalPrice,
            })),
            subtotal: o.subtotal,
            discount: o.discount || 0,
            discountCode: o.discountCode,
            tax: o.tax || 0,
            shippingFee: o.shippingFee ?? 0,
            total: o.total,
            paymentMethod: mappedMethod,
            paymentStatus: (o.paymentStatus || 'PAID') as any,
            shippingStatus: mappedShippingStatus,
            courier: o.courierPartner || o.courier,
            trackingNumber: o.courierTrackingNumber || o.trackingNumber,
            estimatedDelivery: o.estimatedDeliveryDate || o.estimatedDelivery || '3 to 5 Business Days',
            timeline: (o.timeline || []).map((tl: any) => ({
              title: tl.status || tl.title || 'Update',
              timestamp: tl.timestamp,
              note: tl.description || tl.note,
            })),
            internalNotes: o.internalNotes || [],
          };
        }));
      }
    }).catch((err) => console.warn('[AdminData] Async fetch orders from API:', err));

    return () => { isMounted = false; };
  }, []);

  // Track last catalog write timestamp to prevent stale GET responses from racing
  const lastProductMutationTimeRef = useRef<number>(0);

  // Fetch server-authoritative products from backend API for Admin Products Vault
  useEffect(() => {
    let isMounted = true;
    const fetchStartTime = Date.now();

    apiClient.getAdminProducts().then((res) => {
      // Prevent stale response from overwriting newer local edits/creates/deletes
      if (!isMounted) return;
      if (lastProductMutationTimeRef.current > fetchStartTime) {
        console.log('[AdminData] ⏭️ Skipping stale getAdminProducts response as a newer mutation occurred.');
        return;
      }

      if (res.success && Array.isArray(res.data)) {
        const mappedProducts: AdminProduct[] = res.data.map((rp: any) => {
          const dept: 'MEN' | 'KIDS' = rp.department === 'KIDS' || rp.universe === 'KIDS' ? 'KIDS' : 'MEN';
          return {
            id: rp.id,
            catalogNumber: rp.catalogNumber || '00',
            name: rp.name,
            sku: rp.sku || `TORI-${rp.catalogNumber || '00'}`,
            department: dept,
            world: rp.world || (dept === 'KIDS' ? 'CUTE ADVENTURE' : 'DARK SHONEN'),
            franchise: rp.franchise || 'Toriwear Originals',
            universe: rp.universe || (dept === 'KIDS' ? 'KIDS' : 'ORIGINALS'),
            category: rp.category || 'Oversized Tees',
            fit: rp.fit || 'Oversized',
            price: Number(rp.price) || 1199,
            mrp: Number(rp.originalPrice || rp.mrp) || Math.round((Number(rp.price) || 1199) * 1.3),
            costPrice: Number(rp.costPrice) || 450,
            discountPercent: 25,
            gstRate: 5,
            rating: rp.rating || 5.0,
            reviewsCount: rp.reviewsCount || 0,
            images: Array.isArray(rp.images) && rp.images.length > 0 ? rp.images : ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80'],
            description: rp.description || '',
            shortDescription: `${rp.gsm || 240} GSM streetwear fit.`,
            storyQuote: rp.storyQuote || 'Wear Your World.',
            drop: rp.drop || 'CHAPTER 01 — ORIGINALS',
            gsm: Number(rp.gsm) || 240,
            fabric: rp.fabric || '100% Combed Heavyweight Cotton',
            neck: rp.neck || 'High-Ribbed Crewneck',
            sleeves: rp.sleeves || 'Drop Shoulder Half Sleeves',
            print: rp.print || 'High-Density Screen Print',
            tags: ['streetwear', 'anime'],
            seoTitle: `${rp.name} | TORIWEAR`,
            seoDescription: 'Shop official heavyweight streetwear from Toriwear.',
            slug: rp.slug || rp.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            publishingStatus: (rp.status || rp.publishingStatus || 'PUBLISHED') as any,
            licenseRightsStatus: (rp.licenseRightsStatus || 'Owned IP') as any,
            variants: Array.isArray(rp.variants) && rp.variants.length > 0 
              ? rp.variants.map((v: any) => ({
                  id: v.id,
                  sku: v.sku || `SKU-${v.id}`,
                  size: v.size || 'M',
                  colorName: v.colorName || 'Obsidian Black',
                  colorHex: v.colorHex || '#111115',
                  price: Number(v.price) || Number(rp.price) || 1199,
                  stock: v.stock !== undefined && !isNaN(Number(v.stock)) ? Number(v.stock) : 25,
                  reserved: Number(v.reservedStock) || 0,
                  barcode: `89000${v.id}`,
                  weightGrams: 340,
                }))
              : [
                  { id: `var-${rp.id}-s`, sku: `${rp.sku || 'TORI'}-S`, size: 'S', colorName: 'Obsidian Black', colorHex: '#111115', price: rp.price || 1199, stock: 20, reserved: 0, barcode: '8901001', weightGrams: 320 },
                  { id: `var-${rp.id}-m`, sku: `${rp.sku || 'TORI'}-M`, size: 'M', colorName: 'Obsidian Black', colorHex: '#111115', price: rp.price || 1199, stock: 35, reserved: 0, barcode: '8901002', weightGrams: 340 },
                  { id: `var-${rp.id}-l`, sku: `${rp.sku || 'TORI'}-L`, size: 'L', colorName: 'Obsidian Black', colorHex: '#111115', price: rp.price || 1199, stock: 40, reserved: 0, barcode: '8901003', weightGrams: 360 },
                  { id: `var-${rp.id}-xl`, sku: `${rp.sku || 'TORI'}-XL`, size: 'XL', colorName: 'Obsidian Black', colorHex: '#111115', price: rp.price || 1199, stock: 25, reserved: 0, barcode: '8901004', weightGrams: 380 },
                ],
            totalSold: 0,
            createdAt: rp.createdAt || new Date().toISOString(),
            updatedAt: rp.updatedAt || new Date().toISOString(),
          };
        });
        setProducts(mappedProducts);
        safeLocalStorageSet('tori_admin_products', mappedProducts);
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('tori_admin_products_updated', { detail: mappedProducts }));
        }
      }
    }).catch((err) => console.warn('[AdminData] Async fetch admin products from API:', err));

    return () => { isMounted = false; };
  }, []);

  // Fetch server-authoritative coupons
  useEffect(() => {
    let isMounted = true;
    const token = getSessionToken();
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;

    fetch('/api/v1/admin/coupons', { headers })
      .then(res => res.json())
      .then(res => {
        if (isMounted && res.success && Array.isArray(res.data) && res.data.length > 0) {
          const mapped: Coupon[] = res.data.map((c: any) => ({
            id: c.id,
            code: c.code,
            discountType: c.discountType,
            value: Number(c.value),
            minOrderValue: Number(c.minOrderValue || 0),
            maxDiscount: c.maxDiscount ? Number(c.maxDiscount) : undefined,
            usageLimit: c.usageLimit ? Number(c.usageLimit) : undefined,
            usageCount: Number(c.usageCount || 0),
            startDate: c.startDate ? new Date(c.startDate).toISOString().split('T')[0] : '2026-01-01',
            expiryDate: c.expiryDate ? new Date(c.expiryDate).toISOString().split('T')[0] : '2026-12-31',
            isActive: c.isActive !== false,
            description: c.description || '',
          }));
          setCoupons(mapped);
          safeLocalStorageSet('tori_admin_coupons', mapped);
        }
      })
      .catch((err) => console.warn('[AdminData] Async fetch coupons error:', err));

    return () => { isMounted = false; };
  }, [currentUser]);

  // Fetch server-authoritative CMS & settings
  useEffect(() => {
    let isMounted = true;
    fetch('/api/v1/cms/frontpage')
      .then(res => res.json())
      .then(res => {
        if (isMounted && res.success && res.data) {
          if (Array.isArray(res.data.sections) && res.data.sections.length > 0) {
            setWebsiteSections(res.data.sections);
            safeLocalStorageSet('tori_admin_websiteSections', res.data.sections);
          }
          if (res.data.hero) {
            setHeroSettings(res.data.hero);
            safeLocalStorageSet('tori_admin_heroSettings', res.data.hero);
          }
        }
      })
      .catch(() => {});

    fetch('/api/v1/cms/settings')
      .then(res => res.json())
      .then(res => {
        if (isMounted && res.success && res.data) {
          setSettings(prev => ({
            ...prev,
            ...res.data,
          }));
        }
      })
      .catch(() => {});

    return () => { isMounted = false; };
  }, []);

  // Listen to product storage events and local custom update events
  useEffect(() => {
    const handleProductsUpdated = () => {
      try {
        const stored = localStorage.getItem('tori_admin_products');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setProducts((prev) => {
              if (prev.length === parsed.length && prev[0]?.id === parsed[0]?.id) return prev;
              return parsed;
            });
          }
        }
      } catch {}
    };
    window.addEventListener('storage', handleProductsUpdated);
    window.addEventListener('tori_admin_products_updated', handleProductsUpdated);
    return () => {
      window.removeEventListener('storage', handleProductsUpdated);
      window.removeEventListener('tori_admin_products_updated', handleProductsUpdated);
    };
  }, []);

  const logAction = (
    action: AuditLog['action'], 
    entity: string, 
    details: string, 
    oldValue?: string, 
    newValue?: string
  ) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      adminName: currentUser?.name || 'System Operator',
      adminEmail: currentUser?.email || 'admin@toriwear.com',
      action,
      entity,
      details,
      oldValue,
      newValue,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST (Today)',
      ipAddress: '152.58.112.9 (Session)',
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Permission check
  const hasPermission = (permission: string): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'SUPER_ADMIN') return true;
    const allowed = ROLE_PERMISSIONS[currentUser.role] || [];
    return allowed.includes(permission as any);
  };

  const loginWithSession = (user: any) => {
    const mappedUser: AdminUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role as any,
      department: user.department || 'Management',
      avatarUrl: user.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      twoFactorEnabled: user.twoFactorEnabled,
      lastLogin: 'Active now',
      isActive: true,
    };
    setCurrentUser(mappedUser);
    setTwoFactorRequired(false);
    setPendingTempToken('');
    safeLocalStorageSet('tori_admin_currentUser', mappedUser);
    logAction('LOGIN_SUCCESS', 'Admin Session', `Authenticated session established for ${mappedUser.email} (${mappedUser.role})`);
    showToast(`Welcome back, ${mappedUser.name}!`);
  };

  // Auth operations — Genuine server-side authentication
  const login = async (email: string, pass: string, remember: boolean = true) => {
    try {
      const res = await platformApi.login(email, pass, remember);
      if (!res.success) {
        return { success: false, error: res.error || 'Invalid credentials. Please verify your email/ID and password.' };
      }

      if (res.requires2FA && res.tempToken) {
        setLoginEmail(email);
        setPendingTempToken(res.tempToken);
        setTwoFactorRequired(true);
        return { success: true, requires2fa: true, tempToken: res.tempToken };
      }

      if (res.user) {
        loginWithSession(res.user);
        return { success: true };
      }

      return { success: false, error: 'Unexpected login response from authentication server.' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Error communicating with authentication server.' };
    }
  };

  const verify2FA = async (code: string, tempTokenOverride?: string) => {
    const tokenToUse = tempTokenOverride || pendingTempToken;
    if (!tokenToUse) {
      showToast('2FA challenge expired. Please sign in again.');
      return false;
    }

    try {
      const res = await platformApi.verify2FA(tokenToUse, code);
      if (res.success && res.user) {
        loginWithSession(res.user);
        showToast(`2FA Verified. Welcome to Toriwear Command Center, ${res.user.name}.`);
        return true;
      } else {
        showToast(res.error || 'Invalid 2FA verification code.');
        return false;
      }
    } catch (err: any) {
      showToast(err.message || 'Verification error.');
      return false;
    }
  };

  const logout = () => {
    platformApi.logout();
    logAction('LOGIN_SUCCESS', 'Admin Session', `User ${currentUser?.email || 'admin'} logged out`);
    setCurrentUser(null);
    setTwoFactorRequired(false);
    setPendingTempToken('');
    safeLocalStorageSet('tori_admin_currentUser', null);
    showToast('Logged out securely.');
  };

  // Immediate synchronous persistence helpers to prevent state drops on unmount/navigation
  const persistProductsImmediately = (updatedProducts: AdminProduct[]) => {
    setProducts(updatedProducts);
    safeLocalStorageSet('tori_admin_products', updatedProducts);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('tori_admin_products_updated', { detail: updatedProducts }));
    }
  };

  const persistInventoryImmediately = (updatedInventory: InventoryItem[]) => {
    setInventory(updatedInventory);
    safeLocalStorageSet('tori_admin_inventory', updatedInventory);
  };

  // Products CRUD — Authoritative Database-First Operations
  const addProduct = async (productData: Partial<AdminProduct>): Promise<{ success: boolean; message: string; data?: AdminProduct }> => {
    // Publishing safeguard
    if (settings.enforceApprovedLicenseOnly && productData.licenseRightsStatus === 'Not Authorized') {
      return { 
        success: false, 
        message: 'Publishing blocked: Products marked "Not Authorized" cannot be published under Toriwear IP compliance rules.' 
      };
    }

    const cleanName = (productData.name || '').trim();
    if (!cleanName) {
      return { success: false, message: 'Product Name / Title is required.' };
    }
    const cleanPrice = Number(productData.price);
    if (!cleanPrice || cleanPrice <= 0) {
      return { success: false, message: 'Selling price must be greater than ₹0.' };
    }

    const newId = productData.id || `tori-custom-${Date.now()}`;
    const newCatalogNum = productData.catalogNumber || `PR-${Math.floor(1000 + Math.random() * 9000)}`;
    const dept: 'MEN' | 'KIDS' = productData.department || (productData.universe === 'KIDS' ? 'KIDS' : 'MEN');
    const world: string = productData.world || (dept === 'KIDS' ? 'CUTE ADVENTURE' : 'DARK SHONEN');

    const defaultImages = [
      dept === 'KIDS'
        ? 'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=900&auto=format&fit=crop&q=80',
    ];

    const finalImages = productData.images && productData.images.length > 0 ? productData.images : defaultImages;

    const created: AdminProduct = {
      id: newId,
      catalogNumber: newCatalogNum,
      name: cleanName,
      sku: productData.sku || `TORI-TSHIRT-${newCatalogNum}`,
      department: dept,
      world,
      franchise: productData.franchise || (world as any) || 'Toriwear Originals',
      universe: productData.universe || (dept === 'KIDS' ? 'KIDS' : 'ORIGINALS'),
      category: productData.category || 'Oversized Tees',
      fit: productData.fit || (dept === 'KIDS' ? 'Comfort Fit' : 'Oversized'),
      price: cleanPrice,
      mrp: Number(productData.mrp) || Math.round(cleanPrice * 1.3),
      costPrice: Number(productData.costPrice) || 450,
      discountPercent: productData.discountPercent || 25,
      gstRate: productData.gstRate || 5,
      rating: 5.0,
      reviewsCount: 1,
      images: finalImages,
      description: productData.description || 'Premium heavyweight anime streetwear tee.',
      shortDescription: productData.shortDescription || `${dept === 'KIDS' ? '180' : '240'} GSM drop-shoulder streetwear fit.`,
      storyQuote: productData.storyQuote || 'Wear Your World.',
      drop: productData.drop || 'DROP 002 — SHINOBI',
      gsm: productData.gsm || (dept === 'KIDS' ? 180 : 240),
      fabric: productData.fabric || '100% Combed Heavyweight Cotton',
      neck: productData.neck || 'High-Ribbed Crewneck',
      sleeves: productData.sleeves || 'Drop Shoulder Half Sleeves',
      print: productData.print || 'High-Density Puff & Screen Print',
      tags: productData.tags || ['streetwear', 'anime', 'heavyweight'],
      seoTitle: `${cleanName} | TORIWEAR`,
      seoDescription: 'Shop official heavyweight streetwear from Toriwear.',
      slug: cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      publishingStatus: productData.publishingStatus || 'PUBLISHED',
      licenseRightsStatus: productData.licenseRightsStatus || 'Owned IP',
      variants: productData.variants && productData.variants.length > 0 
        ? productData.variants 
        : [
            { id: `var-${newId}-S`, sku: `TORI-${newCatalogNum}-S`, size: 'S', colorName: 'Obsidian Black', colorHex: '#111115', price: cleanPrice, stock: 20, reserved: 0, barcode: `89000${newCatalogNum}1`, weightGrams: 320 },
            { id: `var-${newId}-M`, sku: `TORI-${newCatalogNum}-M`, size: 'M', colorName: 'Obsidian Black', colorHex: '#111115', price: cleanPrice, stock: 35, reserved: 0, barcode: `89000${newCatalogNum}2`, weightGrams: 340 },
            { id: `var-${newId}-L`, sku: `TORI-${newCatalogNum}-L`, size: 'L', colorName: 'Obsidian Black', colorHex: '#111115', price: cleanPrice, stock: 40, reserved: 0, barcode: `89000${newCatalogNum}3`, weightGrams: 360 },
            { id: `var-${newId}-XL`, sku: `TORI-${newCatalogNum}-XL`, size: 'XL', colorName: 'Obsidian Black', colorHex: '#111115', price: cleanPrice, stock: 25, reserved: 0, barcode: `89000${newCatalogNum}4`, weightGrams: 380 },
          ],
      totalSold: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Await authoritative persistence to backend database FIRST
    try {
      const apiRes = await apiClient.adminCreateProduct(created);
      if (!apiRes || !apiRes.success) {
        const errorMsg = apiRes?.error || 'Database save failed. Product was NOT saved.';
        console.error('[AdminData] Product creation failed on backend:', errorMsg);
        return { success: false, message: errorMsg };
      }
      lastProductMutationTimeRef.current = Date.now();
    } catch (err: any) {
      console.error('[AdminData] Network error saving product to backend:', err);
      return { success: false, message: err.message || 'Database connection error. Product was NOT saved.' };
    }

    // Only after successful database persistence, update local state & fallback cache
    const updatedProducts = [created, ...products.filter(p => p.id !== created.id)];
    persistProductsImmediately(updatedProducts);

    // Also add to inventory items
    const newInvItems: InventoryItem[] = created.variants.map(v => ({
      id: `inv-${v.id}`,
      productId: created.id,
      productName: created.name,
      variantId: v.id,
      sku: v.sku,
      size: v.size,
      colorName: v.colorName,
      availableStock: v.stock,
      reservedStock: 0,
      sold: 0,
      lowStockThreshold: 5,
      criticalThreshold: 2,
      status: v.stock > 5 ? 'IN_STOCK' : 'LOW_STOCK',
      lastUpdated: 'Just now',
    }));
    const updatedInventory = [...newInvItems, ...inventory];
    persistInventoryImmediately(updatedInventory);

    logAction('PRODUCT_CREATED', `Product #${created.catalogNumber} (${created.name})`, `Created with ${created.variants.length} variants at ₹${created.price}`);
    showToast(`Product "${created.name}" created and saved to database!`);
    return { success: true, message: 'Product added successfully', data: created };
  };

  const updateProduct = async (id: string, updates: Partial<AdminProduct>): Promise<{ success: boolean; message: string; data?: AdminProduct }> => {
    const existing = products.find(p => p.id === id);
    if (!existing) {
      return { success: false, message: `Product ${id} not found.` };
    }

    // If variants were modified, recalculate total stock and availability
    let enrichedUpdates = { ...updates };
    if (Array.isArray(updates.variants)) {
      const totalStock = updates.variants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
      (enrichedUpdates as any).stock = totalStock;
      (enrichedUpdates as any).inStock = totalStock > 0;
    }

    // Persist to authoritative backend database first
    try {
      const apiRes = await apiClient.adminUpdateProduct(id, enrichedUpdates);
      if (!apiRes || !apiRes.success) {
        const errorMsg = apiRes?.error || 'Failed to update product in database.';
        console.error('[AdminData] Product update failed on backend:', errorMsg);
        return { success: false, message: errorMsg };
      }
      lastProductMutationTimeRef.current = Date.now();
    } catch (err: any) {
      console.error('[AdminData] Network error updating product on backend:', err);
      return { success: false, message: err.message || 'Database connection error while updating product.' };
    }

    const updated = { ...existing, ...enrichedUpdates, updatedAt: new Date().toISOString() };
    const updatedProducts = products.map(p => (p.id === id ? updated : p));
    persistProductsImmediately(updatedProducts);

    // If variants were provided, also keep inventory state in sync
    if (Array.isArray(updates.variants)) {
      setInventory(prevInv => {
        const nextInv = prevInv.map(item => {
          const matchingVar = updates.variants?.find(v => v.id === item.variantId || v.sku === item.sku);
          if (matchingVar && matchingVar.stock !== undefined) {
            const st = Number(matchingVar.stock);
            let s: InventoryItem['status'] = 'IN_STOCK';
            if (st === 0) s = 'OUT_OF_STOCK';
            else if (st <= item.criticalThreshold) s = 'CRITICAL_STOCK';
            else if (st <= item.lowStockThreshold) s = 'LOW_STOCK';
            return {
              ...item,
              availableStock: st,
              status: s,
              lastUpdated: 'Just now',
            };
          }
          return item;
        });
        persistInventoryImmediately(nextInv);
        return nextInv;
      });
    }

    if (updates.price && updates.price !== existing.price) {
      logAction('PRICE_UPDATED', `Product #${existing.catalogNumber} (${existing.name})`, `Price modified from ₹${existing.price} to ₹${updates.price}`, `₹${existing.price}`, `₹${updates.price}`);
    } else {
      logAction('PRODUCT_UPDATED', `Product #${existing.catalogNumber} (${existing.name})`, 'Metadata, pricing or variants modified.');
    }
    showToast(`Product "${existing.name}" updated successfully.`);
    return { success: true, message: 'Product updated successfully', data: updated };
  };

  const archiveProduct = async (id: string): Promise<{ success: boolean; message: string }> => {
    const target = products.find(p => p.id === id);
    if (!target) return { success: false, message: 'Product not found.' };

    try {
      const apiRes = await apiClient.adminArchiveProduct(id);
      if (!apiRes || !apiRes.success) {
        const errorMsg = apiRes?.error || 'Failed to archive product on backend.';
        showToast(`Error: ${errorMsg}`);
        return { success: false, message: errorMsg };
      }
      lastProductMutationTimeRef.current = Date.now();
    } catch (err: any) {
      console.error('[AdminData] Network error archiving product:', err);
      showToast('Database error archiving product.');
      return { success: false, message: err.message || 'Database error archiving product.' };
    }

    const updatedProducts = products.map(p => p.id === id ? { ...p, publishingStatus: 'ARCHIVED' as const } : p);
    persistProductsImmediately(updatedProducts);
    logAction('PRODUCT_ARCHIVED', `Product #${target.catalogNumber} (${target.name})`, 'Archived and hidden from customer storefront.');
    showToast(`Product "${target.name}" archived.`);
    return { success: true, message: 'Product archived successfully' };
  };

  const deleteProduct = async (id: string): Promise<{ success: boolean; message: string }> => {
    const target = products.find(p => p.id === id);
    const targetName = target ? target.name : id;
    const targetCatalog = target ? target.catalogNumber : id;

    try {
      const apiRes = await apiClient.adminDeleteProduct(id);
      if (!apiRes || !apiRes.success) {
        console.warn('[AdminData] Product delete API returned warning:', apiRes?.error);
      }
      lastProductMutationTimeRef.current = Date.now();
    } catch (err: any) {
      console.warn('[AdminData] Network error deleting product on backend:', err);
    }

    // Atomically update products state
    setProducts(prev => {
      const next = prev.filter(p => p.id !== id);
      safeLocalStorageSet('tori_admin_products', next);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('tori_admin_products_updated', { detail: next }));
      }
      return next;
    });

    // Atomically remove linked inventory records
    setInventory(prev => {
      const next = prev.filter(item => item.productId !== id);
      safeLocalStorageSet('tori_admin_inventory', next);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('tori_admin_inventory_updated', { detail: next }));
      }
      return next;
    });

    logAction('PRODUCT_DELETED', `Product #${targetCatalog} (${targetName})`, 'Permanently deleted from product catalogue and database.');
    showToast(`Product "${targetName}" permanently deleted.`);
    return { success: true, message: 'Product deleted successfully' };
  };

  const duplicateProduct = (id: string) => {
    const target = products.find(p => p.id === id);
    if (!target) return;
    const duplicated: AdminProduct = {
      ...target,
      id: `tori-dup-${Date.now()}`,
      catalogNumber: String(products.length + 1).padStart(2, '0'),
      name: `${target.name} (Copy)`,
      sku: `${target.sku}-COPY`,
      publishingStatus: 'DRAFT',
      totalSold: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    // Persist duplicated product to backend asynchronously
    apiClient.adminCreateProduct(duplicated).then(() => {
      lastProductMutationTimeRef.current = Date.now();
      const updatedProducts = [duplicated, ...products];
      persistProductsImmediately(updatedProducts);
      logAction('PRODUCT_CREATED', `Product #${duplicated.catalogNumber} (${duplicated.name})`, `Duplicated from ${target.name}`);
      showToast(`Duplicated "${target.name}" as a draft.`);
    }).catch(err => {
      console.warn('[AdminData] Error duplicating product on backend:', err);
      showToast('Failed to duplicate product on database.');
    });
  };

  const bulkUpdateProducts = async (ids: string[], action: 'PUBLISH' | 'ARCHIVE' | 'DELETE' | 'DISCOUNT', val?: any): Promise<void> => {
    lastProductMutationTimeRef.current = Date.now();

    if (action === 'PUBLISH') {
      let publishedCount = 0;
      let blockedCount = 0;
      const updatedProducts = products.map(p => {
        if (ids.includes(p.id)) {
          const hasValidImage = p.images && p.images.some(img => isValidProductImageUrl(img));
          if (hasValidImage) {
            publishedCount++;
            return { ...p, publishingStatus: 'PUBLISHED' as const };
          } else {
            blockedCount++;
            return p;
          }
        }
        return p;
      });
      persistProductsImmediately(updatedProducts);
      // Persist to backend
      for (const id of ids) {
        const prod = updatedProducts.find(p => p.id === id);
        if (prod && prod.publishingStatus === 'PUBLISHED') {
          apiClient.adminUpdateProduct(id, { publishingStatus: 'PUBLISHED' }).catch(() => {});
        }
      }
      if (blockedCount > 0) {
        showToast(`${publishedCount} published. ${blockedCount} blocked (missing valid product image).`);
      } else {
        showToast(`${publishedCount} products published to live storefront.`);
      }
    } else if (action === 'ARCHIVE') {
      const updatedProducts = products.map(p => ids.includes(p.id) ? { ...p, publishingStatus: 'ARCHIVED' as const } : p);
      persistProductsImmediately(updatedProducts);
      ids.forEach(id => {
        apiClient.adminArchiveProduct(id).catch(() => {});
      });
      showToast(`${ids.length} products archived.`);
    } else if (action === 'DELETE') {
      const updatedProducts = products.filter(p => !ids.includes(p.id));
      persistProductsImmediately(updatedProducts);
      setInventory(prev => {
        const next = prev.filter(item => !ids.includes(item.productId));
        persistInventoryImmediately(next);
        return next;
      });
      showToast(`${ids.length} products deleted.`);
      await Promise.all(
        ids.map(id => 
          apiClient.adminDeleteProduct(id).catch(err => console.warn('[AdminData] Async sync product bulk delete to API:', err))
        )
      );
    } else if (action === 'DISCOUNT' && typeof val === 'number') {
      const updatedProducts = products.map(p => {
        if (ids.includes(p.id)) {
          const newPrice = Math.round(p.mrp * (1 - val / 100));
          return { ...p, price: newPrice, discountPercent: val };
        }
        return p;
      });
      persistProductsImmediately(updatedProducts);
      ids.forEach(id => {
        const p = updatedProducts.find(prod => prod.id === id);
        if (p) {
          apiClient.adminUpdateProduct(id, { price: p.price, discountPercent: p.discountPercent }).catch(() => {});
        }
      });
      showToast(`Applied ${val}% discount to ${ids.length} products.`);
    }
    logAction('PRODUCT_UPDATED', `Bulk Operation on ${ids.length} Products`, `Action executed: ${action}`);
  };

  // Inventory Stock Adjustment
  const updateStock = (variantId: string, newStock: number, reason: string) => {
    const invItem = inventory.find(i => i.variantId === variantId || i.sku === variantId);
    if (!invItem) return;

    const oldStock = invItem.availableStock;
    const diff = newStock - oldStock;

    let newStatus: InventoryItem['status'] = 'IN_STOCK';
    if (newStock === 0) newStatus = 'OUT_OF_STOCK';
    else if (newStock <= invItem.criticalThreshold) newStatus = 'CRITICAL_STOCK';
    else if (newStock <= invItem.lowStockThreshold) newStatus = 'LOW_STOCK';

    const nextInv = inventory.map(i => {
      if (i.variantId === variantId || i.sku === variantId) {
        return {
          ...i,
          availableStock: newStock,
          status: newStatus,
          lastUpdated: 'Just now',
        };
      }
      return i;
    });
    persistInventoryImmediately(nextInv);

    // Synchronize product variant stock and total stock in products list
    const targetProduct = products.find(p => p.id === invItem.productId || p.variants?.some(v => v.id === variantId || v.sku === invItem.sku));
    if (targetProduct) {
      const updatedVariants = (targetProduct.variants || []).map(v => 
        (v.id === variantId || v.sku === invItem.sku) ? { ...v, stock: Math.max(0, newStock) } : v
      );
      const totalStock = updatedVariants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
      const updatedProd: AdminProduct = {
        ...targetProduct,
        variants: updatedVariants,
        stock: totalStock as any,
        inStock: (totalStock > 0) as any,
        updatedAt: new Date().toISOString(),
      };
      const updatedProducts = products.map(p => p.id === targetProduct.id ? updatedProd : p);
      persistProductsImmediately(updatedProducts);

      apiClient.adminUpdateProduct(targetProduct.id, {
        variants: updatedVariants,
        stock: totalStock,
        inStock: totalStock > 0,
      }).catch((err) => console.warn('[AdminData] Async sync product stock update to API:', err));
    }

    // Record movement
    const movement: InventoryMovement = {
      id: `mov-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST (Today)',
      productId: invItem.productId,
      productName: invItem.productName,
      sku: invItem.sku,
      type: diff >= 0 ? 'INCREASE' : 'DECREASE',
      amount: diff,
      previousStock: oldStock,
      newStock: newStock,
      reason: reason || 'Manual stock reconciliation in Admin',
      adminName: currentUser?.name || 'Saif (Owner)',
    };
    setInventoryMovements(prev => [movement, ...prev]);

    logAction('STOCK_MODIFIED', `SKU #${invItem.sku} (${invItem.productName})`, `Stock adjusted from ${oldStock} to ${newStock}. Reason: ${reason}`, `${oldStock} units`, `${newStock} units`);
    showToast(`Stock for ${invItem.sku} updated to ${newStock} units.`);
    apiClient.updateStock(variantId, newStock, reason).catch((err) => console.warn('[AdminData] Async sync stock update to API:', err));
  };

  // Inventory SKU Deletion (Functional & Atomic)
  const deleteInventoryItem = (variantId: string, reason?: string) => {
    let deletedItem: InventoryItem | undefined;

    setInventory(prev => {
      const target = prev.find(i => i.variantId === variantId || i.sku === variantId || i.id === variantId);
      if (!target) return prev;
      deletedItem = target;
      const next = prev.filter(i => i.variantId !== variantId && i.sku !== variantId && i.id !== variantId);
      safeLocalStorageSet('tori_admin_inventory', next);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('tori_admin_inventory_updated', { detail: next }));
      }
      return next;
    });

    if (deletedItem) {
      const invItem = deletedItem;
      // Record movement audit
      const movement: InventoryMovement = {
        id: `mov-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST (Today)',
        productId: invItem.productId,
        productName: invItem.productName,
        sku: invItem.sku,
        type: 'MANUAL_CORRECTION',
        amount: -invItem.availableStock,
        previousStock: invItem.availableStock,
        newStock: 0,
        reason: reason || 'Inventory record removed in Admin',
        adminName: currentUser?.name || 'Saif (Owner)',
      };
      setInventoryMovements(prev => [movement, ...prev]);

      // Remove variant from products and update stock
      setProducts(prevProducts => {
        const nextProducts = prevProducts.map(p => {
          if (p.id === invItem.productId || p.variants?.some(v => v.id === invItem.variantId || v.sku === invItem.sku)) {
            const nextVariants = (p.variants || []).filter(v => v.id !== invItem.variantId && v.sku !== invItem.sku);
            const totalStock = nextVariants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
            return {
              ...p,
              variants: nextVariants,
              stock: totalStock as any,
              inStock: (totalStock > 0) as any,
              updatedAt: new Date().toISOString(),
            };
          }
          return p;
        });
        safeLocalStorageSet('tori_admin_products', nextProducts);
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('tori_admin_products_updated', { detail: nextProducts }));
        }
        return nextProducts;
      });

      logAction(
        'STOCK_MODIFIED',
        `Deleted SKU #${invItem.sku} (${invItem.productName})`,
        `Inventory record removed. Reason: ${reason || 'Manual SKU deletion'}. Previous stock: ${invItem.availableStock}`,
        `${invItem.availableStock} units`,
        '0 units (Deleted)'
      );

      showToast(`Inventory SKU ${invItem.sku} (${invItem.size}) deleted.`);
      apiClient.deleteInventoryItem(invItem.variantId || invItem.sku, reason).catch((err) =>
        console.warn('[AdminData] Async sync delete inventory to API:', err)
      );
    }
  };

  // Bulk Inventory & Product Deletion (Functional, Atomic, Multi-variant aware)
  const bulkDeleteInventoryItems = async (
    targetIds: string[], 
    reason: string = 'Bulk product removal / Warehouse clearance'
  ): Promise<{ success: boolean; deletedCount: number; message: string }> => {
    if (!targetIds || targetIds.length === 0) {
      return { success: false, deletedCount: 0, message: 'No items selected.' };
    }

    lastProductMutationTimeRef.current = Date.now();
    const targetSet = new Set(targetIds);

    // Identify affected inventory items from current state
    const itemsToDelete = inventory.filter(i => 
      targetSet.has(i.id) || 
      (i.variantId && targetSet.has(i.variantId)) || 
      (i.sku && targetSet.has(i.sku)) ||
      (i.productId && targetSet.has(i.productId))
    );

    const deletedVariantIds = new Set(itemsToDelete.map(i => i.variantId || i.id));
    const deletedSkus = new Set(itemsToDelete.map(i => i.sku));
    const affectedProductIds = Array.from(new Set(itemsToDelete.map(i => i.productId).filter(Boolean)));

    // 1. Identify which products have ALL their variants targeted or are directly targeted
    const fullyRemovedProductIds: string[] = [];
    const nextProducts: AdminProduct[] = [];

    for (const prod of products) {
      if (targetSet.has(prod.id)) {
        fullyRemovedProductIds.push(prod.id);
        continue;
      }

      if (affectedProductIds.includes(prod.id)) {
        const prodVariants = prod.variants || [];
        const remainingVariants = prodVariants.filter(v => 
          !targetSet.has(v.id) && 
          !targetSet.has(`inv-${v.id}`) &&
          !deletedVariantIds.has(v.id) && 
          !deletedSkus.has(v.sku)
        );

        if (remainingVariants.length === 0) {
          fullyRemovedProductIds.push(prod.id);
        } else {
          const totalStock = remainingVariants.reduce((sum, v) => sum + (Number(v.stock) || 0), 0);
          nextProducts.push({
            ...prod,
            variants: remainingVariants,
            stock: totalStock as any,
            inStock: (totalStock > 0) as any,
            updatedAt: new Date().toISOString(),
          });
        }
      } else {
        nextProducts.push(prod);
      }
    }

    // 2. Synchronously update products in state and localStorage
    persistProductsImmediately(nextProducts);

    // 3. Synchronously filter inventory in state and localStorage
    const nextInv = inventory.filter(i => 
      !targetSet.has(i.id) && 
      !targetSet.has(i.variantId) &&
      !targetSet.has(i.productId) &&
      !deletedVariantIds.has(i.variantId || '') && 
      !deletedSkus.has(i.sku) &&
      !fullyRemovedProductIds.includes(i.productId)
    );
    persistInventoryImmediately(nextInv);

    // 4. Record audit trail & movements
    const timestamp = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST (Today)';
    const newMovements: InventoryMovement[] = itemsToDelete.map(item => ({
      id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp,
      productId: item.productId,
      productName: item.productName,
      sku: item.sku,
      type: 'MANUAL_CORRECTION',
      amount: -item.availableStock,
      previousStock: item.availableStock,
      newStock: 0,
      reason,
      adminName: currentUser?.name || 'Saif (Owner)',
    }));

    if (newMovements.length > 0) {
      setInventoryMovements(prev => [...newMovements, ...prev]);
    }

    logAction(
      'STOCK_MODIFIED',
      `Bulk deleted ${itemsToDelete.length} SKU entries across ${affectedProductIds.length} products`,
      `Reason: ${reason}. Removed: ${Array.from(deletedSkus).slice(0, 5).join(', ')}${deletedSkus.size > 5 ? '...' : ''}`
    );

    // 5. Propagate deletions to backend API and database
    try {
      await Promise.all([
        ...fullyRemovedProductIds.map(prodId => 
          apiClient.adminDeleteProduct(prodId).catch(err => 
            console.warn(`[AdminData] Backend delete error for product ${prodId}:`, err)
          )
        ),
        ...itemsToDelete.map(item => 
          apiClient.deleteInventoryItem(item.variantId || item.sku, reason).catch(err => 
            console.warn(`[AdminData] Backend delete error for variant ${item.sku}:`, err)
          )
        )
      ]);
    } catch (err) {
      console.warn('[AdminData] Async delete sync error:', err);
    }

    showToast(`Permanently deleted ${itemsToDelete.length} inventory records and ${fullyRemovedProductIds.length} product entries.`);
    return { 
      success: true, 
      deletedCount: itemsToDelete.length, 
      message: `Successfully deleted ${itemsToDelete.length} product/SKU records.` 
    };
  };

  // Orders Workflow
  const updateOrderStatus = (orderId: string, status: OrderShippingStatus, note?: string) => {
    const target = orders.find(o => o.orderId === orderId);
    if (!target) return;

    const oldStatus = target.shippingStatus;
    const newTimelineEntry = {
      title: `Status changed to ${status}`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST (Today)',
      note: note || `Updated by ${currentUser?.name || 'Admin'}`,
    };

    setOrders(prev => prev.map(o => {
      if (o.orderId === orderId) {
        return {
          ...o,
          shippingStatus: status,
          timeline: [newTimelineEntry, ...o.timeline],
        };
      }
      return o;
    }));

    logAction('ORDER_STATUS_CHANGED', `Order #${target.orderNumber}`, `Changed status from ${oldStatus} to ${status}. Note: ${note || 'None'}`, oldStatus, status);
    showToast(`Order #${target.orderNumber} is now marked ${status}.`);
    apiClient.updateAdminOrderStatus(orderId, status, note).catch((err) => console.warn('[AdminData] Async sync order status to API:', err));
  };

  const addOrderInternalNote = (orderId: string, noteText: string) => {
    const newNote = {
      id: `note-${Date.now()}`,
      text: noteText,
      author: currentUser?.name || 'Saif (Owner)',
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST',
    };

    setOrders(prev => prev.map(o => {
      if (o.orderId === orderId) {
        return { ...o, internalNotes: [newNote, ...o.internalNotes] };
      }
      return o;
    }));
    showToast('Internal note saved.');
  };

  const cancelOrder = (orderId: string, reason: string) => {
    const target = orders.find(o => o.orderId === orderId);
    if (!target) return;

    setOrders(prev => prev.map(o => {
      if (o.orderId === orderId) {
        return {
          ...o,
          shippingStatus: 'CANCELLED',
          paymentStatus: o.paymentMethod === 'COD' ? 'FAILED' : 'REFUNDED',
          timeline: [
            { title: 'Order Cancelled by Admin', timestamp: 'Today', note: `Reason: ${reason}` },
            ...o.timeline,
          ],
        };
      }
      return o;
    }));

    logAction('ORDER_CANCELLED', `Order #${target.orderNumber}`, `Cancelled by ${currentUser?.name}. Reason: ${reason}`);
    showToast(`Order #${target.orderNumber} cancelled.`);
    apiClient.cancelAdminOrder(orderId, reason).catch((err) => console.warn('[AdminData] Async sync cancel order to API:', err));
  };

  const initiateRefund = (orderId: string, amount: number, reason: string) => {
    const target = orders.find(o => o.orderId === orderId);
    if (!target) return;

    // Add payment transaction record
    const refundTx: PaymentTransaction = {
      id: `tx-ref-${Date.now()}`,
      orderId: target.orderId,
      orderNumber: target.orderNumber,
      customerName: target.customerName,
      customerEmail: target.customerEmail,
      amount: amount,
      method: target.paymentMethod,
      gateway: 'Razorpay',
      gatewayRefId: `pay_REF_${Date.now()}`,
      status: 'REFUNDED',
      date: new Date().toLocaleDateString('en-IN') + ' IST',
      refundStatus: 'COMPLETED',
      refundAmount: amount,
      fee: 0,
      netSettlement: 0,
    };

    setPayments(prev => [refundTx, ...prev]);

    setOrders(prev => prev.map(o => {
      if (o.orderId === orderId) {
        return {
          ...o,
          paymentStatus: 'REFUNDED',
          timeline: [
            { title: `Refund of ₹${amount} Initiated`, timestamp: 'Today', note: `Reason: ${reason}` },
            ...o.timeline,
          ],
        };
      }
      return o;
    }));

    logAction('REFUND_INITIATED', `Order #${target.orderNumber}`, `Refund of ₹${amount} processed. Reason: ${reason}`);
    showToast(`Refund of ₹${amount} initiated for Order #${target.orderNumber}.`);
    apiClient.refundAdminOrder(orderId, amount, reason).catch((err) => console.warn('[AdminData] Async sync refund order to API:', err));
  };

  // Coupons (Server Authoritative)
  const addCoupon = async (couponData: Omit<Coupon, 'id' | 'usageCount'>) => {
    const token = getSessionToken();
    try {
      const res = await fetch('/api/v1/admin/coupons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(couponData),
      });
      const json = await res.json();
      if (json.success && json.data) {
        const c = json.data;
        const newCoupon: Coupon = {
          id: c.id,
          code: c.code,
          discountType: c.discountType === 'PERCENTAGE' ? 'PERCENTAGE' : (c.discountType === 'FREE_SHIPPING' ? 'FREE_SHIPPING' : 'FIXED'),
          value: Number(c.value),
          minCartValue: Number(c.minOrderValue || c.minCartValue || 0),
          maxDiscount: c.maxDiscount ? Number(c.maxDiscount) : undefined,
          usageLimit: Number(c.usageLimit || 1000),
          usageCount: Number(c.usageCount || 0),
          perCustomerLimit: Number(c.perCustomerLimit || 1),
          applicableFranchises: Array.isArray(c.applicableFranchises) ? c.applicableFranchises : ['ALL'],
          startDate: c.startDate ? new Date(c.startDate).toISOString().split('T')[0] : '2026-01-01',
          endDate: c.expiryDate ? new Date(c.expiryDate).toISOString().split('T')[0] : (c.endDate || '2026-12-31'),
          isActive: c.isActive !== false,
          description: c.description || '',
        };
        setCoupons(prev => [newCoupon, ...prev.filter(item => item.id !== newCoupon.id)]);
        logAction('COUPON_CREATED', `Coupon Code ${newCoupon.code}`, `Created with ${newCoupon.value}${newCoupon.discountType === 'PERCENTAGE' ? '%' : '₹'} discount`);
        showToast(`Coupon "${newCoupon.code}" created and saved to database.`);
        return;
      } else {
        showToast(json.error || 'Failed to create coupon on server.');
      }
    } catch (err: any) {
      console.warn('[AdminData] Error saving coupon to server:', err);
      showToast('Error communicating with backend.');
    }
  };

  const toggleCoupon = async (id: string) => {
    const token = getSessionToken();
    setCoupons(prev => prev.map(c => c.id === id ? { ...c, isActive: !c.isActive } : c));
    showToast('Coupon status updated.');
    try {
      await fetch(`/api/v1/admin/coupons/${encodeURIComponent(id)}/toggle`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
    } catch (err) {
      console.warn('[AdminData] Error toggling coupon on backend:', err);
    }
  };

  const deleteCoupon = async (id: string) => {
    const token = getSessionToken();
    setCoupons(prev => prev.filter(c => c.id !== id));
    showToast('Coupon deleted.');
    try {
      await fetch(`/api/v1/admin/coupons/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });
    } catch (err) {
      console.warn('[AdminData] Error deleting coupon on backend:', err);
    }
  };

  // Ads
  const addAdvertisement = (adData: Omit<Advertisement, 'id' | 'clicks' | 'impressions'>) => {
    const newAd: Advertisement = {
      ...adData,
      id: `ad-${Date.now()}`,
      clicks: 0,
      impressions: 0,
    };
    setAds(prev => [newAd, ...prev]);
    showToast(`Ad "${newAd.name}" created.`);
  };

  const updateAdvertisement = (id: string, updates: Partial<Advertisement>) => {
    setAds(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
    showToast('Advertisement campaign updated.');
  };

  const deleteAdvertisement = (id: string) => {
    setAds(prev => prev.filter(a => a.id !== id));
    showToast('Advertisement removed.');
  };

  // CMS (Server Authoritative)
  const saveWebsiteSections = (sections: WebsiteSection[]) => {
    setWebsiteSections(sections);
    logAction('SETTINGS_SAVED', 'Homepage CMS Sections', 'Updated section order and visibility flags.');
    showToast('Homepage section architecture updated.');

    const token = getSessionToken();
    fetch('/api/v1/admin/cms/sections', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ sections }),
    }).catch((err) => console.warn('[AdminData] Failed to persist sections to backend:', err));
  };

  const saveHeroSettings = (hero: HeroSettings) => {
    setHeroSettings(hero);
    try {
      localStorage.setItem('tori_admin_heroSettings', JSON.stringify(hero));
      window.dispatchEvent(new Event('tori_hero_updated'));
      window.dispatchEvent(new Event('storage'));
    } catch (e) {
      console.error(e);
    }
    logAction('SETTINGS_SAVED', 'Hero Parallax Banner', `Updated headline to "${hero.headline}"`);
    showToast('Hero section settings saved.');

    const token = getSessionToken();
    fetch('/api/v1/admin/cms/hero', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(hero),
    }).catch((err) => console.warn('[AdminData] Failed to persist hero to backend:', err));
  };

  // Returns
  const processReturnRequest = (id: string, newStatus: ReturnRequest['status'], note?: string) => {
    setReturnRequests(prev => prev.map(r => r.id === id ? { ...r, status: newStatus, notes: note || r.notes } : r));
    showToast(`Return request updated to ${newStatus}.`);
  };

  // Security Sessions
  const revokeSession = (id: string) => {
    setSecuritySessions(prev => prev.filter(s => s.id !== id));
    logAction('SESSION_REVOKED', `Session #${id}`, 'Session remotely terminated by administrator.');
    showToast('Session revoked successfully.');
  };

  const revokeAllOtherSessions = () => {
    setSecuritySessions(prev => prev.filter(s => s.isCurrent));
    logAction('SESSION_REVOKED', 'All Remote Sessions', 'Terminated all sessions except current active device.');
    showToast('All other sessions terminated.');
  };

  // Staff
  const addStaffMember = (user: Omit<AdminUser, 'id' | 'lastLogin'>) => {
    const newStaff: AdminUser = {
      avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
      department: 'Operations',
      ...user,
      id: `user-${Date.now()}`,
      lastLogin: 'Never (Invited)',
    };
    setStaff(prev => [...prev, newStaff]);
    logAction('STAFF_ADDED', `User ${newStaff.email}`, `Assigned role ${newStaff.role}`);
    showToast(`Invited ${newStaff.name} as ${newStaff.role}.`);
  };

  const updateStaffRole = (userId: string, newRole: Role) => {
    setStaff(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
    logAction('PERMISSION_CHANGED', `User ID #${userId}`, `Role updated to ${newRole}`);
    showToast('Staff role updated.');
  };

  const toggleStaffStatus = (userId: string) => {
    setStaff(prev => prev.map(u => u.id === userId ? { ...u, isActive: !u.isActive } : u));
    showToast('Staff access status toggled.');
  };

  // Settings (Server Authoritative)
  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('tori_admin_settings', JSON.stringify(updated));
        window.dispatchEvent(new CustomEvent('tori_settings_updated', { detail: updated }));
      } catch (e) {}
      return updated;
    });
    logAction('SETTINGS_SAVED', 'Store Configuration', 'Updated GST, shipping or business details.');
    showToast('Store settings saved.');

    const token = getSessionToken();
    fetch('/api/v1/admin/cms/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(newSettings),
    }).catch((err) => console.warn('[AdminData] Failed to persist settings to backend:', err));
  };

  const toggleMaintenanceMode = () => {
    const nextState = !settings.maintenanceMode;
    setSettings(prev => {
      const updated = { ...prev, maintenanceMode: nextState };
      try {
        localStorage.setItem('tori_admin_settings', JSON.stringify(updated));
        window.dispatchEvent(new CustomEvent('tori_settings_updated', { detail: updated }));
      } catch (e) {}
      return updated;
    });
    logAction('MAINTENANCE_TOGGLED', 'Storefront System', `Maintenance mode ${nextState ? 'ACTIVATED' : 'DEACTIVATED'}`);
    showToast(`Maintenance mode is now ${nextState ? 'ACTIVE ("Dropping Soon")' : 'OFF (Live Online)'}.`);

    const token = getSessionToken();
    fetch('/api/v1/admin/cms/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ maintenanceMode: nextState }),
    }).catch((err) => console.warn('[AdminData] Failed to persist maintenance mode to backend:', err));
  };

  // Notifications
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('All notifications marked as read.');
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    showToast('Notification dismissed.');
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    showToast('All notifications cleared.');
  };

  const resetToDemoData = () => {
    localStorage.clear();
    setProducts(INITIAL_ADMIN_PRODUCTS);
    setInventory(INITIAL_INVENTORY_ITEMS);
    setOrders(INITIAL_ORDERS);
    setPayments(INITIAL_PAYMENT_TRANSACTIONS);
    setCustomers(INITIAL_CUSTOMERS);
    setCoupons(INITIAL_COUPONS);
    setAds(INITIAL_ADVERTISEMENTS);
    setStaff(INITIAL_ADMIN_USERS);
    setSettings(INITIAL_STORE_SETTINGS);
    setCurrentUser(INITIAL_ADMIN_USERS[0]);
    showToast('Reset database to clean production demo state.');
  };

  // AI Design Lab Actions
  const addAIConcept = (concept: AIDesignConcept) => {
    setAiConcepts((prev) => [concept, ...prev]);
    logAction('CONTENT_UPDATE', 'AI Design Lab', `Generated new concept: ${concept.designName} (${concept.designNumber})`);
    showToast(`AI Concept "${concept.designName}" saved.`);
  };

  const updateAIConcept = (concept: AIDesignConcept) => {
    setAiConcepts((prev) => prev.map((c) => (c.id === concept.id ? concept : c)));
    showToast(`Concept "${concept.designName}" updated.`);
  };

  const deleteAIConcept = (id: string) => {
    const found = aiConcepts.find((c) => c.id === id);
    setAiConcepts((prev) => prev.filter((c) => c.id !== id));
    if (selectedConcept?.id === id) setSelectedConcept(null);
    showToast(`Concept "${found?.designName || id}" deleted.`);
  };

  const addAICharacter = (char: AICharacter) => {
    setAiCharacters((prev) => [char, ...prev]);
    logAction('CONTENT_UPDATE', 'AI Characters', `Created character: ${char.name}`);
    showToast(`Character "${char.name}" added to TORIWEAR Universe.`);
  };

  const updateAICharacter = (char: AICharacter) => {
    setAiCharacters((prev) => prev.map((c) => (c.id === char.id ? char : c)));
    showToast(`Character "${char.name}" updated.`);
  };

  const addAIWorld = (world: AIWorld) => {
    setAiWorlds((prev) => [world, ...prev]);
    logAction('CONTENT_UPDATE', 'AI Worlds', `Created world: ${world.name}`);
    showToast(`World "${world.name}" created.`);
  };

  const updateAIWorld = (world: AIWorld) => {
    setAiWorlds((prev) => prev.map((w) => (w.id === world.id ? world : w)));
    showToast(`World "${world.name}" updated.`);
  };

  const addAICollection = (col: AICollection) => {
    setAiCollections((prev) => [col, ...prev]);
    logAction('CONTENT_UPDATE', 'AI Collections', `Created collection chapter: ${col.name}`);
    showToast(`Collection "${col.name}" created.`);
  };

  const updateAICollection = (col: AICollection) => {
    setAiCollections((prev) => prev.map((c) => (c.id === col.id ? col : c)));
    showToast(`Collection "${col.name}" updated.`);
  };

  const updateAISettings = (updates: Partial<AISettings>) => {
    setAiSettings((prev) => ({ ...prev, ...updates }));
    showToast('AI Design Lab settings updated.');
  };

  const convertConceptToProductDraft = async (concept: AIDesignConcept): Promise<{ success: boolean; message: string; productId?: string }> => {
    const draftData = conceptToProductDraft(concept, products.length);
    const result = await addProduct(draftData);
    if (result.success) {
      setAiConcepts((prev) =>
        prev.map((c) =>
          c.id === concept.id
            ? { ...c, convertedToProductId: draftData.id || `TORI-DRAFT-${Date.now()}`, status: 'APPROVED' }
            : c
        )
      );
      logAction('CONTENT_UPDATE', 'AI Design Lab', `Converted AI concept ${concept.designName} to product draft`);
      showToast(`Product Draft created for "${concept.designName}". Added to Products Vault as DRAFT.`);
      return { success: true, message: 'Draft product created.', productId: draftData.id };
    }
    return { success: false, message: result.message };
  };

  return (
    <AdminDataContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isAuthChecking,
        twoFactorRequired,
        loginEmail,
        loginWithSession,
        login,
        verify2FA,
        logout,
        hasPermission,

        currentView,
        setCurrentView,
        selectedSubFilter,
        setSelectedSubFilter,
        globalSearchOpen,
        setGlobalSearchOpen,

        products,
        inventory,
        inventoryMovements,
        orders,
        payments,
        customers,
        coupons,
        ads,
        flashSales,
        websiteSections,
        heroSettings,
        returnRequests,
        auditLogs,
        securitySessions,
        staff,
        settings,
        notifications,

        // AI Design Lab Values
        aiConcepts,
        aiCharacters,
        aiWorlds,
        aiCollections,
        aiSettings,
        aiUsageLogs,
        selectedConcept,
        setSelectedConcept,
        addAIConcept,
        updateAIConcept,
        deleteAIConcept,
        addAICharacter,
        updateAICharacter,
        addAIWorld,
        updateAIWorld,
        addAICollection,
        updateAICollection,
        updateAISettings,
        convertConceptToProductDraft,

        addProduct,
        updateProduct,
        archiveProduct,
        deleteProduct,
        duplicateProduct,
        bulkUpdateProducts,

        updateStock,
        deleteInventoryItem,
        bulkDeleteInventoryItems,
        updateOrderStatus,
        addOrderInternalNote,
        cancelOrder,
        initiateRefund,

        addCoupon,
        toggleCoupon,
        deleteCoupon,

        addAdvertisement,
        updateAdvertisement,
        deleteAdvertisement,

        saveWebsiteSections,
        saveHeroSettings,

        processReturnRequest,

        revokeSession,
        revokeAllOtherSessions,

        addStaffMember,
        updateStaffRole,
        toggleStaffStatus,

        updateSettings,
        toggleMaintenanceMode,

        markNotificationAsRead,
        markAllNotificationsRead,
        deleteNotification,
        clearAllNotifications,

        toastMessage,
        showToast,
        resetToDemoData,
      }}
    >
      {children}
    </AdminDataContext.Provider>
  );
};

export const useAdmin = () => {
  const context = useContext(AdminDataContext);
  if (!context) {
    throw new Error('useAdmin must be used within an AdminDataProvider');
  }
  return context;
};
