import { Router, Request, Response, NextFunction } from 'express';
import { cmsRepository } from '../repositories/cmsRepository';
import { extractSessionToken } from '../middleware/authMiddleware';
import { userService } from '../services/userService';
import { authStore } from '../authStore';

export const cmsRouter = Router();

// Middleware to enforce admin/staff authentication
function requireAdminAuth() {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const token = extractSessionToken(req);

    if (token) {
      const session = await userService.validateSession(token);
      if (session) {
        req.user = {
          id: session.user.id,
          email: session.user.email,
          name: session.user.name,
          role: session.user.role,
          department: session.user.department,
        };
        req.sessionToken = token;
        return next();
      }

      const legacyUser = authStore.getUserByToken(token);
      if (legacyUser) {
        req.user = {
          id: legacyUser.id,
          email: legacyUser.email,
          name: legacyUser.name,
          role: legacyUser.role,
          permissions: legacyUser.permissions,
          department: legacyUser.department,
        };
        req.sessionToken = token;
        return next();
      }
    }

    res.status(401).json({
      success: false,
      code: 'UNAUTHENTICATED',
      error: 'Admin authentication required to perform this CMS operation.',
    });
  };
}

// ============================================================================
// 1. PUBLIC STOREFRONT CMS APIS (Zero authentication needed)
// ============================================================================

/**
 * Public Frontpage CMS Data (Hero, Ordered Sections, Realms, Announcements, Lore)
 */
cmsRouter.get('/frontpage', async (_req: Request, res: Response) => {
  try {
    const data = await cmsRepository.getFrontPageData();
    res.json({
      success: true,
      data,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve frontpage CMS data' });
  }
});

/**
 * Public Store Settings (Shipping thresholds, Maintenance mode, Currency, Fees)
 */
cmsRouter.get('/settings', async (_req: Request, res: Response) => {
  try {
    const full = await cmsRepository.getStoreSettings();
    // Expose only public store configurations
    res.json({
      success: true,
      data: {
        storeName: full.storeName,
        tagline: full.tagline,
        freeShippingThreshold: full.freeShippingThreshold,
        standardShippingFee: full.standardShippingFee,
        codFee: full.codFee,
        currency: full.currency,
        maintenanceMode: full.maintenanceMode,
        supportEmail: full.supportEmail,
        supportPhone: full.supportPhone,
        gstNumber: full.gstNumber,
        panNumber: full.panNumber,
        registeredAddress: full.registeredAddress,
        operatingHours: full.operatingHours,
        logoUrl: full.logoUrl,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to retrieve store settings' });
  }
});

// ============================================================================
// 2. PROTECTED ADMIN CMS APIS (Session & Role Enforced)
// ============================================================================

cmsRouter.get('/admin/frontpage', requireAdminAuth(), async (_req: Request, res: Response) => {
  try {
    const data = await cmsRepository.getFrontPageData();
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to load frontpage CMS data' });
  }
});

cmsRouter.post('/admin/frontpage', requireAdminAuth(), async (req: Request, res: Response) => {
  try {
    const actorId = req.user?.id || req.user?.name || 'ADMIN';
    const saved = await cmsRepository.saveFrontPageData(req.body, actorId);
    res.json({
      success: true,
      message: 'Frontpage CMS successfully published and persisted to backend.',
      data: saved,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to save frontpage CMS data' });
  }
});

cmsRouter.put('/admin/sections', requireAdminAuth(), async (req: Request, res: Response) => {
  try {
    if (!Array.isArray(req.body.sections)) {
      return res.status(400).json({ success: false, error: 'Expected "sections" array in request body.' });
    }
    const actorId = req.user?.id || req.user?.name || 'ADMIN';
    const updated = await cmsRepository.updateSections(req.body.sections, actorId);
    res.json({
      success: true,
      message: 'Homepage sections order and visibility updated.',
      data: updated,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to update sections' });
  }
});

cmsRouter.put('/admin/hero', requireAdminAuth(), async (req: Request, res: Response) => {
  try {
    const actorId = req.user?.id || req.user?.name || 'ADMIN';
    const updated = await cmsRepository.updateHero(req.body, actorId);
    res.json({
      success: true,
      message: 'Hero billboard configuration updated.',
      data: updated,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to update hero settings' });
  }
});

cmsRouter.post('/admin/reset', requireAdminAuth(), async (req: Request, res: Response) => {
  try {
    const actorId = req.user?.id || req.user?.name || 'ADMIN';
    const reset = await cmsRepository.resetToDefaults(actorId);
    res.json({
      success: true,
      message: 'CMS configurations reset to baseline factory defaults.',
      data: reset,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to reset CMS defaults' });
  }
});

cmsRouter.get('/admin/settings', requireAdminAuth(), async (_req: Request, res: Response) => {
  try {
    const settings = await cmsRepository.getStoreSettings();
    res.json({ success: true, data: settings });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to load store settings' });
  }
});

cmsRouter.put('/admin/settings', requireAdminAuth(), async (req: Request, res: Response) => {
  try {
    const actorId = req.user?.id || req.user?.name || 'ADMIN';
    const updated = await cmsRepository.updateStoreSettings(req.body, actorId);
    res.json({
      success: true,
      message: 'Store settings successfully updated.',
      data: updated,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to update store settings' });
  }
});
