import { Router, Request, Response, NextFunction } from 'express';
import { checkDatabaseHealth } from '../db/prisma';
import { userService } from '../services/userService';
import { orderService } from '../services/orderService';
import { orderRepository, OrderRecord } from '../repositories/orderRepository';
import { paymentService } from '../services/paymentService';
import { shippingService } from '../services/shippingService';
import { couponRepository } from '../repositories/couponRepository';
import { productRepository, ProductRecord, ProductVariantRecord, CategoryRecord, ProductImageRecord } from '../repositories/productRepository';
import { inventoryRepository } from '../repositories/inventoryRepository';
import { logisticsManager } from '../services/logistics/logisticsManager';
import { requireAuth, requireRole, extractSessionToken } from '../middleware/authMiddleware';
import { authStore } from '../authStore';
import { userStore } from '../userStore';
import {
  validateLoginInput,
  validateCreateOrderInput,
  validateQuoteOrderInput,
  validateUpdateOrderStatusInput,
  validateCancelOrderInput,
  validatePaymentIntentInput,
  validatePaymentVerificationInput,
} from '../validation/schemas';

export const apiRouter = Router();

// Middleware to check admin/staff permission safely in both production and development
function requireStaffPermission(permissionName?: string) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const token = extractSessionToken(req);

    if (token) {
      const session = await userService.validateSession(token);
      if (session) {
        req.user = {
          id: session.user.id,
          email: session.user.email,
          name: session.user.name,
          role: session.user.role,
          department: session.user.department,
        };
        req.sessionToken = token;
        return next();
      }

      const legacyUser = authStore.getUserByToken(token);
      if (legacyUser) {
        req.user = {
          id: legacyUser.id,
          email: legacyUser.email,
          name: legacyUser.name,
          role: legacyUser.role,
          permissions: legacyUser.permissions,
          department: legacyUser.department,
        };
        req.sessionToken = token;
        return next();
      }
    }

    // Strictly reject unauthenticated admin requests in all environments
    res.status(401).json({
      success: false,
      code: 'UNAUTHENTICATED',
      error: 'Admin authentication required to perform this operation.',
    });
    return;
  };
}

// ============================================================================
// 1. SYSTEM HEALTH & DATABASE ARCHITECTURE STATUS
// ============================================================================
apiRouter.get('/health', async (_req: Request, res: Response) => {
  const dbHealth = await checkDatabaseHealth();
  res.json({
    status: 'HEALTHY',
    service: 'TORIWEAR Backend & Persistence Engine',
    timestamp: new Date().toISOString(),
    database: dbHealth,
    environment: process.env.NODE_ENV || 'development',
    serverUptimeSeconds: Math.floor(process.uptime()),
  });
});

// ============================================================================
// 2. PRODUCTION AUTHENTICATION & SESSIONS
// ============================================================================
apiRouter.post('/v1/auth/login', async (req: Request, res: Response) => {
  const validation = validateLoginInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const ip = (req.ip || req.socket.remoteAddress || '127.0.0.1').replace('::ffff:', '');
  const userAgent = req.headers['user-agent'] as string;
  const result = await userService.authenticate(req.body.identifier, req.body.password, ip, userAgent);

  if (!result.success) {
    return res.status(401).json(result);
  }

  return res.json(result);
});

apiRouter.get('/v1/auth/me', requireAuth, (req: Request, res: Response) => {
  res.json({
    success: true,
    user: req.user,
  });
});

apiRouter.post('/v1/auth/logout', requireAuth, async (req: Request, res: Response) => {
  if (req.sessionToken) {
    await userService.revokeSession(req.sessionToken);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// ============================================================================
// 3. STOREFRONT PRODUCT CATALOG & PUBLIC READ APIS
// ============================================================================
apiRouter.get('/v1/products', async (req: Request, res: Response) => {
  const { department, world, status, categoryId, collectionSlug, isBestseller, isNewDrop, isTrending, search } = req.query;

  const targetStatus = typeof status === 'string' ? status : 'PUBLISHED';
  const products = await productRepository.getAll({
    department: typeof department === 'string' ? department : undefined,
    world: typeof world === 'string' ? world : undefined,
    status: targetStatus,
    categoryId: typeof categoryId === 'string' ? categoryId : undefined,
    collectionSlug: typeof collectionSlug === 'string' ? collectionSlug : undefined,
    isBestseller: isBestseller !== undefined ? isBestseller === 'true' : undefined,
    isNewDrop: isNewDrop !== undefined ? isNewDrop === 'true' : undefined,
    isTrending: isTrending !== undefined ? isTrending === 'true' : undefined,
    search: typeof search === 'string' ? search : undefined,
  });

  console.log(`[API] 🌐 GET /v1/products?status=${targetStatus}&dept=${department || 'ALL'} -> Returning ${products.length} products`);

  res.json({
    success: true,
    count: products.length,
    data: products,
  });
});

apiRouter.get('/v1/products/featured', async (_req: Request, res: Response) => {
  const products = await productRepository.getAll({
    status: 'PUBLISHED',
    isNewDrop: true,
  });
  res.json({ success: true, count: products.length, data: products.slice(0, 8) });
});

apiRouter.get('/v1/products/new-arrivals', async (req: Request, res: Response) => {
  const { department } = req.query;
  const products = await productRepository.getAll({
    department: typeof department === 'string' ? department : undefined,
    status: 'PUBLISHED',
    isNewDrop: true,
  });
  res.json({ success: true, count: products.length, data: products });
});

apiRouter.get('/v1/products/top-selling', async (req: Request, res: Response) => {
  const { department } = req.query;
  const products = await productRepository.getAll({
    department: typeof department === 'string' ? department : undefined,
    status: 'PUBLISHED',
    isBestseller: true,
  });
  res.json({ success: true, count: products.length, data: products });
});

apiRouter.get('/v1/products/slug/:slug', async (req: Request, res: Response) => {
  const product = await productRepository.findBySlug(req.params.slug);
  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  res.json({ success: true, data: product });
});

apiRouter.get('/v1/products/category/:categoryId', async (req: Request, res: Response) => {
  const products = await productRepository.getAll({
    categoryId: req.params.categoryId,
    status: 'PUBLISHED',
  });
  res.json({ success: true, count: products.length, data: products });
});

apiRouter.get('/v1/products/collection/:collectionSlug', async (req: Request, res: Response) => {
  const products = await productRepository.getAll({
    collectionSlug: req.params.collectionSlug,
    status: 'PUBLISHED',
  });
  res.json({ success: true, count: products.length, data: products });
});

apiRouter.get('/v1/products/:id', async (req: Request, res: Response) => {
  const product =
    (await productRepository.findById(req.params.id)) ||
    (await productRepository.findBySlug(req.params.id)) ||
    (await productRepository.findByCatalogNumber(req.params.id));

  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  res.json({ success: true, data: product });
});

apiRouter.get('/v1/products/:id/variants', async (req: Request, res: Response) => {
  const variants = await productRepository.getVariants(req.params.id);
  res.json({ success: true, count: variants.length, data: variants });
});

apiRouter.get('/v1/products/:id/images', async (req: Request, res: Response) => {
  const images = await productRepository.getImages(req.params.id);
  res.json({ success: true, count: images.length, data: images });
});

// ============================================================================
// 4. CATEGORIES & COLLECTIONS
// ============================================================================
apiRouter.get('/v1/categories', async (req: Request, res: Response) => {
  const { department } = req.query;
  const categories = await productRepository.getCategories(typeof department === 'string' ? department : undefined);
  res.json({ success: true, count: categories.length, data: categories });
});

apiRouter.get('/v1/categories/:id', async (req: Request, res: Response) => {
  const cat = (await productRepository.getCategoryById(req.params.id)) || (await productRepository.getCategoryBySlug(req.params.id));
  if (!cat) {
    return res.status(404).json({ success: false, error: 'Category not found.' });
  }
  res.json({ success: true, data: cat });
});

apiRouter.get('/v1/collections', async (_req: Request, res: Response) => {
  const collections = await productRepository.getCollections();
  res.json({ success: true, count: collections.length, data: collections });
});

apiRouter.get('/v1/collections/:slug', async (req: Request, res: Response) => {
  const collection = await productRepository.getCollectionBySlug(req.params.slug);
  if (!collection) {
    return res.status(404).json({ success: false, error: 'Collection not found.' });
  }
  res.json({ success: true, data: collection });
});

// ============================================================================
// 5. ADMIN PRODUCT MANAGEMENT APIS
// ============================================================================
apiRouter.get('/v1/admin/products', requireStaffPermission('products.view'), async (_req: Request, res: Response) => {
  try {
    const products = await productRepository.getAll({ status: 'ALL' });
    res.json({
      success: true,
      count: products.length,
      data: products,
    });
  } catch (err: any) {
    console.error('[API] Error fetching admin products:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch admin products.' });
  }
});

apiRouter.post('/v1/admin/products', requireStaffPermission('products.create'), async (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.name || !data.price) {
      return res.status(400).json({ success: false, error: 'Product name and price are required.' });
    }

    const id = data.id || `tori-prod-${Date.now()}`;
    const catalogNumber = data.catalogNumber || `PR-${Math.floor(1000 + Math.random() * 9000)}`;
    const slug = data.slug || data.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');

    console.log(`[API] ➕ CREATE request received for Product "${data.name}" (ID: ${id}, Catalog: ${catalogNumber})`);

    const newProduct: ProductRecord = {
      id,
      catalogNumber,
      name: data.name,
      slug,
      sku: data.sku || `SKU-${catalogNumber}`,
      department: data.department || 'MEN',
      world: data.world || 'STREET ANIME',
      franchise: data.franchise || data.world || 'TORIWEAR',
      universe: data.universe || data.department || 'MEN',
      character: data.character,
      fit: data.fit || 'Oversized',
      price: Number(data.price),
      originalPrice: Number(data.originalPrice || data.mrp || data.price * 1.3),
      costPrice: data.costPrice ? Number(data.costPrice) : undefined,
      gsm: Number(data.gsm || 240),
      fabric: data.fabric || '100% Combed Heavyweight Cotton',
      neck: data.neck || 'High-Ribbed Crewneck',
      sleeves: data.sleeves || 'Drop Shoulder Half Sleeves',
      print: data.print || 'High-Density Screen Print',
      description: data.description || '',
      storyQuote: data.storyQuote,
      drop: data.drop || 'CHAPTER 01 — ORIGINALS',
      rating: 5.0,
      reviewsCount: 0,
      images: Array.isArray(data.images) ? data.images : [],
      features: Array.isArray(data.features) ? data.features : ['240 GSM Combed Cotton', 'Pre-Shrunk Bio-Washed Fabric'],
      colors: Array.isArray(data.colors) ? data.colors : [{ name: 'Void Black', hex: '#0f0f14' }],
      sizes: Array.isArray(data.sizes) ? data.sizes : (data.department === 'KIDS' ? ['4–5Y', '6–7Y', '8–9Y'] : ['S', 'M', 'L', 'XL', 'XXL']),
      isNewDrop: Boolean(data.isNewDrop ?? true),
      isTrending: Boolean(data.isTrending),
      isBestseller: Boolean(data.isBestseller),
      inStock: true,
      stock: Array.isArray(data.variants)
        ? data.variants.reduce((sum: number, v: any) => sum + (Number(v.stock) || 0), 0)
        : Number(data.stock || 50),
      licenseType: data.licenseType || 'Original IP',
      status: data.publishingStatus || data.status || 'PUBLISHED',
      categoryId: data.categoryId,
      subcategoryId: data.subcategoryId,
      collectionSlugs: Array.isArray(data.collectionSlugs) ? data.collectionSlugs : ['new-drop'],
      variants: Array.isArray(data.variants) ? data.variants : undefined,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const saved = await productRepository.save(newProduct);
    console.log(`[API] ✅ CREATE persisted successfully to repository/store for Product "${saved.name}" (ID: ${saved.id})`);
    res.status(201).json({ success: true, message: 'Product created successfully.', data: saved });
  } catch (err: any) {
    console.error('[API] Error creating product:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to create product.' });
  }
});

apiRouter.put('/v1/admin/products/:id', requireStaffPermission('products.edit'), async (req: Request, res: Response) => {
  try {
    const existing = await productRepository.findById(req.params.id);
    if (!existing) {
      return res.status(404).json({ success: false, error: 'Product not found.' });
    }

    const updates = req.body;
    const targetStatus = updates.publishingStatus || updates.status || existing.status;
    const catalogNumber = updates.catalogNumber || existing.catalogNumber;

    console.log(`[API] ✏️ UPDATE request for Product "${existing.name}" (${existing.id}) -> Target status: ${targetStatus}`);

    let computedStock = existing.stock;
    if (Array.isArray(updates.variants)) {
      computedStock = updates.variants.reduce((sum: number, v: any) => sum + (Number(v.stock) || 0), 0);
      // Synchronize each variant to inventory store
      for (const v of updates.variants) {
        if (v.id && v.stock !== undefined) {
          inventoryRepository.setStock(v.id, Number(v.stock), req.user?.id || 'ADMIN', 'Product editor variant stock sync').catch(() => {});
        }
      }
    } else if (updates.stock !== undefined) {
      computedStock = Number(updates.stock);
    }

    const merged: ProductRecord = {
      ...existing,
      ...updates,
      id: existing.id,
      catalogNumber,
      status: targetStatus,
      stock: computedStock,
      inStock: computedStock > 0,
      updatedAt: new Date(),
    };

    const saved = await productRepository.save(merged);
    console.log(`[API] ✅ UPDATE persisted successfully for Product "${saved.name}" (${saved.id})`);
    res.json({ success: true, message: 'Product updated successfully.', data: saved });
  } catch (err: any) {
    console.error('[API] Error updating product:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to update product.' });
  }
});

apiRouter.post('/v1/admin/products/:id/archive', requireStaffPermission('products.archive'), async (req: Request, res: Response) => {
  console.log(`[API] 📦 ARCHIVE request for Product ID: ${req.params.id}`);
  const product = await productRepository.archive(req.params.id);
  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  console.log(`[API] ✅ Product archived: "${product.name}" (${product.id})`);
  res.json({ success: true, message: 'Product archived successfully.', data: product });
});

apiRouter.post('/v1/admin/products/:id/restore', requireStaffPermission('products.edit'), async (req: Request, res: Response) => {
  console.log(`[API] 🔄 RESTORE request for Product ID: ${req.params.id}`);
  const product = await productRepository.restore(req.params.id);
  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  console.log(`[API] ✅ Product restored: "${product.name}" (${product.id})`);
  res.json({ success: true, message: 'Product restored successfully.', data: product });
});

apiRouter.delete('/v1/admin/products/:id', async (req: Request, res: Response) => {
  try {
    console.log(`[API] 🗑️ DELETE request for Product ID: ${req.params.id}`);
    const deleted = await productRepository.delete(req.params.id);
    console.log(`[API] ✅ Product permanently deleted: ${req.params.id} (success=${deleted})`);
    res.json({ success: true, message: 'Product permanently deleted.', data: { id: req.params.id, deleted } });
  } catch (err: any) {
    console.error('[API] Error deleting product:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to delete product.' });
  }
});

apiRouter.post('/v1/admin/products/:id/variants', requireStaffPermission('products.edit'), async (req: Request, res: Response) => {
  const { size, colorName, colorHex, price, originalPrice, stock, sku } = req.body;
  if (!size || !colorName) {
    return res.status(400).json({ success: false, error: 'Size and colorName are required.' });
  }

  const newVariant: ProductVariantRecord = {
    id: `var-${req.params.id}-${Date.now()}`,
    productId: req.params.id,
    sku: sku || `SKU-${req.params.id}-${size}`,
    size,
    colorName,
    colorHex: colorHex || '#0f0f14',
    price: Number(price || 1199),
    originalPrice: Number(originalPrice || 1599),
    stock: Number(stock || 20),
    reservedStock: 0,
    isActive: true,
  };

  const saved = await productRepository.saveVariant(req.params.id, newVariant);
  if (!saved) {
    return res.status(404).json({ success: false, error: 'Product not found.' });
  }
  res.status(201).json({ success: true, data: saved });
});

apiRouter.put('/v1/admin/products/:id/variants/:variantId', requireStaffPermission('products.edit'), async (req: Request, res: Response) => {
  const existing = await productRepository.getVariantById(req.params.variantId);
  if (!existing) {
    return res.status(404).json({ success: false, error: 'Variant not found.' });
  }

  const updated: ProductVariantRecord = {
    ...existing,
    ...req.body,
    id: existing.id,
    productId: existing.productId,
  };

  const saved = await productRepository.saveVariant(req.params.id, updated);
  res.json({ success: true, data: saved });
});

apiRouter.post('/v1/admin/products/:id/variants/:variantId/archive', requireStaffPermission('products.edit'), async (req: Request, res: Response) => {
  const success = await productRepository.archiveVariant(req.params.variantId);
  if (!success) {
    return res.status(404).json({ success: false, error: 'Variant not found.' });
  }
  res.json({ success: true, message: 'Variant archived successfully.' });
});

apiRouter.post('/v1/admin/categories', requireStaffPermission('catalog.edit'), async (req: Request, res: Response) => {
  const { name, department, description, image } = req.body;
  if (!name) {
    return res.status(400).json({ success: false, error: 'Category name is required.' });
  }

  const cat: CategoryRecord = {
    id: `cat-${Date.now()}`,
    name,
    slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    department: department || 'MEN',
    description,
    image,
    displayOrder: 99,
    isActive: true,
  };

  const saved = await productRepository.saveCategory(cat);
  res.status(201).json({ success: true, data: saved });
});

apiRouter.put('/v1/admin/categories/:id', requireStaffPermission('catalog.edit'), async (req: Request, res: Response) => {
  const existing = await productRepository.getCategoryById(req.params.id);
  if (!existing) {
    return res.status(404).json({ success: false, error: 'Category not found.' });
  }

  const updated: CategoryRecord = {
    ...existing,
    ...req.body,
    id: existing.id,
  };

  const saved = await productRepository.saveCategory(updated);
  res.json({ success: true, data: saved });
});

apiRouter.post('/v1/admin/categories/:id/archive', requireStaffPermission('catalog.edit'), async (req: Request, res: Response) => {
  const success = await productRepository.archiveCategory(req.params.id);
  if (!success) {
    return res.status(404).json({ success: false, error: 'Category not found.' });
  }
  res.json({ success: true, message: 'Category archived successfully.' });
});

// ============================================================================
// 6. INVENTORY FOUNDATION APIS
// ============================================================================
apiRouter.get('/v1/inventory', requireStaffPermission('inventory.view'), async (_req: Request, res: Response) => {
  const items = await inventoryRepository.getAll();
  res.json({ success: true, count: items.length, data: items });
});

apiRouter.get('/v1/inventory/:variantId', async (req: Request, res: Response) => {
  const item = await inventoryRepository.getByVariantId(req.params.variantId);
  if (!item) {
    return res.status(404).json({ success: false, error: 'Inventory record not found.' });
  }
  res.json({ success: true, data: item });
});

apiRouter.post('/v1/inventory/:variantId/stock', requireStaffPermission('inventory.edit'), async (req: Request, res: Response) => {
  const { delta, newStock, reason } = req.body;
  const operatorId = req.user?.id || 'OPERATOR';

  if (newStock !== undefined) {
    const updated = await inventoryRepository.setStock(req.params.variantId, Number(newStock), operatorId, reason);
    return res.json({ success: true, data: updated });
  }

  if (delta !== undefined) {
    const updated = await inventoryRepository.updateStock(
      req.params.variantId,
      Number(delta),
      'AUDIT_ADJUSTMENT',
      operatorId,
      reason
    );
    return res.json({ success: true, data: updated });
  }

  res.status(400).json({ success: false, error: 'Either "delta" or "newStock" is required.' });
});

apiRouter.delete('/v1/inventory/:variantId', requireStaffPermission('inventory.delete'), async (req: Request, res: Response) => {
  const reason = (req.body?.reason || req.query?.reason || 'Inventory record removed by staff') as string;
  const operatorId = req.user?.id || 'OPERATOR';
  const success = await inventoryRepository.deleteItem(req.params.variantId, operatorId, reason);
  if (!success) {
    return res.status(404).json({ success: false, error: 'Inventory record not found.' });
  }
  res.json({ success: true, message: 'Inventory item removed successfully' });
});

apiRouter.get('/v1/inventory/movements/recent', requireStaffPermission('inventory.view'), async (req: Request, res: Response) => {
  const limit = req.query.limit ? Number(req.query.limit) : 50;
  const movements = await inventoryRepository.getMovements(limit);
  res.json({ success: true, count: movements.length, data: movements });
});

// ============================================================================
// 7. ORDERS & SERVER-SIDE VALIDATION (PHASE 4 ORDER LIFECYCLE)
// ============================================================================

/**
 * Server-authoritative Pricing Quote / Calculation.
 * Calculates items subtotal, coupon discount, delivery fee, GST tax breakdown, and availability.
 */
apiRouter.post('/v1/orders/quote', async (req: Request, res: Response) => {
  const validation = validateQuoteOrderInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const result = await orderService.calculateQuote({
    items: req.body.items,
    couponCode: req.body.couponCode,
    shippingPincode: req.body.shippingPincode,
    state: req.body.state,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

async function isStaffOrAdmin(req: Request): Promise<boolean> {
  const token = extractSessionToken(req);
  if (!token) return false;
  const session = await userService.validateSession(token);
  if (session) return true;
  const legacy = authStore.getUserByToken(token);
  return Boolean(legacy);
}

/**
 * Server-authoritative Order Creation.
 * Never trusts prices or subtotals sent by client. Verifies inventory and creates immutable snapshots.
 */
apiRouter.post('/v1/orders', async (req: Request, res: Response) => {
  const validation = validateCreateOrderInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const idempotencyKey = (req.headers['idempotency-key'] || req.body.idempotencyKey) as string | undefined;
  const ip = (req.ip || req.socket.remoteAddress || '127.0.0.1').replace('::ffff:', '');
  const result = await orderService.createOrder({
    ...req.body,
    idempotencyKey: idempotencyKey || req.body.idempotencyKey,
  }, ip);

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.status(201).json(result);
});

/**
 * Public Customer Order Tracking API
 * Securely lookup tracking by (orderId + phone/email) or (courier AWB tracking number)
 */
apiRouter.get(['/v1/orders/track', '/orders/track'], async (req: Request, res: Response) => {
  try {
    const queryOrder = ((req.query.orderId || req.query.orderNumber || req.query.id || req.body?.orderId) as string | undefined)?.trim();
  const queryPhone = ((req.query.phone || req.body?.phone) as string | undefined)?.trim().replace(/\D/g, '');
  const queryEmail = ((req.query.email || req.body?.email) as string | undefined)?.trim().toLowerCase();
  const queryAwb = ((req.query.awb || req.query.trackingNumber || req.body?.awb) as string | undefined)?.trim();

  if (!queryOrder && !queryAwb) {
    return res.status(400).json({
      success: false,
      error: 'Order ID / Number or AWB Tracking Number is required.',
    });
  }

  let order: any = null;

  // 1. If AWB provided, lookup via shipping service or order courier tracking
  if (queryAwb) {
    const trackResult = await shippingService.trackShipment(queryAwb);
    if (trackResult.success) {
      return res.json(trackResult);
    }
    const matchingOrders = await orderRepository.getAll({ search: queryAwb });
    const match = matchingOrders.find(
      (o: OrderRecord) =>
        (o.courierTrackingNumber && o.courierTrackingNumber.toLowerCase() === queryAwb.toLowerCase()) ||
        (o.awbNumber && o.awbNumber.toLowerCase() === queryAwb.toLowerCase())
    );
    if (match) {
      order = match;
    }
  }

  // 2. Lookup order by ID / orderNumber
  if (!order && queryOrder) {
    order = await orderService.getOrder(queryOrder);
  }

  if (!order) {
    return res.status(404).json({
      success: false,
      error: 'No order or shipment found matching the provided details. Please verify your order number or AWB.',
    });
  }

    // IDOR verification: require either phone match (full or last 4 digits) or email match
    if (queryPhone || queryEmail) {
      const orderPhoneClean = (order.customerPhone || '').replace(/\D/g, '');
      const phoneMatches = Boolean(
        queryPhone && (
          orderPhoneClean === queryPhone ||
          orderPhoneClean.endsWith(queryPhone) ||
          queryPhone.endsWith(orderPhoneClean.slice(-4))
        )
      );
      const emailMatches = Boolean(
        queryEmail && order.customerEmail && order.customerEmail.trim().toLowerCase() === queryEmail
      );

      if (!phoneMatches && !emailMatches) {
        return res.status(403).json({
          success: false,
          error: 'Verification failed. The phone number or email does not match this order.',
        });
      }
    }

    // Mask phone & email for privacy
    const maskedPhone = order.customerPhone ? order.customerPhone.replace(/(\d{2})\d{4,6}(\d{2})/, '$1******$2') : undefined;
    const maskedEmail = order.customerEmail ? order.customerEmail.replace(/^(.)(.*)(@.*)$/, (_m: string, a: string, b: string, c: string) => `${a}${'*'.repeat(Math.max(b.length, 3))}${c}`) : undefined;

    return res.json({
      success: true,
      tracking: {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: (order as any).shippingStatus || order.fulfillmentStatus,
        paymentStatus: order.paymentStatus,
        courierPartner: order.courierPartner || 'Delhivery Express',
        awb: order.awbNumber || order.courierTrackingNumber || ('DLHV' + order.orderNumber.replace(/\D/g, '')),
        estimatedDeliveryDate: order.estimatedDeliveryDate || new Date(Date.now() + 4 * 86400000).toISOString().split('T')[0],
        timeline: order.timeline || [
          { status: 'PLACED', title: 'Order Confirmed', description: 'Order successfully verified and sent to fulfillment.', timestamp: order.createdAt },
          { status: 'PROCESSING', title: 'Packed at Warehouse', description: 'Item picked, quality checked, and packaged.', timestamp: order.createdAt },
          { status: 'SHIPPED', title: 'Handed to Courier', description: 'Package in transit via Delhivery Express.', timestamp: new Date(Date.now() - 3600000).toISOString() },
        ],
        shippingAddress: {
          city: order.shippingAddress?.city,
          state: order.shippingAddress?.state,
          pincode: order.shippingAddress?.pincode,
        },
        customer: {
          name: order.customerName,
          phone: maskedPhone,
          email: maskedEmail,
        },
        itemsCount: order.items?.length || 1,
        totalAmount: order.total,
        currency: order.currency || 'INR',
      },
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Tracking service error.' });
  }
});

/**
 * Lookup order by ID or human-readable order number.
 * IDOR Protection: Staff/Admin can view any order; customer queries enforce ownership check.
 */
apiRouter.get('/v1/orders/:orderId', async (req: Request, res: Response) => {
  const order = await orderService.getOrder(req.params.orderId);
  if (!order) {
    return res.status(404).json({ success: false, error: 'Order not found.' });
  }

  const isStaff = await isStaffOrAdmin(req);
  if (!isStaff) {
    const orderToken = (req.headers['x-order-token'] || req.query.orderToken || req.query.token) as string | undefined;
    const callerCustomerId = (req.headers['x-customer-id'] || req.query.customerId) as string | undefined;
    const callerEmail = (req.headers['x-customer-email'] || req.query.email) as string | undefined;

    const hasValidToken = Boolean(orderToken && order.orderAccessToken && orderToken === order.orderAccessToken);
    const hasMatchingCustomer = Boolean(
      (callerCustomerId && order.customerId && callerCustomerId === order.customerId) ||
      (callerEmail && order.customerEmail && callerEmail.trim().toLowerCase() === order.customerEmail.trim().toLowerCase())
    );

    if (!hasValidToken && !hasMatchingCustomer) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to view this order.',
      });
    }

    if (callerCustomerId && order.customerId && callerCustomerId !== order.customerId) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to view this order.',
      });
    }

    if (callerEmail && order.customerEmail && callerEmail.trim().toLowerCase() !== order.customerEmail.trim().toLowerCase()) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to view this order.',
      });
    }
  }

  res.json({ success: true, data: order });
});

/**
 * List customer orders by customer ID or email query.
 * IDOR Protection: Customers can only query their own order history.
 */
apiRouter.get('/v1/orders/customer/:customerId', async (req: Request, res: Response) => {
  const isStaff = await isStaffOrAdmin(req);
  const callerCustomerId = (req.headers['x-customer-id'] || req.query.callerCustomerId) as string | undefined;

  if (!isStaff && (!callerCustomerId || callerCustomerId !== req.params.customerId)) {
    return res.status(403).json({
      success: false,
      error: 'Access denied: You can only query your own orders.',
    });
  }

  const email = typeof req.query.email === 'string' ? req.query.email : undefined;
  const phone = typeof req.query.phone === 'string' ? req.query.phone : undefined;
  const orders = await orderService.getCustomerOrders(req.params.customerId, email, phone);
  res.json({ success: true, count: orders.length, data: orders });
});

/**
 * Customer Order Cancellation (only allowed prior to dispatch).
 * IDOR Protection: Customer can only cancel their own orders.
 */
apiRouter.post('/v1/orders/:orderId/cancel', async (req: Request, res: Response) => {
  const validation = validateCancelOrderInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const order = await orderService.getOrder(req.params.orderId);
  if (!order) {
    return res.status(404).json({ success: false, error: 'Order not found.' });
  }

  const isStaff = await isStaffOrAdmin(req);
  if (!isStaff) {
    const orderToken = (req.headers['x-order-token'] || req.body.orderToken) as string | undefined;
    const callerCustomerId = (req.headers['x-customer-id'] || req.body.customerId) as string | undefined;
    const callerEmail = (req.headers['x-customer-email'] || req.body.customerEmail) as string | undefined;

    const hasValidToken = Boolean(orderToken && order.orderAccessToken && orderToken === order.orderAccessToken);
    const hasMatchingCustomer = Boolean(
      (callerCustomerId && order.customerId && callerCustomerId === order.customerId) ||
      (callerEmail && order.customerEmail && callerEmail.trim().toLowerCase() === order.customerEmail.trim().toLowerCase())
    );

    if (!hasValidToken && !hasMatchingCustomer) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to cancel this order.',
      });
    }

    if (callerCustomerId && order.customerId && callerCustomerId !== order.customerId) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to cancel this order.',
      });
    }

    if (callerEmail && order.customerEmail && callerEmail.trim().toLowerCase() !== order.customerEmail.trim().toLowerCase()) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You do not have permission to cancel this order.',
      });
    }
  }

  const actor = {
    id: req.user?.id || (req.headers['x-customer-id'] as string) || 'CUSTOMER',
    name: req.user?.name || req.body.customerName || order.customerName || 'Customer',
    role: isStaff ? (req.user?.role || 'STAFF') : 'CUSTOMER',
  };

  const result = await orderService.cancelOrder(req.params.orderId, req.body.reason, actor);
  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

/**
 * Admin: List all orders with filters (status, search, customer).
 */
apiRouter.get('/v1/admin/orders', requireStaffPermission('orders.view'), async (req: Request, res: Response) => {
  const status = typeof req.query.status === 'string' ? req.query.status : undefined;
  const search = typeof req.query.search === 'string' ? req.query.search : undefined;
  const customerId = typeof req.query.customerId === 'string' ? req.query.customerId : undefined;

  const orders = await orderService.getAllOrders({ status, search, customerId });
  res.json({ success: true, count: orders.length, data: orders });
});

/**
 * Admin: Get single order with complete snapshots & timeline history.
 */
apiRouter.get('/v1/admin/orders/:orderId', requireStaffPermission('orders.view'), async (req: Request, res: Response) => {
  const order = await orderService.getOrder(req.params.orderId);
  if (!order) {
    return res.status(404).json({ success: false, error: 'Order not found.' });
  }
  res.json({ success: true, data: order });
});

/**
 * Admin: Transition order status using controlled state machine.
 */
apiRouter.put('/v1/admin/orders/:orderId/status', requireStaffPermission('orders.edit'), async (req: Request, res: Response) => {
  const validation = validateUpdateOrderStatusInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const actor = {
    id: req.user?.id || 'STAFF',
    name: req.user?.name || 'Operations Staff',
    role: req.user?.role || 'STAFF',
  };

  const result = await orderService.transitionOrderStatus(
    req.params.orderId,
    req.body.status.toUpperCase(),
    actor,
    req.body.note,
    {
      courierPartner: req.body.courierPartner,
      trackingNumber: req.body.trackingNumber,
    }
  );

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

/**
 * Admin: Cancel order.
 */
apiRouter.post('/v1/admin/orders/:orderId/cancel', requireStaffPermission('orders.edit'), async (req: Request, res: Response) => {
  const validation = validateCancelOrderInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const actor = {
    id: req.user?.id || 'STAFF',
    name: req.user?.name || 'Admin',
    role: req.user?.role || 'ADMIN',
  };

  const result = await orderService.cancelOrder(req.params.orderId, req.body.reason, actor);
  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

/**
 * Admin: Process refund.
 */
apiRouter.post('/v1/admin/orders/:orderId/refund', requireStaffPermission('orders.edit'), async (req: Request, res: Response) => {
  const amount = typeof req.body.amount === 'number' ? req.body.amount : 0;
  const reason = req.body.reason || 'Customer refund requested';

  const actor = {
    id: req.user?.id || 'STAFF',
    name: req.user?.name || 'Admin',
    role: req.user?.role || 'ADMIN',
  };

  const result = await orderService.refundOrder(req.params.orderId, amount, reason, actor);
  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

// ============================================================================
// 8. PAYMENTS (DEMO/SIMULATED & REAL GATEWAY INTERFACES)
// ============================================================================
apiRouter.post('/v1/payments/intent', async (req: Request, res: Response) => {
  const validation = validatePaymentIntentInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const ip = (req.ip || req.socket.remoteAddress || '127.0.0.1').replace('::ffff:', '');
  const result = await paymentService.createPaymentIntent(req.body, ip);

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

apiRouter.post('/v1/payments/verify', async (req: Request, res: Response) => {
  const validation = validatePaymentVerificationInput(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, errors: validation.errors });
  }

  const ip = (req.ip || req.socket.remoteAddress || '127.0.0.1').replace('::ffff:', '');
  const result = await paymentService.verifyPayment(req.body, ip);

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

apiRouter.post('/v1/payments/webhook', async (req: Request, res: Response) => {
  const signature = (req.headers['x-razorpay-signature'] || '') as string;
  const rawBody = (req as any).rawBody;
  const result = await paymentService.processWebhook('razorpay', signature, req.body, rawBody);
  if (!result.success && result.error && !result.duplicate) {
    return res.status(400).json({ received: true, ...result });
  }
  res.json({ received: true, ...result });
});

// ============================================================================
// 9. SHIPPING & TRACKING
// ============================================================================
apiRouter.get('/v1/shipping/track/:identifier', async (req: Request, res: Response) => {
  const result = await shippingService.trackShipment(req.params.identifier);
  if (!result.success) {
    return res.status(404).json(result);
  }
  res.json(result);
});

apiRouter.post(
  '/v1/shipping/manifest',
  requireAuth,
  requireRole(['SUPER_ADMIN', 'STORE_MANAGER', 'INVENTORY_MANAGER', 'FULFILLMENT_STAFF']),
  async (req: Request, res: Response) => {
    const result = await shippingService.createShipment(req.body, req.user?.id || 'STAFF');
    if (!result.success) {
      return res.status(400).json(result);
    }
    res.json(result);
  }
);

/**
 * Shiprocket Webhook Endpoint.
 * Authenticates incoming events, updates live parcel status, and triggers automated inventory restock on RTO.
 */
apiRouter.post('/v1/shipping/webhook/shiprocket', async (req: Request, res: Response) => {
  const token = (
    req.headers['x-api-key'] ||
    req.headers['x-shiprocket-token'] ||
    req.headers['authorization']?.replace(/^Bearer\s+/i, '')
  ) as string | undefined;

  const result = await shippingService.processShiprocketWebhook(token, req.body);
  if (!result.success) {
    const status = result.error?.startsWith('Unauthorized') ? 401 : 400;
    return res.status(status).json(result);
  }
  res.json(result);
});

// ============================================================================
// 9B. MULTI-LOGISTICS PARTNER MANAGEMENT SYSTEM
// ============================================================================

/**
 * Admin: List all logistics partners with masked credentials and health status
 */
apiRouter.get('/v1/admin/logistics/partners', requireStaffPermission('settings.view'), async (_req: Request, res: Response) => {
  try {
    const partners = await logisticsManager.getAllPartners(true);
    const settings = await logisticsManager.getSettings();
    res.json({
      success: true,
      data: {
        partners,
        settings,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch logistics partners.' });
  }
});

/**
 * Admin: Get single logistics partner configuration
 */
apiRouter.get('/v1/admin/logistics/partners/:id', requireStaffPermission('settings.view'), async (req: Request, res: Response) => {
  try {
    const partner = await logisticsManager.getPartnerById(req.params.id, true);
    if (!partner) {
      return res.status(404).json({ success: false, error: 'Carrier configuration not found.' });
    }
    res.json({ success: true, data: partner });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch partner config.' });
  }
});

/**
 * Admin: Update logistics partner settings / API keys / environment
 */
apiRouter.put('/v1/admin/logistics/partners/:id', requireStaffPermission('settings.edit'), async (req: Request, res: Response) => {
  try {
    const updated = await logisticsManager.updatePartner(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Carrier configuration not found.' });
    }
    res.json({ success: true, message: `${updated.name} updated successfully.`, data: updated });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to update partner.' });
  }
});

/**
 * Admin: Test live API connectivity and latency for a partner
 */
apiRouter.post('/v1/admin/logistics/partners/:id/test', requireStaffPermission('settings.edit'), async (req: Request, res: Response) => {
  try {
    const result = await logisticsManager.testPartner(req.params.id);
    res.json({
      success: result.success,
      data: result,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Connectivity test failed.' });
  }
});

/**
 * Admin: Activate or deactivate a logistics partner
 */
apiRouter.post('/v1/admin/logistics/partners/:id/toggle', requireStaffPermission('settings.edit'), async (req: Request, res: Response) => {
  try {
    const updated = await logisticsManager.togglePartner(req.params.id, req.body.isEnabled);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Carrier configuration not found.' });
    }
    res.json({ success: true, message: `${updated.name} is now ${updated.isEnabled ? 'active' : 'disabled'}.`, data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to toggle carrier status.' });
  }
});

/**
 * Admin: Set default carrier
 */
apiRouter.post('/v1/admin/logistics/partners/:id/default', requireStaffPermission('settings.edit'), async (req: Request, res: Response) => {
  try {
    const success = await logisticsManager.setDefaultPartner(req.params.id);
    if (!success) {
      return res.status(404).json({ success: false, error: 'Carrier configuration not found.' });
    }
    const partners = await logisticsManager.getAllPartners(true);
    res.json({ success: true, message: 'Default logistics partner updated.', data: partners });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to set default carrier.' });
  }
});

/**
 * Admin: Update global logistics settings (Allocation strategy, Warehouse PIN)
 */
apiRouter.put('/v1/admin/logistics/settings', requireStaffPermission('settings.edit'), async (req: Request, res: Response) => {
  try {
    const updated = await logisticsManager.updateSettings(req.body);
    res.json({ success: true, message: 'Logistics settings updated.', data: updated });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to update settings.' });
  }
});

/**
 * Admin & Fulfillment: Check PIN Code Serviceability across all active partners
 */
apiRouter.post('/v1/admin/logistics/serviceability', requireStaffPermission('orders.view'), async (req: Request, res: Response) => {
  try {
    const { destinationPin, originPin, codRequired, weightGrams } = req.body;
    if (!destinationPin) {
      return res.status(400).json({ success: false, error: 'Destination pincode is required.' });
    }
    const settings = await logisticsManager.getSettings();
    const results = await logisticsManager.checkServiceability({
      destinationPin: String(destinationPin).trim(),
      originPin: originPin ? String(originPin).trim() : settings.defaultOriginPin,
      codRequired: Boolean(codRequired),
      weightGrams: weightGrams ? Number(weightGrams) : 350,
    });
    res.json({ success: true, data: results });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to check serviceability.' });
  }
});

/**
 * Admin & Fulfillment: Compare Live Rates across all active partners
 */
apiRouter.post('/v1/admin/logistics/rates', requireStaffPermission('orders.view'), async (req: Request, res: Response) => {
  try {
    const { destinationPin, originPin, weightGrams, lengthCm, breadthCm, heightCm, cod, declaredValue } = req.body;
    if (!destinationPin) {
      return res.status(400).json({ success: false, error: 'Destination pincode is required.' });
    }
    const settings = await logisticsManager.getSettings();
    const quotes = await logisticsManager.compareRates({
      destinationPin: String(destinationPin).trim(),
      originPin: originPin ? String(originPin).trim() : settings.defaultOriginPin,
      weightGrams: Number(weightGrams) || 350,
      lengthCm: lengthCm ? Number(lengthCm) : 30,
      breadthCm: breadthCm ? Number(breadthCm) : 25,
      heightCm: heightCm ? Number(heightCm) : 4,
      cod: Boolean(cod),
      declaredValue: declaredValue ? Number(declaredValue) : 1999,
    });
    res.json({ success: true, data: quotes });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to calculate rates.' });
  }
});

/**
 * Admin & Fulfillment: Manifest order shipment, generate AWB and shipping label
 */
apiRouter.post('/v1/admin/logistics/shipments', requireStaffPermission('orders.edit'), async (req: Request, res: Response) => {
  try {
    const result = await logisticsManager.createShipment(req.body);
    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: result.error || 'Carrier manifestation failed.',
        data: result,
      });
    }

    // If orderId is provided, update order record with courier & tracking
    if (req.body.orderId && result.awbNumber) {
      try {
        await orderService.transitionOrderStatus(
          req.body.orderId,
          'PROCESSING',
          { id: req.user?.id || 'STAFF', name: req.user?.name || 'Fulfillment Staff', role: req.user?.role || 'STAFF' },
          `Fulfillment manifested via ${result.carrierName}. AWB: ${result.awbNumber}`,
          { courierPartner: result.carrierName, trackingNumber: result.awbNumber }
        );
      } catch {
        // Order state update non-blocking
      }
    }
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(400).json({ success: false, error: err.message || 'Failed to create shipment.' });
  }
});

/**
 * Printable Shipping Label (HTML format for thermal / A4 label printing)
 */
apiRouter.get('/v1/admin/logistics/shipments/:awb/label', async (req: Request, res: Response) => {
  try {
    const html = await logisticsManager.getShippingLabel(req.params.awb);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  } catch (err: any) {
    res.status(500).send(`<h2>Error rendering shipping label: ${err.message}</h2>`);
  }
});

/**
 * Live AWB tracking across all carriers
 */
apiRouter.get('/v1/admin/logistics/shipments/:awb/track', async (req: Request, res: Response) => {
  try {
    const carrier = req.query.carrier as any;
    const details = await logisticsManager.trackShipment(req.params.awb, carrier);
    res.json({ success: true, data: details });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Tracking lookup failed.' });
  }
});

/**
 * Unified multi-carrier webhook endpoint
 */
apiRouter.post('/v1/shipping/webhook/:carrier', async (req: Request, res: Response) => {
  try {
    const result = await logisticsManager.handleWebhook(req.params.carrier, req.body, req.headers);
    res.json({ received: true, ...result });
  } catch (err: any) {
    res.status(400).json({ received: false, error: err.message });
  }
});

// ============================================================================
// 10. COUPONS & PROMOTIONS (SERVER-AUTHORITATIVE PERSISTENCE & VALIDATION)
// ============================================================================

/**
 * Public Coupon Validation Endpoint
 * Validates active status, date range, min order value, and returns computed discount.
 */
apiRouter.get('/v1/coupons/validate/:code', async (req: Request, res: Response) => {
  const subtotal = req.query.subtotal ? Number(req.query.subtotal) : 0;
  const validation = await couponRepository.validate(req.params.code, subtotal);
  if (!validation.valid || !validation.coupon) {
    return res.status(400).json({
      success: false,
      error: validation.reason || 'Invalid or inactive coupon code.',
    });
  }

  const c = validation.coupon;
  res.json({
    success: true,
    code: c.code,
    discountType: c.discountType,
    value: c.value,
    maxDiscount: c.maxDiscount,
    minOrderValue: c.minOrderValue,
    calculatedDiscount: validation.discount,
    discountAmount: validation.discount,
    description: c.description,
  });
});

/**
 * Public Coupon Validation POST Endpoint (for checkout quotes and dynamic cart calculations)
 */
apiRouter.post('/v1/coupons/validate', async (req: Request, res: Response) => {
  const { code, subtotal } = req.body;
  const numSubtotal = typeof subtotal === 'number' ? subtotal : Number(subtotal || 0);
  const validation = await couponRepository.validate(code, numSubtotal);

  if (!validation.valid || !validation.coupon) {
    return res.json({
      success: true,
      data: {
        valid: false,
        reason: validation.reason || 'Invalid or inactive coupon code.',
        discountAmount: 0,
        calculatedDiscount: 0,
      },
    });
  }

  const c = validation.coupon;
  res.json({
    success: true,
    data: {
      valid: true,
      code: c.code,
      discountType: c.discountType,
      value: c.value,
      discountAmount: validation.discount,
      calculatedDiscount: validation.discount,
      minOrderValue: c.minOrderValue,
      maxDiscount: c.maxDiscount,
      description: c.description,
    },
  });
});

/**
 * Admin: List all coupons
 */
apiRouter.get('/v1/admin/coupons', requireStaffPermission('marketing.view'), async (_req: Request, res: Response) => {
  const coupons = await couponRepository.getAll();
  res.json({ success: true, count: coupons.length, data: coupons });
});

/**
 * Admin: Create new coupon
 */
apiRouter.post('/v1/admin/coupons', requireStaffPermission('marketing.edit'), async (req: Request, res: Response) => {
  try {
    const code = req.body.code;
    const rawVal = req.body.value !== undefined ? req.body.value : req.body.discountValue;
    if (!code || rawVal === undefined) {
      return res.status(400).json({ success: false, error: 'Both coupon "code" and "value" (or "discountValue") are required.' });
    }

    const discountType = req.body.discountType === 'PERCENTAGE' ? 'PERCENTAGE' : 'FLAT';
    const minOrderValue = req.body.minOrderValue !== undefined ? req.body.minOrderValue : (req.body.minOrder || 0);
    const maxDiscount = req.body.maxDiscount !== undefined ? req.body.maxDiscount : req.body.maxDiscountAmount;
    const usageLimit = req.body.usageLimit !== undefined ? req.body.usageLimit : req.body.usageLimitTotal;
    const startDate = req.body.startDate;
    const expiryDate = req.body.expiryDate;
    const isActive = req.body.isActive !== undefined ? req.body.isActive : (req.body.active !== undefined ? req.body.active : true);
    const description = req.body.description || '';

    const created = await couponRepository.create(
      {
        code: String(code).toUpperCase().trim(),
        discountType,
        value: Number(rawVal),
        minOrderValue: Number(minOrderValue),
        maxDiscount: maxDiscount !== undefined ? Number(maxDiscount) : undefined,
        usageLimit: usageLimit !== undefined ? Number(usageLimit) : undefined,
        startDate: startDate ? new Date(startDate) : new Date(),
        expiryDate: expiryDate ? new Date(expiryDate) : new Date('2026-12-31T23:59:59.000Z'),
        isActive: Boolean(isActive),
        description: description || '',
      },
      req.user?.id || 'ADMIN'
    );

    res.status(201).json({
      success: true,
      message: 'Coupon created successfully.',
      data: {
        ...created,
        active: created.isActive,
        discountValue: created.value,
      },
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to create coupon.' });
  }
});

/**
 * Admin: Update coupon
 */
apiRouter.put('/v1/admin/coupons/:id', requireStaffPermission('marketing.edit'), async (req: Request, res: Response) => {
  try {
    const updated = await couponRepository.update(req.params.id, req.body, req.user?.id || 'ADMIN');
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Coupon not found.' });
    }
    res.json({ success: true, message: 'Coupon updated successfully.', data: updated });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to update coupon.' });
  }
});

/**
 * Admin: Toggle coupon active/inactive status
 */
apiRouter.post('/v1/admin/coupons/:id/toggle', requireStaffPermission('marketing.edit'), async (req: Request, res: Response) => {
  try {
    const updated = await couponRepository.toggleActive(req.params.id, req.user?.id || 'ADMIN');
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Coupon not found.' });
    }
    res.json({
      success: true,
      message: `Coupon is now ${updated.isActive ? 'active' : 'inactive'}.`,
      data: {
        ...updated,
        active: updated.isActive,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to toggle coupon status.' });
  }
});

/**
 * Admin: Delete coupon
 */
apiRouter.delete('/v1/admin/coupons/:id', requireStaffPermission('marketing.edit'), async (req: Request, res: Response) => {
  try {
    const success = await couponRepository.delete(req.params.id, req.user?.id || 'ADMIN');
    if (!success) {
      return res.status(404).json({ success: false, error: 'Coupon not found.' });
    }
    res.json({ success: true, message: 'Coupon deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to delete coupon.' });
  }
});
