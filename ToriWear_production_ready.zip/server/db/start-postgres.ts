import EmbeddedPostgres from 'embedded-postgres';
import pg from 'pg';
import fs from 'fs';

async function main() {
  const isProduction = process.env.NODE_ENV === 'production';

  // Strict architectural guard: Never run embedded PostgreSQL in production
  if (isProduction) {
    console.error('[PG-FATAL] Embedded PostgreSQL is strictly prohibited in production.');
    console.error('[PG-FATAL] TORIWEAR production requires a managed PostgreSQL instance (e.g. AWS RDS, GCP Cloud SQL, Supabase, Neon) connected via DATABASE_URL.');
    console.error('[PG-FATAL] Database migrations must be applied using "npx prisma migrate deploy" and NOT "prisma db push".');
    process.exit(1);
  }

  // Development / Sandbox Local PostgreSQL runner
  const pgDir = process.env.EMBEDDED_PG_DIR || '/tmp/toriwear_pgdata';
  const port = parseInt(process.env.PGPORT || '5433', 10);
  const user = process.env.PGUSER || 'postgres';
  const password = process.env.PGPASSWORD || 'postgrespassword';

  const pgInstance = new EmbeddedPostgres({
    databaseDir: pgDir,
    port,
    user,
    password,
    authMethod: 'password',
    persistent: true,
    createPostgresUser: true,
    autoRehydrateSymlinks: true,
  });

  if (!fs.existsSync(pgDir)) {
    console.log('[PG-DEV] Initialising new development cluster...');
    await pgInstance.initialise();
  }

  console.log(`[PG-DEV] Starting development PostgreSQL cluster on port ${port}...`);
  await pgInstance.start();

  // Create database toriwear if it doesn't exist
  const client = new pg.Client({
    host: '127.0.0.1',
    port,
    user,
    password,
    database: 'postgres',
  });
  await client.connect();
  const res = await client.query("SELECT 1 FROM pg_database WHERE datname = 'toriwear'");
  if (res.rowCount === 0) {
    console.log('[PG-DEV] Creating database toriwear...');
    await client.query('CREATE DATABASE toriwear');
  }
  await client.end();

  // Verify and sync schema tables in development only
  try {
    const { execSync } = await import('child_process');
    const toriClient = new pg.Client({
      host: '127.0.0.1',
      port,
      user,
      password,
      database: 'toriwear',
    });
    await toriClient.connect();
    const tableRes = await toriClient.query("SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public'");
    const tableCount = parseInt(tableRes.rows[0]?.count || '0', 10);
    await toriClient.end();

    if (tableCount === 0) {
      console.log('[PG-DEV] Empty development database detected. Applying Prisma schema...');
      execSync('npx prisma db push --skip-generate', { stdio: 'inherit' });
      console.log('[PG-DEV] Prisma schema synchronized for local development.');
    }
  } catch (syncErr) {
    console.warn('[PG-DEV] Schema check note:', syncErr);
  }

  console.log(`[PG-DEV] Local PostgreSQL successfully running on port ${port} with database toriwear.`);

  // Keep process alive in dev
  setInterval(() => {}, 60000);
}

main().catch((err) => {
  console.error('[PG] Fatal error:', err);
  process.exit(1);
});
