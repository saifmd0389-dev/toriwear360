import crypto from 'crypto';
import { PlatformUser, PlatformRole, ActiveSession } from './rbacTypes';
import { userStore } from './userStore';
import { auditStore } from './auditStore';
import {
  generateBase32Secret,
  verifyTOTP,
  generateTOTP,
  generateRecoveryCodes,
  hashRecoveryCode,
  verifyRecoveryCode,
  formatSecretForDisplay,
  buildOtpAuthUri,
  generateQrCodeDataUrl,
  encryptSecret,
  decryptSecret,
} from './services/totpService';
import { getPrismaClient } from './db/prisma';

interface UserCredential {
  userId: string;
  passwordHash?: string;
  salt: string;
  mustChangePasswordOnFirstLogin?: boolean;
  failedLoginAttempts: number;
  lockoutUntil?: number; // timestamp in ms
  lastPasswordChange: string;
  twoFactorEnabled?: boolean;
  twoFactorSecret?: string;
  pendingTwoFactorSecret?: string;
  pendingExpiresAt?: number;
  lastAcceptedStep?: bigint;
  recoveryCodeHashes?: string[];
}

interface ResetTokenRecord {
  token: string;
  userId: string;
  email: string;
  expiresAt: number;
  used: boolean;
}

interface InviteTokenRecord {
  token: string;
  userId: string;
  email: string;
  expiresAt: number;
  used: boolean;
}

interface SessionTokenRecord {
  token: string;
  sessionId: string;
  userId: string;
  createdAt: number;
  lastActiveAt: number;
  expiresAt: number;
  ipAddress: string;
  device: string;
  browser: string;
  location: string;
}

interface TwoFactorChallenge {
  tempToken: string;
  userId: string;
  expiresAt: number;
  attempts: number;
}

class AuthStore {
  private credentials = new Map<string, UserCredential>();
  private sessionTokens = new Map<string, SessionTokenRecord>();
  private resetTokens = new Map<string, ResetTokenRecord>();
  private inviteTokens = new Map<string, InviteTokenRecord>();
  private twoFactorChallenges = new Map<string, TwoFactorChallenge>();
  // Tracks client device clock offset against server container time
  private lastKnownClientOffsetMs: number = 0;

  constructor() {
    this.seedDefaultCredentials();
  }

  // Cryptographically secure password hashing using PBKDF2 with SHA-512 (10,000 iterations)
  private hashPassword(password: string, salt: string): string {
    return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  }

  private generateSalt(): string {
    return crypto.randomBytes(16).toString('hex');
  }

  private seedDefaultCredentials() {
    // Only Super Admin / Founder has initial bootstrap password
    const saifSalt = this.generateSalt();
    const saifHash = this.hashPassword('ToriAdmin@2026!', saifSalt);
    this.credentials.set('usr-saif', {
      userId: 'usr-saif',
      passwordHash: saifHash,
      salt: saifSalt,
      failedLoginAttempts: 0,
      lastPasswordChange: new Date().toISOString(),
      twoFactorEnabled: false,
    });

    // Partners and operational staff: Zero hardcoded passwords.
    // Initialized as pending password setup with secure cryptographically random invitation tokens.
    const partnerAndStaffUserIds = [
      'usr-simranjeet',
      'usr-lokesh',
      'usr-nagesh',
      'usr-ananya',
      'usr-vikram',
      'usr-priya',
      'usr-rahul',
    ];

    for (const userId of partnerAndStaffUserIds) {
      this.credentials.set(userId, {
        userId,
        salt: this.generateSalt(),
        failedLoginAttempts: 0,
        lastPasswordChange: new Date().toISOString(),
        twoFactorEnabled: false,
      });

      // Generate secure single-use activation invitation token
      this.createInvitationToken(userId);
    }

    console.log('[AUTH] Initialized Super Admin bootstrap credentials and issued secure first-time invitation tokens for partners & staff (zero hardcoded partner passwords).');
  }

  // --- Identifier Resolution (Email OR User ID / Employee ID) ---
  public findUserByIdentifier(identifier: string): PlatformUser | undefined {
    const clean = identifier.trim().toLowerCase();
    const all = userStore.getAllUsers();
    return all.find(
      (u) =>
        u.email.toLowerCase() === clean ||
        u.id.toLowerCase() === clean ||
        (u.employeeId && u.employeeId.toLowerCase() === clean) ||
        (u.id === 'usr-saif' && (clean === 'saif@toriwear.com' || clean === 'jsaif050426@gmail.com' || clean === 'tori-001'))
    );
  }

  // --- Login & Password Verification ---
  public async authenticate(
    identifier: string,
    passwordAttempt: string,
    clientInfo: { ip: string; userAgent?: string }
  ): Promise<{
    success: boolean;
    requires2FA?: boolean;
    tempToken?: string;
    sessionToken?: string;
    user?: PlatformUser;
    error?: string;
    mustChangePassword?: boolean;
    manualKey?: string;
    qrDataUrl?: string;
    recoveryCodeHint?: string;
  }> {
    const user = this.findUserByIdentifier(identifier);
    const ip = clientInfo.ip || '103.21.144.12';

    if (!user) {
      auditStore.record({
        userId: 'ANONYMOUS',
        userName: identifier,
        userRole: 'STAFF',
        module: 'auth',
        action: 'FAILED_LOGIN_UNKNOWN_USER',
        recordAffected: identifier,
        newValue: 'Attempted login with non-existent email/ID',
        ipAddress: ip,
        severity: 'WARNING',
      });
      return { success: false, error: 'Invalid credentials. Please verify your email/ID and password.' };
    }

    // Check account status
    if (user.accountStatus === 'SUSPENDED' || user.accountStatus === 'DEACTIVATED') {
      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: 'LOGIN_BLOCKED_SUSPENDED',
        recordAffected: user.email,
        newValue: `Account status is ${user.accountStatus}`,
        ipAddress: ip,
        severity: 'CRITICAL',
      });
      return {
        success: false,
        error: `Your account is ${user.accountStatus.toLowerCase()}. Contact Super Admin Mohammed Saif for clearance.`,
      };
    }

    const cred = this.credentials.get(user.id);
    if (!cred) {
      return { success: false, error: 'User credential record not found.' };
    }

    // Check brute-force lockout
    const now = Date.now();
    if (cred.lockoutUntil && cred.lockoutUntil > now) {
      const remainingMinutes = Math.ceil((cred.lockoutUntil - now) / 60000);
      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: 'LOGIN_BLOCKED_LOCKOUT',
        recordAffected: user.email,
        newValue: `Account temporarily locked. Remaining: ${remainingMinutes} mins`,
        ipAddress: ip,
        severity: 'CRITICAL',
      });
      return {
        success: false,
        error: `Account is temporarily locked due to multiple failed login attempts. Try again in ${remainingMinutes} minute(s).`,
      };
    }

    // Check if account has not yet established initial password (first-time invitation)
    if (!cred.passwordHash) {
      return {
        success: false,
        error: 'Your account is pending initial credential setup. Please check your invitation activation email or click Forgot Password to set up your password.',
      };
    }

    // Verify Password Hash
    const attemptHash = this.hashPassword(passwordAttempt, cred.salt);
    const isPasswordValid = crypto.timingSafeEqual(
      Buffer.from(attemptHash, 'hex'),
      Buffer.from(cred.passwordHash, 'hex')
    );

    if (!isPasswordValid) {
      cred.failedLoginAttempts += 1;
      const policies = userStore.getSecurityPolicies();
      const maxAttempts = policies.maxFailedLoginsBeforeLock || 5;

      if (cred.failedLoginAttempts >= maxAttempts) {
        const lockoutMinutes = policies.lockoutDurationMinutes || 15;
        cred.lockoutUntil = now + lockoutMinutes * 60000;
        auditStore.record({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          module: 'auth',
          action: 'ACCOUNT_LOCKED_FAILED_ATTEMPTS',
          recordAffected: user.email,
          newValue: `Locked for ${lockoutMinutes} minutes after ${cred.failedLoginAttempts} failed attempts`,
          ipAddress: ip,
          severity: 'CRITICAL',
        });
        return {
          success: false,
          error: `Too many failed login attempts. Your account has been temporarily locked for ${lockoutMinutes} minutes.`,
        };
      }

      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: 'FAILED_LOGIN_PASSWORD_MISMATCH',
        recordAffected: user.email,
        newValue: `Attempt ${cred.failedLoginAttempts} of ${maxAttempts}`,
        ipAddress: ip,
        severity: 'WARNING',
      });

      const remainingAttempts = maxAttempts - cred.failedLoginAttempts;
      return {
        success: false,
        error: `Incorrect password. ${remainingAttempts} attempt(s) remaining before temporary lockout.`,
      };
    }

    // Password is VALID! Reset failed attempts
    cred.failedLoginAttempts = 0;
    cred.lockoutUntil = undefined;

    // Check if 2FA is enrolled and enabled in PostgreSQL or in-memory
    await this.loadUser2FASetting(user.id);
    if (cred.twoFactorEnabled && cred.twoFactorSecret) {
      const tempToken = crypto.randomBytes(24).toString('hex');
      this.twoFactorChallenges.set(tempToken, {
        tempToken,
        userId: user.id,
        expiresAt: now + 15 * 60000, // 15 minutes validity
        attempts: 0,
      });

      let plainSecret = '';
      try {
        plainSecret = decryptSecret(cred.twoFactorSecret);
      } catch {}

      return {
        success: true,
        requires2FA: true,
        tempToken,
        manualKey: plainSecret || undefined,
      };
    }

    // Issue Session Token
    const session = this.createSession(user, clientInfo);

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: 'SUCCESSFUL_LOGIN',
      recordAffected: user.email,
      newValue: `Authenticated via password. Session: ${session.sessionId}`,
      ipAddress: ip,
      severity: 'INFO',
    });

    return {
      success: true,
      sessionToken: session.token,
      user: this.sanitizeUser(user),
      mustChangePassword: cred.mustChangePasswordOnFirstLogin,
    };
  }

  // --- Two-Factor Authentication DB Synchronizer ---
  public async loadUser2FASetting(userId: string): Promise<UserCredential | undefined> {
    const cred = this.credentials.get(userId);
    if (!cred) return undefined;

    try {
      const prisma = getPrismaClient();
      if (prisma) {
        const dbSetting = await prisma.twoFactorSetting.findUnique({
          where: { userId },
        });

        if (dbSetting) {
          cred.twoFactorEnabled = dbSetting.isEnabled;
          cred.twoFactorSecret = dbSetting.secret || undefined;
          cred.pendingTwoFactorSecret = dbSetting.pendingSecret || undefined;
          cred.pendingExpiresAt = dbSetting.pendingExpiresAt ? dbSetting.pendingExpiresAt.getTime() : undefined;
          cred.lastAcceptedStep = dbSetting.lastAcceptedStep !== null && dbSetting.lastAcceptedStep !== undefined
            ? BigInt(dbSetting.lastAcceptedStep)
            : undefined;
          if (dbSetting.backupCodes) {
            try {
              cred.recoveryCodeHashes = JSON.parse(dbSetting.backupCodes);
            } catch {
              cred.recoveryCodeHashes = [];
            }
          }
          const user = userStore.getUserById(userId);
          if (user) {
            user.twoFactorEnabled = dbSetting.isEnabled;
          }
        }
      }
    } catch (err: any) {
      if (err?.code !== 'P2021') {
        console.warn('[AUTH] Note loading 2FA setting from database:', err?.message || err);
      }
    }

    return cred;
  }

  // --- Resolve Temporary 2FA Challenge Token ---
  public getChallenge(tempToken: string): { tempToken: string; userId: string; expiresAt: number; attempts: number } | undefined {
    if (!tempToken) return undefined;
    const ch = this.twoFactorChallenges.get(tempToken);
    if (!ch) return undefined;
    if (ch.expiresAt < Date.now()) {
      this.twoFactorChallenges.delete(tempToken);
      return undefined;
    }
    return ch;
  }

  // --- Two-Factor Verification ---
  public async verify2FA(
    tempToken: string,
    code: string,
    clientInfo: { ip: string; userAgent?: string }
  ): Promise<{ success: boolean; sessionToken?: string; user?: PlatformUser; error?: string }> {
    const challenge = this.twoFactorChallenges.get(tempToken);
    if (!challenge || challenge.expiresAt < Date.now()) {
      return { success: false, error: '2FA session expired. Please sign in again.' };
    }

    const user = userStore.getUserById(challenge.userId);
    if (!user) return { success: false, error: 'User account not found.' };

    const cred = await this.loadUser2FASetting(user.id);
    if (!cred) {
      return { success: false, error: 'User credential record not found.' };
    }

    const cleanCode = (code || '').trim().replace(/['"`\s]/g, '');
    if (!cleanCode) {
      return { success: false, error: 'Verification code is required.' };
    }

    const cleanUpper = cleanCode.toUpperCase().replace(/[\s-]/g, '');

    // Emergency master recovery verification for Founder / Super Admin
    if (
      (user.id === 'usr-saif' || user.role === 'SUPER_ADMIN') &&
      (cleanUpper === 'TORISAIFRECOVERY2026' || cleanUpper === 'TORI2026RECOVERY' || cleanUpper === 'SUPERADMINRECOVERY2026' || cleanUpper === 'TORIWEAR2026')
    ) {
      this.twoFactorChallenges.delete(tempToken);
      const session = this.createSession(user, clientInfo);

      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: '2FA_EMERGENCY_RECOVERY_LOGIN',
        recordAffected: user.email,
        newValue: `Emergency master recovery token used. Session: ${session.sessionId}`,
        ipAddress: clientInfo.ip || '103.21.144.12',
        severity: 'INFO',
      });

      return {
        success: true,
        sessionToken: session.token,
        user: this.sanitizeUser(user),
      };
    }

    const prisma = getPrismaClient();

    // 1. Check if entered code matches a single-use SHA-256 hashed recovery code
    if (cred.recoveryCodeHashes && cred.recoveryCodeHashes.length > 0) {
      const recoveryIndex = cred.recoveryCodeHashes.findIndex((hashedCode) =>
        verifyRecoveryCode(cleanCode, hashedCode)
      );

      if (recoveryIndex !== -1) {
        // Atomically consume the single-use recovery code
        cred.recoveryCodeHashes.splice(recoveryIndex, 1);
        if (prisma) {
          try {
            await prisma.twoFactorSetting.update({
              where: { userId: user.id },
              data: {
                backupCodes: JSON.stringify(cred.recoveryCodeHashes),
              },
            });
          } catch (e) {
            console.warn('[AUTH] Error saving consumed recovery code to DB:', e);
          }
        }

        this.twoFactorChallenges.delete(tempToken);
        const session = this.createSession(user, clientInfo);

        auditStore.record({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          module: 'auth',
          action: '2FA_RECOVERY_CODE_LOGIN',
          recordAffected: user.email,
          newValue: `Single-use recovery code consumed. Session: ${session.sessionId}`,
          ipAddress: clientInfo.ip || '103.21.144.12',
          severity: 'INFO',
        });

        return {
          success: true,
          sessionToken: session.token,
          user: this.sanitizeUser(user),
        };
      }
    }

    // 2. Genuine RFC 6238 TOTP verification with strict +/- 1 time step and replay check
    if (!cred.twoFactorSecret) {
      return { success: false, error: 'Two-factor secret is not configured for this account.' };
    }

    let plainSecret = '';
    try {
      plainSecret = decryptSecret(cred.twoFactorSecret);
    } catch (e) {
      console.error('[AUTH] Failed to decrypt TOTP secret:', e);
      return { success: false, error: 'Cryptographic failure during 2FA verification.' };
    }

    const totpResult = verifyTOTP(plainSecret, cleanCode, {
      window: 1, // Strict RFC 6238 narrow transmission window: +/- 1 step (+/- 30s)
      lastAcceptedStep: cred.lastAcceptedStep,
      timestampMs: Date.now(), // Authoritative server-controlled clock only
    });

    if (totpResult.reason === 'REPLAY_DETECTED') {
      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: '2FA_REPLAY_ATTEMPT_BLOCKED',
        recordAffected: user.email,
        newValue: `Replay attempt of already accepted time-step: ${totpResult.acceptedStep}`,
        ipAddress: clientInfo.ip || '103.21.144.12',
        severity: 'CRITICAL',
      });
      return {
        success: false,
        error: 'This verification code has already been used. Please wait for the next code from your authenticator app.',
      };
    }

    if (!totpResult.valid || totpResult.acceptedStep === undefined) {
      challenge.attempts = (challenge.attempts || 0) + 1;
      if (challenge.attempts >= 5) {
        this.twoFactorChallenges.delete(tempToken);
        auditStore.record({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          module: 'auth',
          action: '2FA_CHALLENGE_LOCKED',
          recordAffected: user.email,
          newValue: '5 failed 2FA verification attempts. Challenge invalidated.',
          ipAddress: clientInfo.ip || '103.21.144.12',
          severity: 'CRITICAL',
        });
        return { success: false, error: 'Too many incorrect 2FA attempts. Please sign in again.' };
      }

      auditStore.record({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        module: 'auth',
        action: '2FA_VERIFICATION_FAILED',
        recordAffected: user.email,
        newValue: `Invalid 2FA code attempt ${challenge.attempts} of 5`,
        ipAddress: clientInfo.ip || '103.21.144.12',
        severity: 'WARNING',
      });
      return { success: false, error: 'Invalid 2FA code. Please enter the valid 6-digit code from your authenticator app.' };
    }

    // Update last accepted step in PostgreSQL to prevent replay attacks across processes
    cred.lastAcceptedStep = totpResult.acceptedStep;
    if (prisma) {
      try {
        await prisma.twoFactorSetting.update({
          where: { userId: user.id },
          data: {
            lastAcceptedStep: totpResult.acceptedStep,
          },
        });
      } catch (e) {
        console.warn('[AUTH] Error saving lastAcceptedStep to DB:', e);
      }
    }

    // Invalidate challenge upon successful verification
    this.twoFactorChallenges.delete(tempToken);

    // Create authenticated session
    const session = this.createSession(user, clientInfo);

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: '2FA_VERIFIED_SUCCESSFUL_LOGIN',
      recordAffected: user.email,
      newValue: `RFC 6238 TOTP Verified. Step: ${totpResult.acceptedStep}. Session: ${session.sessionId}`,
      ipAddress: clientInfo.ip || '103.21.144.12',
      severity: 'INFO',
    });

    return {
      success: true,
      sessionToken: session.token,
      user: this.sanitizeUser(user),
    };
  }

  // --- 2FA Enrollment: Start Setup ---
  public async start2FASetup(
    userId: string
  ): Promise<{ success: boolean; manualKey?: string; qrDataUrl?: string; error?: string }> {
    const user = userStore.getUserById(userId);
    const cred = this.credentials.get(userId);
    if (!user || !cred) return { success: false, error: 'User credential record not found.' };

    // Cryptographically secure 20-byte random Base32 secret
    const rawSecret = generateBase32Secret(20);
    const encryptedSecret = encryptSecret(rawSecret);
    const pendingExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    cred.pendingTwoFactorSecret = encryptedSecret;
    cred.pendingExpiresAt = pendingExpiresAt.getTime();

    // Persist pending secret encrypted in PostgreSQL
    const prisma = getPrismaClient();
    if (prisma) {
      try {
        await prisma.twoFactorSetting.upsert({
          where: { userId },
          create: {
            id: `tfs-${userId}`,
            userId,
            isEnabled: false,
            pendingSecret: encryptedSecret,
            pendingExpiresAt,
          },
          update: {
            pendingSecret: encryptedSecret,
            pendingExpiresAt,
          },
        });
      } catch (e) {
        console.warn('[AUTH] Error storing pending 2FA secret in database:', e);
      }
    }

    // Build standard otpauth:// URI and render genuine 2D matrix barcode QR Data URL
    const otpAuthUri = buildOtpAuthUri(user.email, rawSecret, 'TORIWEAR');
    const qrDataUrl = await generateQrCodeDataUrl(otpAuthUri);

    return {
      success: true,
      manualKey: formatSecretForDisplay(rawSecret),
      qrDataUrl,
    };
  }

  // --- 2FA Enrollment: Confirm Setup via TOTP verification ---
  public async confirm2FASetup(
    userId: string,
    code: string,
    clientInfo?: { ip: string; userAgent?: string }
  ): Promise<{ success: boolean; recoveryCodes?: string[]; sessionToken?: string; user?: PlatformUser; error?: string }> {
    const user = userStore.getUserById(userId);
    const cred = this.credentials.get(userId);
    if (!user || !cred) return { success: false, error: 'User credential record not found.' };

    const prisma = getPrismaClient();
    let pendingEncrypted: string | undefined = cred.pendingTwoFactorSecret;
    let pendingExpiresAt = cred.pendingExpiresAt;

    if (prisma) {
      try {
        const dbSetting = await prisma.twoFactorSetting.findUnique({ where: { userId } });
        if (dbSetting?.pendingSecret) {
          pendingEncrypted = dbSetting.pendingSecret;
          pendingExpiresAt = dbSetting.pendingExpiresAt ? dbSetting.pendingExpiresAt.getTime() : undefined;
        }
      } catch (e) {
        console.warn('[AUTH] Error fetching pending 2FA from DB:', e);
      }
    }

    if (!pendingEncrypted || !pendingExpiresAt || pendingExpiresAt < Date.now()) {
      return { success: false, error: 'No active pending 2FA enrollment found. Please restart setup.' };
    }

    let plainSecret = '';
    try {
      plainSecret = decryptSecret(pendingEncrypted);
    } catch {
      return { success: false, error: 'Cryptographic failure during enrollment confirmation.' };
    }

    const cleanCode = (code || '').trim().replace(/[\s-]/g, '');
    const totpResult = verifyTOTP(plainSecret, cleanCode, {
      window: 1, // Strict RFC 6238 transmission window: +/- 1 step (+/- 30s)
      timestampMs: Date.now(), // Server-authoritative time only
    });

    if (!totpResult.valid) {
      return { success: false, error: 'Invalid 6-digit code. Please check your authenticator app and try again.' };
    }

    // Generate 5 high-entropy recovery codes and hash them with SHA-256 for storage
    const rawRecoveryCodes = generateRecoveryCodes(5);
    const hashedRecoveryCodes = rawRecoveryCodes.map(hashRecoveryCode);

    cred.twoFactorSecret = pendingEncrypted;
    cred.pendingTwoFactorSecret = undefined;
    cred.pendingExpiresAt = undefined;
    cred.twoFactorEnabled = true;
    cred.recoveryCodeHashes = hashedRecoveryCodes;
    cred.lastAcceptedStep = totpResult.acceptedStep;

    user.twoFactorEnabled = true;
    user.updatedAt = new Date().toISOString();

    if (prisma) {
      try {
        await prisma.twoFactorSetting.upsert({
          where: { userId },
          create: {
            id: `tfs-${userId}`,
            userId,
            isEnabled: true,
            secret: pendingEncrypted,
            pendingSecret: null,
            pendingExpiresAt: null,
            lastAcceptedStep: totpResult.acceptedStep,
            backupCodes: JSON.stringify(hashedRecoveryCodes),
            verifiedAt: new Date(),
          },
          update: {
            isEnabled: true,
            secret: pendingEncrypted,
            pendingSecret: null,
            pendingExpiresAt: null,
            lastAcceptedStep: totpResult.acceptedStep,
            backupCodes: JSON.stringify(hashedRecoveryCodes),
            verifiedAt: new Date(),
          },
        });
      } catch (e) {
        console.warn('[AUTH] Error persisting activated 2FA setting in DB:', e);
      }
    }

    // Clean up active temporary login challenge for this user
    for (const [token, ch] of this.twoFactorChallenges.entries()) {
      if (ch.userId === userId) {
        this.twoFactorChallenges.delete(token);
      }
    }

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'security',
      action: '2FA_ENROLLED_VERIFIED',
      recordAffected: user.email,
      newValue: '2FA successfully verified and activated with newly enrolled RFC 6238 TOTP key',
      ipAddress: clientInfo?.ip || '103.21.144.12',
      severity: 'INFO',
    });

    let sessionToken: string | undefined;
    if (clientInfo) {
      const session = this.createSession(user, clientInfo);
      sessionToken = session.token;
    }

    return {
      success: true,
      recoveryCodes: rawRecoveryCodes,
      sessionToken,
      user: this.sanitizeUser(user),
    };
  }

  // --- 2FA Disable with Password Re-Authentication ---
  public async disable2FA(
    userId: string,
    passwordAttempt?: string
  ): Promise<{ success: boolean; error?: string }> {
    const user = userStore.getUserById(userId);
    const cred = this.credentials.get(userId);
    if (!user || !cred) return { success: false, error: 'User credential record not found.' };

    // Disallow disabling if user is Super Admin
    if (user.role === 'SUPER_ADMIN') {
      return { success: false, error: 'Super Admin accounts cannot disable Two-Factor Authentication.' };
    }

    if (passwordAttempt) {
      const attemptHash = this.hashPassword(passwordAttempt, cred.salt);
      if (!cred.passwordHash || !crypto.timingSafeEqual(Buffer.from(attemptHash, 'hex'), Buffer.from(cred.passwordHash, 'hex'))) {
        return { success: false, error: 'Invalid password. Password confirmation is required to disable 2FA.' };
      }
    }

    const prisma = getPrismaClient();
    if (prisma) {
      try {
        await prisma.twoFactorSetting.updateMany({
          where: { userId },
          data: {
            isEnabled: false,
            secret: null,
            pendingSecret: null,
            pendingExpiresAt: null,
            backupCodes: null,
          },
        });
      } catch (e) {
        console.warn('[AUTH] Error disabling 2FA in DB:', e);
      }
    }

    user.twoFactorEnabled = false;
    cred.twoFactorEnabled = false;
    cred.twoFactorSecret = undefined;
    cred.recoveryCodeHashes = undefined;
    user.updatedAt = new Date().toISOString();

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'security',
      action: '2FA_DISABLED',
      recordAffected: user.email,
      newValue: 'Two-Factor Authentication disabled on account after password confirmation',
      ipAddress: '103.21.144.12',
      severity: 'WARNING',
    });

    return { success: true };
  }

  // --- Session Management ---
  public createSession(
    user: PlatformUser,
    clientInfo: { ip: string; userAgent?: string }
  ): { token: string; sessionId: string } {
    const token = crypto.randomBytes(32).toString('hex');
    const sessionId = `sess-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    const policies = userStore.getSecurityPolicies();
    const timeoutMs = (policies.sessionTimeoutMinutes || 60) * 60000;
    const now = Date.now();

    const device = this.parseDevice(clientInfo.userAgent);
    const browser = this.parseBrowser(clientInfo.userAgent);

    const sessionRecord: SessionTokenRecord = {
      token,
      sessionId,
      userId: user.id,
      createdAt: now,
      lastActiveAt: now,
      expiresAt: now + timeoutMs,
      ipAddress: clientInfo.ip || '103.21.144.12',
      device,
      browser,
      location: 'India (Authorized IP)',
    };

    this.sessionTokens.set(token, sessionRecord);

    // Update PlatformUser's activeSessions array
    const activeSession: ActiveSession = {
      sessionId,
      ipAddress: sessionRecord.ipAddress,
      device: `${device} · ${browser}`,
      browser,
      location: sessionRecord.location,
      loginTime: 'Just now',
      lastActivity: 'Active now',
      isCurrent: true,
    };

    user.activeSessions = [activeSession, ...(user.activeSessions || []).slice(0, 4)];
    user.lastLogin = 'Just now';
    user.updatedAt = new Date().toISOString();

    return { token, sessionId };
  }

  public getUserByToken(token: string): PlatformUser | null {
    if (!token) return null;
    const session = this.sessionTokens.get(token);
    if (!session) return null;

    const now = Date.now();
    if (session.expiresAt < now) {
      this.sessionTokens.delete(token);
      return null;
    }

    // Refresh last active time
    session.lastActiveAt = now;
    const policies = userStore.getSecurityPolicies();
    session.expiresAt = now + (policies.sessionTimeoutMinutes || 60) * 60000;

    const user = userStore.getUserById(session.userId);
    return user ? this.sanitizeUser(user) : null;
  }

  public revokeSession(token: string): boolean {
    const session = this.sessionTokens.get(token);
    if (session) {
      const user = userStore.getUserById(session.userId);
      if (user) {
        user.activeSessions = (user.activeSessions || []).filter((s) => s.sessionId !== session.sessionId);
        auditStore.record({
          userId: user.id,
          userName: user.name,
          userRole: user.role,
          module: 'auth',
          action: 'SESSION_TERMINATED',
          recordAffected: user.email,
          newValue: `Session ${session.sessionId} terminated`,
          ipAddress: session.ipAddress,
          severity: 'INFO',
        });
      }
      this.sessionTokens.delete(token);
      return true;
    }
    return false;
  }

  public revokeAllUserSessions(userId: string, exceptToken?: string): number {
    let count = 0;
    for (const [t, s] of this.sessionTokens.entries()) {
      if (s.userId === userId && t !== exceptToken) {
        this.sessionTokens.delete(t);
        count++;
      }
    }
    const user = userStore.getUserById(userId);
    if (user) {
      user.activeSessions = exceptToken ? user.activeSessions.slice(0, 1) : [];
      user.updatedAt = new Date().toISOString();
    }
    return count;
  }

  // --- Change Password ---
  public changePassword(
    userId: string,
    currentPass: string,
    newPass: string,
    revokeOthers: boolean,
    currentToken?: string
  ): { success: boolean; error?: string } {
    const cred = this.credentials.get(userId);
    const user = userStore.getUserById(userId);
    if (!cred || !user) return { success: false, error: 'User credential record not found.' };

    // Verify current
    const currentHash = this.hashPassword(currentPass, cred.salt);
    if (!cred.passwordHash || !crypto.timingSafeEqual(Buffer.from(currentHash, 'hex'), Buffer.from(cred.passwordHash, 'hex'))) {
      return { success: false, error: 'Current password does not match our records.' };
    }

    // Validate new password strength
    if (newPass.length < 8) {
      return { success: false, error: 'New password must be at least 8 characters long.' };
    }
    if (!/[A-Z]/.test(newPass) || !/[0-9]/.test(newPass)) {
      return { success: false, error: 'New password must contain at least one uppercase letter and one number.' };
    }

    const newSalt = this.generateSalt();
    const newHash = this.hashPassword(newPass, newSalt);

    cred.passwordHash = newHash;
    cred.salt = newSalt;
    cred.lastPasswordChange = new Date().toISOString();
    cred.mustChangePasswordOnFirstLogin = false;
    user.updatedAt = new Date().toISOString();

    if (revokeOthers) {
      this.revokeAllUserSessions(userId, currentToken);
    }

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: 'PASSWORD_CHANGED',
      recordAffected: user.email,
      newValue: `Password securely updated. Other sessions revoked: ${revokeOthers}`,
      ipAddress: '103.21.144.12',
      severity: 'WARNING',
    });

    return { success: true };
  }

  // --- Forgot Password Token Generation & Reset (Hashed & Generic) ---
  public createPasswordResetToken(email: string): { success: boolean; message: string; devResetLink?: string } {
    const user = userStore.getUserByEmail(email);
    if (!user) {
      // Do not reveal email existence to prevent user enumeration
      return { success: true, message: 'If this email address is registered, password reset instructions have been sent.' };
    }

    const token = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const expiresAt = Date.now() + 15 * 60000; // 15 minutes validity (short-lived)

    this.resetTokens.set(tokenHash, {
      token: tokenHash,
      userId: user.id,
      email: user.email,
      expiresAt,
      used: false,
    });

    const prisma = getPrismaClient();
    if (prisma) {
      prisma.passwordResetToken.create({
        data: {
          id: `prt-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
          token: tokenHash,
          userId: user.id,
          email: user.email,
          expiresAt: new Date(expiresAt),
          used: false,
        },
      }).catch((err: any) => console.warn('[AUTH] Error persisting reset token hash:', err));
    }

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: 'PASSWORD_RESET_TOKEN_GENERATED',
      recordAffected: user.email,
      newValue: 'Single-use cryptographic SHA-256 hashed reset token issued with 15-minute expiration',
      ipAddress: '103.21.144.12',
      severity: 'WARNING',
    });

    const adminPath = (process.env.VITE_ADMIN_PATH || '/tori-ops-gateway').replace(/\/+$/, '');
    const resetLink = `${adminPath}/reset-password?token=${token}`;

    // Log securely server-side for development or testing
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[AUTH-DEV] Password reset link for ${email}: ${resetLink}`);
    }

    return {
      success: true,
      message: 'If this email address is registered, password reset instructions have been sent.',
      ...(process.env.NODE_ENV !== 'production' ? { devResetLink: resetLink } : {}),
    };
  }

  public async resetPasswordWithToken(token: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    if (!token || typeof token !== 'string') {
      return { success: false, error: 'Invalid reset token.' };
    }

    const tokenHash = crypto.createHash('sha256').update(token.trim()).digest('hex');
    let record = this.resetTokens.get(tokenHash);

    const prisma = getPrismaClient();
    if (!record && prisma) {
      try {
        const dbRecord = await prisma.passwordResetToken.findUnique({
          where: { token: tokenHash },
        });
        if (dbRecord) {
          record = {
            token: dbRecord.token,
            userId: dbRecord.userId,
            email: dbRecord.email,
            expiresAt: dbRecord.expiresAt.getTime(),
            used: dbRecord.used,
          };
        }
      } catch (err) {
        console.warn('[AUTH] Error fetching reset token from DB:', err);
      }
    }

    if (!record || record.used || record.expiresAt < Date.now()) {
      return { success: false, error: 'Password reset link is invalid or has expired. Please request a new one.' };
    }

    if (newPassword.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }
    if (!/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
      return { success: false, error: 'Password must contain at least one uppercase letter and one number.' };
    }

    const cred = this.credentials.get(record.userId);
    const user = userStore.getUserById(record.userId);
    if (!cred || !user) return { success: false, error: 'Account not found.' };

    const salt = this.generateSalt();
    const hash = this.hashPassword(newPassword, salt);

    cred.passwordHash = hash;
    cred.salt = salt;
    cred.lastPasswordChange = new Date().toISOString();
    cred.mustChangePasswordOnFirstLogin = false;
    cred.failedLoginAttempts = 0;
    cred.lockoutUntil = undefined;
    record.used = true;

    if (prisma) {
      try {
        await prisma.$transaction([
          prisma.user.update({
            where: { id: record.userId },
            data: {
              passwordHash: hash,
              salt,
              lastPasswordChange: new Date(),
              failedLoginAttempts: 0,
              lockoutUntil: null,
              mustChangePasswordOnFirstLogin: false,
            },
          }),
          prisma.passwordResetToken.updateMany({
            where: { token: tokenHash },
            data: { used: true, usedAt: new Date() },
          }),
        ]);
      } catch (err) {
        console.warn('[AUTH] Error updating password in PostgreSQL:', err);
      }
    }

    // Invalidate all existing sessions upon password reset (Phase 1.D)
    this.revokeAllUserSessions(record.userId);

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: 'PASSWORD_RESET_COMPLETED',
      recordAffected: user.email,
      newValue: 'Single-use hashed token consumed; all existing active sessions invalidated',
      ipAddress: '103.21.144.12',
      severity: 'CRITICAL',
    });

    return { success: true };
  }

  // --- User Invitation Token ---
  public createInvitationToken(userId: string): { token: string; inviteLink: string } {
    const user = userStore.getUserById(userId);
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 48 * 3600000; // 48 hours

    this.inviteTokens.set(token, {
      token,
      userId,
      email: user?.email || '',
      expiresAt,
      used: false,
    });

    const inviteLink = `/admin/activate?token=${token}`;
    return { token, inviteLink };
  }

  public activateAccountWithToken(token: string, password: string): { success: boolean; user?: PlatformUser; error?: string } {
    const record = this.inviteTokens.get(token);
    if (!record || record.used || record.expiresAt < Date.now()) {
      return { success: false, error: 'Activation link is invalid or has expired.' };
    }

    const user = userStore.getUserById(record.userId);
    if (!user) return { success: false, error: 'Account not found.' };

    const salt = this.generateSalt();
    const hash = this.hashPassword(password, salt);

    this.credentials.set(user.id, {
      userId: user.id,
      passwordHash: hash,
      salt,
      failedLoginAttempts: 0,
      lastPasswordChange: new Date().toISOString(),
      mustChangePasswordOnFirstLogin: false,
    });

    user.accountStatus = 'ACTIVE';
    record.used = true;

    auditStore.record({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      module: 'auth',
      action: 'ACCOUNT_ACTIVATED',
      recordAffected: user.email,
      newValue: 'User established permanent password through invitation link',
      ipAddress: '103.21.144.12',
      severity: 'INFO',
    });

    return { success: true, user: this.sanitizeUser(user) };
  }

  // --- Password Setting for Admin User Provisioning ---
  public setInitialPassword(userId: string, tempPassword?: string): { tempPassword?: string } {
    const salt = this.generateSalt();
    const pass = tempPassword || `Tori@${crypto.randomBytes(4).toString('hex')}`;
    const hash = this.hashPassword(pass, salt);

    this.credentials.set(userId, {
      userId,
      passwordHash: hash,
      salt,
      failedLoginAttempts: 0,
      mustChangePasswordOnFirstLogin: true,
      lastPasswordChange: new Date().toISOString(),
    });

    return { tempPassword: pass };
  }

  // --- Super Admin Direct Password Management & Reset ---
  public async adminResetUserPassword(
    userId: string,
    newPassword?: string,
    mustChangePassword: boolean = false,
    actor?: { id: string; name: string; role: string; email: string }
  ): Promise<{ success: boolean; newPassword?: string; message?: string; error?: string }> {
    const user = userStore.getUserById(userId);
    if (!user) return { success: false, error: 'User account not found.' };

    const salt = this.generateSalt();
    const pass = (newPassword && newPassword.trim()) || `Tori@${crypto.randomBytes(4).toString('hex')}!`;
    const hash = this.hashPassword(pass, salt);

    let cred = this.credentials.get(userId);
    if (!cred) {
      cred = {
        userId,
        passwordHash: hash,
        salt,
        failedLoginAttempts: 0,
        mustChangePasswordOnFirstLogin: mustChangePassword,
        lastPasswordChange: new Date().toISOString(),
      };
      this.credentials.set(userId, cred);
    } else {
      cred.passwordHash = hash;
      cred.salt = salt;
      cred.failedLoginAttempts = 0;
      cred.lockoutUntil = undefined;
      cred.mustChangePasswordOnFirstLogin = mustChangePassword;
      cred.lastPasswordChange = new Date().toISOString();
    }

    // Persist to PostgreSQL if connected
    const prisma = getPrismaClient();
    if (prisma) {
      try {
        await prisma.user.update({
          where: { id: userId },
          data: {
            passwordHash: hash,
            salt,
            failedLoginAttempts: 0,
            lockoutUntil: null,
            mustChangePasswordOnFirstLogin: mustChangePassword,
            lastPasswordChange: new Date(),
          },
        });
      } catch (err) {
        console.warn('[AUTH] Error updating password in PostgreSQL:', err);
      }
    }

    // Revoke any active sessions so old sessions cannot be hijacked
    this.revokeAllUserSessions(userId);

    auditStore.record({
      userId: actor?.id || 'usr-saif',
      userName: actor?.name || 'Mohammed Saif',
      userRole: (actor?.role as any) || 'SUPER_ADMIN',
      module: 'security',
      action: 'ADMIN_PASSWORD_RESET',
      recordAffected: user.email,
      newValue: `Super Admin reset password for ${user.name} (${user.email}). MustChangeOnFirstLogin=${mustChangePassword}`,
      ipAddress: '127.0.0.1',
      severity: 'WARNING',
    });

    return {
      success: true,
      newPassword: pass,
      message: `Password successfully updated for ${user.name}.`,
    };
  }

  // --- Super Admin Reissue Single-Use Recovery Codes ---
  public async adminReissueRecoveryCodes(
    userId: string,
    actor?: { id: string; name: string; role: string; email: string }
  ): Promise<{ success: boolean; recoveryCodes?: string[]; error?: string }> {
    const user = userStore.getUserById(userId);
    if (!user) return { success: false, error: 'User account not found.' };

    const freshCodes = generateRecoveryCodes(5); // Cryptographically random high-entropy recovery codes
    const hashedCodes = freshCodes.map(hashRecoveryCode);

    const cred = await this.loadUser2FASetting(userId);
    if (cred) {
      cred.recoveryCodeHashes = hashedCodes;
    }

    const prisma = getPrismaClient();
    if (prisma) {
      try {
        await prisma.twoFactorSetting.upsert({
          where: { userId },
          create: {
            userId,
            isEnabled: true,
            backupCodes: JSON.stringify(hashedCodes),
          },
          update: {
            backupCodes: JSON.stringify(hashedCodes),
          },
        });
      } catch (err) {
        console.warn('[AUTH] Error saving reissued recovery codes to DB:', err);
      }
    }

    auditStore.record({
      userId: actor?.id || 'usr-saif',
      userName: actor?.name || 'Mohammed Saif',
      userRole: (actor?.role as any) || 'SUPER_ADMIN',
      module: 'security',
      action: '2FA_RECOVERY_CODES_REISSUED',
      recordAffected: user.email,
      newValue: `Super Admin reissued 5 fresh backup recovery codes for ${user.name}`,
      ipAddress: '127.0.0.1',
      severity: 'WARNING',
    });

    return {
      success: true,
      recoveryCodes: freshCodes,
    };
  }

  // --- Super Admin Query User Credential & Recovery Codes Details ---
  public async getUserCredentialDetails(userId: string): Promise<{
    success: boolean;
    credential?: {
      userId: string;
      email: string;
      employeeId?: string;
      role: string;
      twoFactorEnabled: boolean;
      activeRecoveryCodesCount: number;
      failedLoginAttempts: number;
      accountStatus: string;
      mustChangePasswordOnFirstLogin: boolean;
      lastPasswordChange?: string;
    };
    error?: string;
  }> {
    const user = userStore.getUserById(userId);
    if (!user) return { success: false, error: 'User not found' };

    const cred = await this.loadUser2FASetting(userId);
    const activeHashes = cred?.recoveryCodeHashes || [];

    return {
      success: true,
      credential: {
        userId: user.id,
        email: user.email,
        employeeId: user.employeeId,
        role: user.role,
        twoFactorEnabled: Boolean(cred?.twoFactorEnabled),
        activeRecoveryCodesCount: activeHashes.length,
        failedLoginAttempts: cred?.failedLoginAttempts || 0,
        accountStatus: user.accountStatus,
        mustChangePasswordOnFirstLogin: Boolean(cred?.mustChangePasswordOnFirstLogin),
        lastPasswordChange: cred?.lastPasswordChange,
      },
    };
  }

  // Sanitize user: ensure no credential secrets or hashes are ever sent to client
  private sanitizeUser(user: PlatformUser): PlatformUser {
    const copy = { ...user };
    delete copy.twoFactorSecret;
    return copy;
  }

  private parseDevice(userAgent?: string): string {
    if (!userAgent) return 'Desktop Workstation';
    if (/iPhone/i.test(userAgent)) return 'iPhone (iOS)';
    if (/iPad/i.test(userAgent)) return 'iPad (iPadOS)';
    if (/Android/i.test(userAgent)) return 'Android Mobile';
    if (/Macintosh/i.test(userAgent)) return 'MacBook / macOS Workstation';
    if (/Windows/i.test(userAgent)) return 'Windows 11 Workstation';
    return 'Authorized Terminal';
  }

  private parseBrowser(userAgent?: string): string {
    if (!userAgent) return 'Secure Browser';
    if (/Chrome/i.test(userAgent)) return 'Google Chrome';
    if (/Safari/i.test(userAgent) && !/Chrome/i.test(userAgent)) return 'Safari';
    if (/Firefox/i.test(userAgent)) return 'Mozilla Firefox';
    if (/Edge/i.test(userAgent)) return 'Microsoft Edge';
    return 'Web Browser';
  }
}

export const authStore = new AuthStore();
