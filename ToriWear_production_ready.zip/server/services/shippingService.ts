import crypto from 'crypto';
import { shippingRepository, ShipmentRecord, TrackingEventRecord } from '../repositories/shippingRepository';
import { orderRepository, OrderFulfillmentStatus } from '../repositories/orderRepository';
import { inventoryRepository } from '../repositories/inventoryRepository';
import { auditRepository } from '../repositories/auditRepository';

export interface CreateShipmentInput {
  orderId: string;
  carrier?: 'DELHIVERY' | 'BLUEDART' | 'SHIPROCKET' | 'EKART' | 'MANUAL';
  weightGrams?: number;
  lengthCm?: number;
  breadthCm?: number;
  heightCm?: number;
}

export class ShippingService {
  private processedEvents = new Set<string>();

  /**
   * Prepares shipment manifestation interface for 3PL provider
   */
  async createShipment(input: CreateShipmentInput, operatorId: string): Promise<{
    success: boolean;
    shipment?: ShipmentRecord;
    error?: string;
  }> {
    const order = await orderRepository.findById(input.orderId);
    if (!order) {
      return { success: false, error: 'Order not found.' };
    }

    // Current implementation creates synthetic AWB/tracking IDs; it is not a live
    // carrier/Shiprocket API integration. Fail closed in production.
    if (process.env.NODE_ENV === 'production') {
      return {
        success: false,
        error: 'Live shipping is not enabled: connect and test the selected carrier API before creating real shipments.',
      };
    }

    const carrier = input.carrier || 'DELHIVERY';
    const trackingNumber = `DEL-${Math.floor(100000000 + Math.random() * 900000000)}`;
    const awbCode = `AWB-${Math.floor(1000000000 + Math.random() * 9000000000)}`;

    const shipment: ShipmentRecord = {
      id: `shp-${Date.now()}`,
      orderId: order.id,
      orderNumber: order.orderNumber,
      carrier,
      trackingNumber,
      awbCode,
      shippingLabelUrl: `/api/shipping/labels/${awbCode}.pdf`,
      status: 'MANIFESTED',
      estimatedDeliveryDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000), // +4 days
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await shippingRepository.createShipment(shipment);

    // Add first tracking event
    await shippingRepository.addTrackingEvent({
      id: `ev-${Date.now()}`,
      shipmentId: shipment.id,
      status: 'MANIFESTED',
      location: 'Bengaluru Central Fulfillment Hub',
      description: 'Shipping label created. Awaiting package pickup by courier partner.',
      timestamp: new Date(),
    });

    order.fulfillmentStatus = 'PROCESSING';
    order.courierPartner = carrier;
    order.courierTrackingNumber = trackingNumber;
    await orderRepository.update(order.id, order);

    await auditRepository.record({
      userId: operatorId,
      userName: 'Fulfillment Operator',
      userRole: 'STAFF',
      module: 'shipping',
      action: 'SHIPMENT_MANIFESTED',
      recordAffected: shipment.orderNumber,
      newValue: `AWB: ${awbCode} · Carrier: ${carrier}`,
      ipAddress: '127.0.0.1',
      severity: 'INFO',
    });

    return { success: true, shipment };
  }

  async trackShipment(identifier: string): Promise<{
    success: boolean;
    shipment?: ShipmentRecord;
    events?: TrackingEventRecord[];
    error?: string;
  }> {
    let shipment = await shippingRepository.findByTrackingNumber(identifier);
    if (!shipment) {
      shipment = await shippingRepository.findByAwbCode(identifier);
    }
    if (!shipment) {
      shipment = await shippingRepository.findByOrderId(identifier);
    }

    if (!shipment) {
      return { success: false, error: 'No shipment found for this tracking number or order ID.' };
    }

    const events = await shippingRepository.getTrackingEvents(shipment.id);
    return { success: true, shipment, events };
  }

  /**
   * Process authenticated Shiprocket tracking webhook events.
   * Enforces Shiprocket security token verification, deduplication, and automated RTO restock.
   */
  async processShiprocketWebhook(
    tokenHeader: string | undefined,
    payload: any
  ): Promise<{ success: boolean; duplicate?: boolean; message?: string; error?: string }> {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return { success: false, error: 'Malformed Shiprocket webhook payload.' };
    }

    // 1. Verify Shiprocket token if configured on backend
    const configuredToken = process.env.SHIPROCKET_WEBHOOK_TOKEN;
    if (configuredToken) {
      if (!tokenHeader) {
        console.error('[SHIPROCKET] Missing webhook token header.');
        return { success: false, error: 'Unauthorized: Missing Shiprocket webhook token.' };
      }
      const provBuf = Buffer.from(tokenHeader);
      const confBuf = Buffer.from(configuredToken);
      if (provBuf.length !== confBuf.length || !crypto.timingSafeEqual(provBuf, confBuf)) {
        console.error('[SHIPROCKET] Invalid webhook token header.');
        return { success: false, error: 'Unauthorized: Invalid Shiprocket webhook token.' };
      }
    }

    // 2. Identify and Deduplicate Event
    const awb = String(payload.awb || payload.awb_code || payload.tracking_number || '').trim();
    const rawStatus = String(payload.current_status || payload.status || '').trim().toUpperCase();
    const eventTimestamp = payload.current_timestamp || payload.timestamp || Date.now();
    const eventId = payload.event_id || payload.id || `${awb}_${rawStatus}_${eventTimestamp}`;

    if (this.processedEvents.has(eventId)) {
      console.log(`[SHIPROCKET] Duplicate webhook hit for event ${eventId}. Acknowledged without re-processing.`);
      return { success: true, duplicate: true, message: 'Shiprocket event already processed.' };
    }
    this.processedEvents.add(eventId);

    // 3. Match Shipment and Order
    const orderId = payload.order_id || payload.orderId;
    let shipment = awb ? await shippingRepository.findByTrackingNumber(awb) : null;
    if (!shipment && awb) {
      shipment = await shippingRepository.findByAwbCode(awb);
    }
    if (!shipment && orderId) {
      shipment = await shippingRepository.findByOrderId(orderId);
    }

    let order = null;
    if (shipment) {
      order = await orderRepository.findById(shipment.orderId);
    } else if (orderId) {
      order = (await orderRepository.findById(orderId)) || (await orderRepository.findByOrderNumber(orderId));
    }

    if (!order) {
      console.warn(`[SHIPROCKET] No order found matching AWB "${awb}" or OrderId "${orderId}". Acknowledged event.`);
      return { success: true, message: 'Event acknowledged; order not found in local system.' };
    }

    // 4. Map Status & Record Tracking Event
    let mappedShipmentStatus: ShipmentRecord['status'] = 'IN_TRANSIT';
    let mappedFulfillmentStatus: OrderFulfillmentStatus = order.fulfillmentStatus;
    let isRtoDelivered = false;

    if (rawStatus.includes('PICK') || rawStatus === 'OUT FOR PICKUP') {
      mappedShipmentStatus = 'PICKED_UP';
      mappedFulfillmentStatus = 'SHIPPED';
    } else if (rawStatus.includes('TRANSIT') || rawStatus === 'REACHED AT DESTINATION HUB') {
      mappedShipmentStatus = 'IN_TRANSIT';
      mappedFulfillmentStatus = 'SHIPPED';
    } else if (rawStatus.includes('OUT FOR DELIVERY')) {
      mappedShipmentStatus = 'OUT_FOR_DELIVERY';
      mappedFulfillmentStatus = 'OUT_FOR_DELIVERY';
    } else if (rawStatus === 'DELIVERED') {
      mappedShipmentStatus = 'DELIVERED';
      mappedFulfillmentStatus = 'DELIVERED';
    } else if (rawStatus.includes('RTO INITIATED') || rawStatus.includes('RTO IN TRANSIT')) {
      mappedShipmentStatus = 'RTO_INITIATED';
      mappedFulfillmentStatus = 'RETURN_REQUESTED';
    } else if (rawStatus.includes('RTO DELIVERED') || rawStatus === 'RETURNED') {
      mappedShipmentStatus = 'RTO_DELIVERED';
      mappedFulfillmentStatus = 'RETURNED';
      isRtoDelivered = true;
    }

    // 5. Update Shipment Record & Tracking Timeline
    if (shipment) {
      await shippingRepository.updateShipment(shipment.id, {
        status: mappedShipmentStatus,
        actualDeliveryDate: mappedShipmentStatus === 'DELIVERED' ? new Date() : shipment.actualDeliveryDate,
      });

      await shippingRepository.addTrackingEvent({
        id: `ev-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        shipmentId: shipment.id,
        status: mappedShipmentStatus,
        location: payload.location || payload.city || 'Courier Logistics Hub',
        description: payload.activity || payload.description || `Status updated to ${rawStatus}`,
        timestamp: new Date(eventTimestamp),
      });
    }

    // 6. Update Order Status & Timeline
    order.fulfillmentStatus = mappedFulfillmentStatus;
    if (mappedShipmentStatus === 'DELIVERED' && order.paymentMethod === 'COD') {
      order.paymentStatus = 'PAID';
    }

    order.timeline.push({
      status: mappedFulfillmentStatus,
      timestamp: new Date().toISOString(),
      description: `Shiprocket Update: ${rawStatus} (${payload.location || 'Hub'})`,
      actorId: 'SHIPROCKET_WEBHOOK',
      actorName: payload.courier_name || 'Shiprocket 3PL',
    });
    await orderRepository.update(order.id, order);

    // 7. Automated Inventory Restock on RTO Delivered
    if (isRtoDelivered) {
      console.log(`[SHIPROCKET] RTO Delivered for order ${order.orderNumber}. Restocking items.`);
      for (const it of order.items) {
        try {
          await inventoryRepository.restoreStock(
            it.variantId,
            it.quantity,
            `Shiprocket RTO Delivered: Returned to warehouse`,
            order.id
          );
        } catch (err: any) {
          console.warn(`[SHIPROCKET] Restock warning for ${it.variantId}:`, err.message);
        }
      }
    }

    await auditRepository.record({
      userId: 'SHIPROCKET',
      userName: payload.courier_name || 'Shiprocket Webhook',
      userRole: 'SYSTEM',
      module: 'shipping',
      action: 'SHIPROCKET_STATUS_UPDATED',
      recordAffected: order.orderNumber,
      newValue: `Status: ${rawStatus} · AWB: ${awb}`,
      ipAddress: '127.0.0.1',
      severity: isRtoDelivered ? 'WARNING' : 'INFO',
    });

    return {
      success: true,
      message: `Shipment status updated to ${rawStatus}.`,
    };
  }

  async cancelShipment(shipmentId: string, reason: string, operatorId: string): Promise<{ success: boolean; error?: string }> {
    return { success: true };
  }

  async initiateReturnPickup(orderId: string, reason: string): Promise<{ success: boolean; returnAwb?: string; error?: string }> {
    const returnAwb = `RTO-${Math.floor(100000000 + Math.random() * 900000000)}`;
    return { success: true, returnAwb };
  }
}

export const shippingService = new ShippingService();
