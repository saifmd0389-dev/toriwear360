import crypto from 'crypto';
import { paymentRepository, PaymentTransactionRecord, PaymentWebhookRecord } from '../repositories/paymentRepository';
import { orderRepository } from '../repositories/orderRepository';
import { inventoryRepository } from '../repositories/inventoryRepository';
import { couponRepository } from '../repositories/couponRepository';
import { financeRepository } from '../repositories/financeRepository';
import { auditRepository } from '../repositories/auditRepository';
import { withTransaction } from '../../database/transactions';

export interface CreatePaymentIntentInput {
  orderId: string;
  gateway?: 'RAZORPAY' | 'CASHFREE' | 'SIMULATED_SANDBOX';
  method: 'UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'NET_BANKING' | 'WALLET' | 'COD';
}

export interface VerifyPaymentInput {
  orderId: string;
  gatewayOrderId: string;
  gatewayPaymentId: string;
  gatewaySignature?: string;
  isSimulated?: boolean;
}

export interface RefundInput {
  orderId: string;
  paymentId?: string;
  amountPaise?: number;
  reason?: string;
}

export class PaymentService {
  private get razorpayAuthHeader(): string | null {
    const keyId = process.env.RAZORPAY_KEY_ID?.trim();
    const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim();
    if (!keyId || !keySecret) return null;
    if (keyId.includes('••••') || keySecret.includes('••••')) return null;
    return 'Basic ' + Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  }

  /**
   * Creates a genuine payment order via official Razorpay Orders API.
   * Never permits fake or random order IDs in production.
   */
  async createPaymentIntent(input: CreatePaymentIntentInput, ip: string): Promise<{
    success: boolean;
    transaction?: PaymentTransactionRecord;
    gatewayPayload?: any;
    error?: string;
  }> {
    const order = (await orderRepository.findById(input.orderId)) || (await orderRepository.findByOrderNumber(input.orderId));
    if (!order) {
      return { success: false, error: 'Order not found.' };
    }

    const isProduction = process.env.NODE_ENV === 'production';
    const authHeader = this.razorpayAuthHeader;
    const isRealGatewayConfigured = Boolean(authHeader);

    // Production guard: Prohibit unverified simulated payments in production
    if (isProduction && !isRealGatewayConfigured) {
      return {
        success: false,
        error: 'Payment gateway configuration required: Live Razorpay Key ID and Secret must be configured in environment settings.',
      };
    }

    const isSimulated = !isRealGatewayConfigured || (input.gateway === 'SIMULATED_SANDBOX' && !isProduction);
    const amountPaise = Math.round(order.total * 100);

    let gatewayOrderId = '';

    if (isRealGatewayConfigured) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);

        const res = await fetch('https://api.razorpay.com/v1/orders', {
          method: 'POST',
          headers: {
            'Authorization': authHeader!,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            amount: amountPaise,
            currency: 'INR',
            receipt: order.orderNumber,
            notes: {
              orderId: order.id,
              customerEmail: order.customerEmail,
              customerPhone: order.customerPhone,
            },
          }),
          signal: controller.signal,
        });
        clearTimeout(timeout);

        const json: any = await res.json().catch(() => ({}));
        if (!res.ok || !json?.id) {
          const errDetail = json?.error?.description || `Razorpay order creation returned HTTP ${res.status}`;
          return {
            success: false,
            error: `Payment Gateway Error: ${errDetail}`,
          };
        }

        gatewayOrderId = json.id;
      } catch (err: any) {
        return {
          success: false,
          error: `Network error contacting Razorpay Orders API: ${err.message}`,
        };
      }
    } else {
      // Development Sandbox fallback only
      gatewayOrderId = `dev_order_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    }

    const txId = `tx-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    const txRecord: PaymentTransactionRecord = {
      id: txId,
      orderId: order.id,
      orderNumber: order.orderNumber,
      gateway: isSimulated ? 'SIMULATED_SANDBOX' : 'RAZORPAY',
      gatewayOrderId,
      amount: order.total,
      currency: 'INR',
      status: 'INITIATED',
      method: input.method,
      isSimulated,
      signatureVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    await paymentRepository.createTransaction(txRecord);

    await auditRepository.record({
      userId: order.customerId || 'GUEST',
      userName: order.customerName,
      userRole: 'CUSTOMER',
      module: 'payments',
      action: 'PAYMENT_INTENT_CREATED',
      recordAffected: txRecord.orderNumber,
      newValue: `Mode: ${isSimulated ? 'DEVELOPMENT_SANDBOX' : 'LIVE_RAZORPAY_GATEWAY'} · Order: ${gatewayOrderId} · Amount: ₹${order.total}`,
      ipAddress: ip,
      severity: 'INFO',
    });

    return {
      success: true,
      transaction: txRecord,
      gatewayPayload: {
        keyId: process.env.RAZORPAY_KEY_ID || 'rzp_test_placeholder',
        amount: amountPaise,
        currency: 'INR',
        orderId: gatewayOrderId,
        mode: isSimulated ? 'DEMO_SIMULATED' : 'PRODUCTION_GATEWAY',
      },
    };
  }

  /**
   * Server-side payment verification.
   * Computes HMAC-SHA256 signature against Razorpay secret.
   * Synchronizes Order, Inventory, and Financial Ledger atomically and idempotently.
   */
  async verifyPayment(input: VerifyPaymentInput, ip: string): Promise<{ success: boolean; message?: string; error?: string }> {
    const order = (await orderRepository.findById(input.orderId)) || (await orderRepository.findByOrderNumber(input.orderId));
    if (!order) {
      return { success: false, error: 'Associated order not found.' };
    }

    let tx = await paymentRepository.findByOrderId(order.id);
    if (!tx && input.gatewayOrderId) {
      tx = await paymentRepository.findByGatewayOrderId(input.gatewayOrderId);
    }

    if (order.paymentStatus === 'PAID') {
      return {
        success: true,
        message: 'Payment already verified and order is currently marked PAID.',
      };
    }

    if (order.paymentStatus === 'REFUNDED') {
      return {
        success: false,
        error: 'Order has already been refunded. Cannot transition back to PAID.',
      };
    }

    const secret = process.env.RAZORPAY_KEY_SECRET?.trim();
    const isSimulated = tx?.isSimulated || input.isSimulated || !secret;

    if (process.env.NODE_ENV === 'production' && isSimulated) {
      return {
        success: false,
        error: 'Simulated payment verification is strictly prohibited in production. Live gateway verification required.',
      };
    }

    if (!isSimulated) {
      if (!secret) {
        return { success: false, error: 'Server payment secret not configured for verification.' };
      }

      if (!input.gatewaySignature) {
        return { success: false, error: 'Missing gateway signature for payment verification.' };
      }

      const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(`${input.gatewayOrderId}|${input.gatewayPaymentId}`)
        .digest('hex');

      const isSignatureValid = crypto.timingSafeEqual(
        Buffer.from(expectedSignature),
        Buffer.from(input.gatewaySignature)
      );

      if (!isSignatureValid) {
        if (tx) {
          tx.status = 'FAILED';
          tx.failureReason = 'Cryptographic signature mismatch.';
          await paymentRepository.updateTransaction(tx.id, tx);
        }

        await auditRepository.record({
          userId: 'SECURITY',
          userName: 'PaymentGateway',
          userRole: 'SYSTEM',
          module: 'payments',
          action: 'PAYMENT_SIGNATURE_MISMATCH',
          recordAffected: order.orderNumber,
          ipAddress: ip,
          severity: 'CRITICAL',
        });

        return { success: false, error: 'Payment verification failed: Cryptographic signature mismatch.' };
      }
    }

    // Atomic transaction for payment capture, stock commit, and finance recording
    await withTransaction(async () => {
      if (tx) {
        tx.status = 'CAPTURED';
        tx.gatewayPaymentId = input.gatewayPaymentId || `pay_${Date.now()}`;
        tx.signatureVerified = true;
        tx.updatedAt = new Date();
        await paymentRepository.updateTransaction(tx.id, tx);
      }

      order.paymentStatus = 'PAID';
      order.fulfillmentStatus = 'CONFIRMED';
      order.timeline.push({
        status: 'PAID',
        timestamp: new Date().toISOString(),
        description: `Payment confirmed (${input.gatewayPaymentId || 'Verified'})`,
        actorId: 'PAYMENT_SERVICE',
        actorName: isSimulated ? 'Verified Development Simulator' : 'Razorpay Gateway',
      });
      await orderRepository.update(order.id, order);

      // Commit stock reservation permanently
      for (const it of order.items) {
        try {
          await inventoryRepository.commitReservation(it.variantId, it.quantity, order.id);
        } catch (err: any) {
          console.warn(`[PaymentService] Stock commit warning for ${it.variantId}:`, err.message);
        }
      }

      // Record in Financial Ledger
      this.recordOrderPaymentFinance(order);
    });

    return {
      success: true,
      message: 'Payment verified successfully and order transitioned to PAID.',
    };
  }

  /**
   * Process refund through official Razorpay Refund API
   */
  async processRefund(input: RefundInput, ip: string): Promise<{ success: boolean; refundId?: string; error?: string }> {
    const order = (await orderRepository.findById(input.orderId)) || (await orderRepository.findByOrderNumber(input.orderId));
    if (!order) {
      return { success: false, error: 'Order not found.' };
    }

    const tx = await paymentRepository.findByOrderId(order.id);
    const paymentId = input.paymentId || tx?.gatewayPaymentId;

    if (!paymentId) {
      return { success: false, error: 'Cannot process refund: No payment transaction ID associated with this order.' };
    }

    const authHeader = this.razorpayAuthHeader;
    const isRealGateway = Boolean(authHeader && !tx?.isSimulated);

    let refundId = '';

    if (isRealGateway) {
      try {
        const payload: any = {
          notes: {
            orderId: order.id,
            reason: input.reason || 'Customer requested return/cancellation',
          },
        };
        if (input.amountPaise) payload.amount = input.amountPaise;

        const res = await fetch(`https://api.razorpay.com/v1/payments/${paymentId}/refund`, {
          method: 'POST',
          headers: {
            'Authorization': authHeader!,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        });

        const json: any = await res.json().catch(() => ({}));
        if (!res.ok || !json?.id) {
          return {
            success: false,
            error: json?.error?.description || `Razorpay refund returned HTTP ${res.status}`,
          };
        }

        refundId = json.id;
      } catch (err: any) {
        return {
          success: false,
          error: `Network error contacting Razorpay refund endpoint: ${err.message}`,
        };
      }
    } else {
      if (process.env.NODE_ENV === 'production') {
        return { success: false, error: 'Real gateway credentials required to execute production refund.' };
      }
      refundId = `dev_rfnd_${Date.now()}`;
    }

    // Atomic update of transaction and order status
    if (tx) {
      tx.status = 'REFUNDED';
      tx.updatedAt = new Date();
      await paymentRepository.updateTransaction(tx.id, tx);
    }

    order.paymentStatus = 'REFUNDED';
    order.timeline.push({
      status: 'REFUNDED',
      timestamp: new Date().toISOString(),
      description: `Refund processed. ID: ${refundId}. Reason: ${input.reason || 'Requested'}`,
      actorId: 'PAYMENT_SERVICE',
      actorName: 'Razorpay Gateway',
    });
    await orderRepository.update(order.id, order);

    await auditRepository.record({
      userId: 'SYSTEM',
      userName: 'PaymentService',
      userRole: 'SYSTEM',
      module: 'payments',
      action: 'PAYMENT_REFUND_PROCESSED',
      recordAffected: order.orderNumber,
      newValue: `Refund ID: ${refundId} · Order: ${order.orderNumber}`,
      ipAddress: ip,
      severity: 'WARNING',
    });

    return { success: true, refundId };
  }

  /**
   * Process incoming webhook events from payment provider with signature verification and idempotency
   */
  async processWebhook(
    gateway: string,
    signature: string,
    payload: any,
    rawBody?: string
  ): Promise<{ success: boolean; duplicate?: boolean; error?: string; message?: string }> {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return { success: false, error: 'Malformed webhook payload.' };
    }

    const eventId =
      payload?.event_id ||
      payload?.id ||
      payload?.eventId ||
      `evt_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

    const eventType = payload?.event || payload?.type || 'payment.captured';

    // 1. Idempotency Check: Reject duplicate webhook processing
    const existingWebhook = await paymentRepository.findWebhookByEventId(eventId);
    if (existingWebhook) {
      return { success: true, duplicate: true, message: 'Webhook already processed.' };
    }

    // 2. Webhook Signature Verification
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (webhookSecret && rawBody) {
      const expectedSignature = crypto
        .createHmac('sha256', webhookSecret)
        .update(rawBody)
        .digest('hex');

      const isValid = crypto.timingSafeEqual(
        Buffer.from(expectedSignature),
        Buffer.from(signature || '')
      );

      if (!isValid) {
        return { success: false, error: 'Invalid webhook cryptographic signature.' };
      }
    }

    const paymentEntity = payload?.payload?.payment?.entity;
    const orderNumber = paymentEntity?.notes?.orderNumber || paymentEntity?.description;

    let order = orderNumber ? await orderRepository.findByOrderNumber(orderNumber) : null;
    if (!order && paymentEntity?.order_id) {
      const tx = await paymentRepository.findByGatewayOrderId(paymentEntity.order_id);
      if (tx) {
        order = await orderRepository.findById(tx.orderId);
      }
    }

    if (eventType === 'payment.captured' || eventType === 'order.paid') {
      if (order && order.paymentStatus !== 'PAID') {
        await withTransaction(async () => {
          order.paymentStatus = 'PAID';
          order.fulfillmentStatus = 'CONFIRMED';
          order.timeline.push({
            status: 'PAID',
            timestamp: new Date().toISOString(),
            description: `Payment captured via Webhook: ${paymentEntity?.id || 'Confirmed'}`,
            actorId: 'GATEWAY_WEBHOOK',
            actorName: gateway || 'Razorpay Webhook',
          });
          await orderRepository.update(order.id, order);

          const tx = await paymentRepository.findByOrderId(order.id);
          if (tx) {
            tx.status = 'CAPTURED';
            tx.gatewayPaymentId = paymentEntity?.id;
            tx.signatureVerified = true;
            await paymentRepository.updateTransaction(tx.id, tx);
          }

          for (const it of order.items) {
            try {
              await inventoryRepository.commitReservation(it.variantId, it.quantity, order.id);
            } catch (err: any) {
              console.warn(`[PaymentWebhook] Commit reservation warning:`, err.message);
            }
          }

          if (order.discountCode) {
            await couponRepository.incrementUsage(order.discountCode);
          }

          this.recordOrderPaymentFinance(order);
        });
      }
    } else if (eventType === 'payment.failed') {
      if (order && order.paymentStatus !== 'PAID' && order.paymentStatus !== 'REFUNDED') {
        order.paymentStatus = 'FAILED';
        order.timeline.push({
          status: 'FAILED',
          timestamp: new Date().toISOString(),
          description: `Payment failed via Webhook: ${paymentEntity?.error_description || 'Declined'}`,
          actorId: 'GATEWAY_WEBHOOK',
          actorName: gateway || 'Razorpay Webhook',
        });
        await orderRepository.update(order.id, order);

        const tx = await paymentRepository.findByOrderId(order.id);
        if (tx) {
          tx.status = 'FAILED';
          tx.failureReason = paymentEntity?.error_description || 'Payment failed';
          await paymentRepository.updateTransaction(tx.id, tx);
        }

        for (const it of order.items) {
          try {
            await inventoryRepository.releaseReservation(it.variantId, it.quantity, order.id, 'Payment failed via webhook');
          } catch {}
        }
      }
    }

    // 5. Save Webhook record
    const webhookRecord: PaymentWebhookRecord = {
      id: `wh-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      gateway: gateway || 'RAZORPAY',
      eventId,
      eventType,
      payload,
      processed: true,
      receivedAt: new Date(),
    };
    await paymentRepository.logWebhook(webhookRecord);

    return { success: true, message: `Webhook event "${eventType}" processed successfully.` };
  }

  private recordOrderPaymentFinance(order: any): void {
    try {
      const primaryAccount =
        financeRepository.getAccounts().find((a) => a.type === 'BANK' && a.isActive) ||
        financeRepository.getAccounts()[0];

      if (primaryAccount) {
        financeRepository.createTransaction(
          {
            transactionNumber: `TXN-ORD-${order.orderNumber.replace(/[^a-zA-Z0-9]/g, '')}`,
            date: new Date().toISOString().split('T')[0],
            description: `Customer Order Revenue - ${order.orderNumber}`,
            type: 'INCOME',
            category: 'Sales Revenue',
            amount: order.total,
            paymentAccountId: primaryAccount.id,
            orderId: order.id,
            referenceId: `ORDER_PAY_${order.id}`,
            status: 'APPROVED',
            notes: `Order ${order.orderNumber} placed by ${order.customerName}`,
          },
          'PAYMENT_SERVICE'
        );
      }
    } catch (err) {
      console.warn('[PaymentService] Finance recording warning:', err);
    }
  }
}

export const paymentService = new PaymentService();
