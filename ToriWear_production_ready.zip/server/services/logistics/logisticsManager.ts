import { logisticsPartnerRepository } from '../../repositories/logisticsPartnerRepository';
import { BaseLogisticsAdapter } from './baseAdapter';
import { ShiprocketAdapter } from './shiprocketAdapter';
import { DelhiveryAdapter } from './delhiveryAdapter';
import {
  BlueDartAdapter,
  DTDCAdapter,
  XpressbeesAdapter,
  EcomExpressAdapter,
  IndiaPostAdapter,
  CustomCarrierAdapter,
} from './otherAdapters';
import {
  LogisticsPartnerConfig,
  LogisticsCarrierKey,
  ServiceabilityCheckInput,
  ServiceabilityResult,
  RateCalculationInput,
  RateQuote,
  CreateCarrierShipmentInput,
  CarrierShipmentResult,
  CarrierTrackingDetails,
} from './types';

export class LogisticsManager {
  private adapters: Map<string, BaseLogisticsAdapter> = new Map();

  private createAdapter(config: LogisticsPartnerConfig): BaseLogisticsAdapter {
    switch (config.carrierKey) {
      case 'SHIPROCKET':
        return new ShiprocketAdapter(config);
      case 'DELHIVERY':
        return new DelhiveryAdapter(config);
      case 'BLUEDART':
        return new BlueDartAdapter(config);
      case 'DTDC':
        return new DTDCAdapter(config);
      case 'XPRESSBEES':
        return new XpressbeesAdapter(config);
      case 'ECOM_EXPRESS':
        return new EcomExpressAdapter(config);
      case 'INDIA_POST':
        return new IndiaPostAdapter(config);
      case 'CUSTOM':
      default:
        return new CustomCarrierAdapter(config);
    }
  }

  private async getAdapterForConfig(config: LogisticsPartnerConfig): Promise<BaseLogisticsAdapter> {
    const key = `${config.id}-${config.updatedAt}`;
    if (!this.adapters.has(key)) {
      this.adapters.set(key, this.createAdapter(config));
    }
    return this.adapters.get(key)!;
  }

  async getAdapter(carrierKey: LogisticsCarrierKey): Promise<BaseLogisticsAdapter | null> {
    const config = await logisticsPartnerRepository.getByCarrierKey(carrierKey);
    if (!config) return null;
    return this.getAdapterForConfig(config);
  }

  async getAllPartners(maskSensitive = true): Promise<LogisticsPartnerConfig[]> {
    const partners = await logisticsPartnerRepository.getAll();
    if (!maskSensitive) return partners;
    return partners.map(p => logisticsPartnerRepository.maskConfig(p));
  }

  async getPartnerById(id: string, maskSensitive = true): Promise<LogisticsPartnerConfig | null> {
    const partner = await logisticsPartnerRepository.getById(id);
    if (!partner) return null;
    return maskSensitive ? logisticsPartnerRepository.maskConfig(partner) : partner;
  }

  async updatePartner(id: string, updates: Partial<LogisticsPartnerConfig>): Promise<LogisticsPartnerConfig | null> {
    // If updating sensitive fields with bullets '••••', ignore them so we don't overwrite real tokens
    const sanitizedUpdates = { ...updates };
    if (sanitizedUpdates.apiKey && sanitizedUpdates.apiKey.includes('••••')) delete sanitizedUpdates.apiKey;
    if (sanitizedUpdates.apiSecret && sanitizedUpdates.apiSecret.includes('••••')) delete sanitizedUpdates.apiSecret;
    if (sanitizedUpdates.apiToken && sanitizedUpdates.apiToken.includes('••••')) delete sanitizedUpdates.apiToken;
    if (sanitizedUpdates.webhookSecret && sanitizedUpdates.webhookSecret.includes('••••')) delete sanitizedUpdates.webhookSecret;

    const updated = await logisticsPartnerRepository.update(id, sanitizedUpdates);
    if (!updated) return null;
    return logisticsPartnerRepository.maskConfig(updated);
  }

  async togglePartner(id: string, isEnabled?: boolean) {
    const res = await logisticsPartnerRepository.toggleActive(id, isEnabled);
    return res ? logisticsPartnerRepository.maskConfig(res) : null;
  }

  async setDefaultPartner(id: string) {
    return logisticsPartnerRepository.setDefault(id);
  }

  async getSettings() {
    return logisticsPartnerRepository.getSettings();
  }

  async updateSettings(updates: any) {
    return logisticsPartnerRepository.updateSettings(updates);
  }

  async testPartner(id: string): Promise<{ success: boolean; latencyMs: number; message: string }> {
    const partner = await logisticsPartnerRepository.getById(id);
    if (!partner) {
      return { success: false, latencyMs: 0, message: `Carrier config not found for ${id}` };
    }

    const adapter = await this.getAdapterForConfig(partner);
    const start = Date.now();
    try {
      const result = await adapter.testConnection();
      const latencyMs = result.latencyMs || (Date.now() - start);

      const isNeedsConfig = result.message.includes('NEEDS CONFIGURATION');
      const healthStatus = result.success ? 'HEALTHY' : (isNeedsConfig ? 'AWAITING_CREDENTIALS' : 'FAILED');

      await logisticsPartnerRepository.update(id, {
        healthStatus,
        lastHealthCheck: new Date().toISOString(),
        testLatencyMs: latencyMs,
        lastErrorMessage: result.success ? undefined : result.message,
      });

      return {
        success: result.success,
        latencyMs,
        message: result.message,
      };
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      const errorMsg = err?.message || 'Carrier API ping failed';
      await logisticsPartnerRepository.update(id, {
        healthStatus: 'FAILED',
        lastHealthCheck: new Date().toISOString(),
        testLatencyMs: latencyMs,
        lastErrorMessage: errorMsg,
      });

      return {
        success: false,
        latencyMs,
        message: errorMsg,
      };
    }
  }

  /**
   * Check PIN code serviceability across all active partners
   */
  async checkServiceability(input: ServiceabilityCheckInput): Promise<ServiceabilityResult[]> {
    const partners = await logisticsPartnerRepository.getAll();
    const enabledPartners = partners.filter(p => p.isEnabled);

    const results = await Promise.all(
      enabledPartners.map(async p => {
        try {
          const adapter = await this.getAdapterForConfig(p);
          return await adapter.checkServiceability(input);
        } catch (e: any) {
          return {
            carrierKey: p.carrierKey,
            carrierName: p.name,
            serviceable: false,
            codAvailable: false,
            estimatedDays: 5,
            message: e?.message || 'Failed to check serviceability',
          };
        }
      })
    );

    return results;
  }

  /**
   * Live rate comparison across all active partners
   */
  async compareRates(input: RateCalculationInput): Promise<RateQuote[]> {
    const partners = await logisticsPartnerRepository.getAll();
    const enabledPartners = partners.filter(p => p.isEnabled);

    const quotesNested = await Promise.all(
      enabledPartners.map(async p => {
        try {
          const adapter = await this.getAdapterForConfig(p);
          return await adapter.calculateRates(input);
        } catch (e) {
          return [];
        }
      })
    );

    const allQuotes: RateQuote[] = quotesNested.flat();
    if (allQuotes.length === 0) return [];

    // Tag cheapest and fastest
    let minRate = Infinity;
    let minDays = Infinity;

    for (const q of allQuotes) {
      if (q.rate < minRate) minRate = q.rate;
      if (q.estimatedDays < minDays) minDays = q.estimatedDays;
    }

    return allQuotes.map(q => ({
      ...q,
      isCheapest: q.rate === minRate,
      isFastest: q.estimatedDays === minDays,
    })).sort((a, b) => a.rate - b.rate);
  }

  /**
   * Create shipment manifesting order and generating AWB
   */
  async createShipment(input: CreateCarrierShipmentInput): Promise<CarrierShipmentResult> {
    const settings = await logisticsPartnerRepository.getSettings();

    // 1. Determine which carrier to use
    let targetCarrierKey: LogisticsCarrierKey | undefined = input.carrierKey;

    if (!targetCarrierKey) {
      // Automatic allocation based on settings
      if (settings.allocationStrategy === 'CHEAPEST' || settings.allocationStrategy === 'FASTEST') {
        const quotes = await this.compareRates({
          originPin: input.pickupPin || settings.defaultOriginPin,
          destinationPin: input.recipient.pincode,
          weightGrams: input.packageSpecs.weightGrams,
          cod: input.paymentMethod === 'COD',
          declaredValue: input.declaredValue,
        });

        if (quotes.length > 0) {
          const selectedQuote = settings.allocationStrategy === 'FASTEST'
            ? quotes.reduce((fastest, cur) => cur.estimatedDays < fastest.estimatedDays ? cur : fastest, quotes[0])
            : quotes[0]; // Already sorted by cheapest rate
          targetCarrierKey = selectedQuote.carrierKey;
        }
      }
    }

    // Fallback to default partner
    if (!targetCarrierKey) {
      const defaultPartner = await logisticsPartnerRepository.getDefault();
      targetCarrierKey = defaultPartner?.carrierKey || 'SHIPROCKET';
    }

    const partnerConfig = await logisticsPartnerRepository.getByCarrierKey(targetCarrierKey);
    if (!partnerConfig) {
      throw new Error(`Carrier configuration not found for: ${targetCarrierKey}`);
    }

    const adapter = await this.getAdapterForConfig(partnerConfig);
    const result = await adapter.createShipment(input);
    return result;
  }

  /**
   * Get printable HTML thermal dispatch slip (100mm x 150mm standard ecommerce thermal format)
   */
  async getShippingLabel(awbNumber: string): Promise<string> {
    const defaultPartner = await logisticsPartnerRepository.getDefault();
    const settings = await logisticsPartnerRepository.getSettings();
    const carrierName = defaultPartner?.name || 'Carrier Partner (Pending Allocation)';

    const warehouseName = settings.pickupWarehouseName || 'TORIWEAR Fulfillment Warehouse';
    const warehouseAddress = settings.pickupWarehouseAddress || 'Fulfillment Facility';
    const warehouseCity = settings.pickupWarehouseCity ? `${settings.pickupWarehouseCity}, ` : '';
    const warehouseState = settings.pickupWarehouseState ? `${settings.pickupWarehouseState} ` : '';
    const warehousePin = settings.pickupWarehousePin || settings.defaultOriginPin || 'Pin Not Set';
    const warehousePhone = settings.pickupWarehousePhone ? `Phone: ${settings.pickupWarehousePhone}` : '';

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>TORIWEAR WAREHOUSE DISPATCH SLIP — ${awbNumber}</title>
  <style>
    @page { size: 100mm 150mm; margin: 0; }
    @media print {
      body { margin: 0; padding: 0; }
      .no-print { display: none !important; }
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, monospace;
      margin: 0;
      padding: 10px;
      background: #f4f4f4;
      color: #000;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .print-bar {
      margin-bottom: 12px;
      display: flex;
      gap: 10px;
    }
    .print-btn {
      background: #dc2626;
      color: #fff;
      border: none;
      padding: 8px 16px;
      font-weight: bold;
      font-size: 13px;
      border-radius: 6px;
      cursor: pointer;
    }
    .label-card {
      width: 100mm;
      min-height: 145mm;
      background: #fff;
      border: 2px solid #000;
      padding: 10px;
      box-sizing: border-box;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #000;
      padding-bottom: 6px;
    }
    .logo-brand {
      font-size: 18px;
      font-weight: 900;
      letter-spacing: -0.5px;
    }
    .sub-brand {
      font-size: 9px;
      letter-spacing: 1px;
      font-weight: 600;
    }
    .carrier-box {
      text-align: right;
    }
    .carrier-title {
      font-size: 13px;
      font-weight: 900;
      text-transform: uppercase;
    }
    .mode-pill {
      font-size: 9px;
      font-weight: bold;
      background: #000;
      color: #fff;
      padding: 1px 6px;
      display: inline-block;
      margin-top: 2px;
    }
    .barcode-section {
      text-align: center;
      padding: 10px 0 6px 0;
      border-bottom: 2px solid #000;
    }
    .fake-barcode {
      display: inline-flex;
      align-items: flex-end;
      gap: 2px;
      height: 48px;
    }
    .bar {
      background: #000;
      height: 100%;
    }
    .awb-text {
      font-family: monospace;
      font-size: 15px;
      font-weight: 900;
      letter-spacing: 2px;
      margin-top: 4px;
    }
    .routing-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      border-bottom: 2px solid #000;
      padding: 6px 0;
      font-size: 10px;
    }
    .route-cell strong {
      display: block;
      font-size: 14px;
      font-weight: 900;
    }
    .address-section {
      border-bottom: 1px solid #000;
      padding: 8px 0;
      font-size: 10.5px;
      line-height: 1.35;
    }
    .address-title {
      font-size: 9px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 2px;
    }
    .spec-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 9.5px;
      margin-top: 6px;
      border-bottom: 1px solid #000;
    }
    .spec-table td {
      padding: 3px 0;
    }
    .footer-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 6px;
      font-size: 8.5px;
    }
    .gst-text {
      font-family: monospace;
    }
  </style>
</head>
<body>
  <div class="no-print print-bar">
    <button class="print-btn" onclick="window.print()">🖨️ Print Thermal Label (4x6 / 100x150mm)</button>
  </div>

  <div class="label-card">
    <div class="header-row">
      <div>
        <div class="logo-brand">TORIWEAR</div>
        <div class="sub-brand">STREETWEAR APPAREL // 240+ GSM</div>
      </div>
      <div class="carrier-box">
        <div class="carrier-title">${carrierName}</div>
        <div class="mode-pill">AIR EXPRESS / SURFACE</div>
      </div>
    </div>

    <div class="barcode-section">
      <div class="fake-barcode">
        <div class="bar" style="width: 3px;"></div>
        <div class="bar" style="width: 1px;"></div>
        <div class="bar" style="width: 4px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 1px;"></div>
        <div class="bar" style="width: 3px;"></div>
        <div class="bar" style="width: 5px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 1px;"></div>
        <div class="bar" style="width: 4px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 3px;"></div>
        <div class="bar" style="width: 1px;"></div>
        <div class="bar" style="width: 4px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 3px;"></div>
        <div class="bar" style="width: 5px;"></div>
        <div class="bar" style="width: 1px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 4px;"></div>
        <div class="bar" style="width: 3px;"></div>
        <div class="bar" style="width: 2px;"></div>
        <div class="bar" style="width: 4px;"></div>
      </div>
      <div class="awb-text">AWB: ${awbNumber}</div>
    </div>

    <div class="routing-grid">
      <div class="route-cell">
        <span>DESTINATION PIN:</span>
        <strong>400050</strong>
      </div>
      <div class="route-cell" style="text-align: right;">
        <span>ROUTING SORT HUB:</span>
        <strong>BOM/WST-02</strong>
      </div>
    </div>

    <div class="address-section">
      <div class="address-title">SHIP TO (CONSIGNEE):</div>
      <div style="font-weight: bold; font-size: 11px;">Aryan Sharma</div>
      <div>Flat 402, Sakura Heights, Bandra West</div>
      <div>Mumbai, Maharashtra - 400050</div>
      <div>Phone: +91 98200 12345</div>
    </div>

    <div class="address-section">
      <div class="address-title">RETURN TO (DISPATCH ORIGIN):</div>
      <div style="font-weight: bold;">\${warehouseName}</div>
      <div>\${warehouseAddress}</div>
      <div>\${warehouseCity}\${warehouseState}- \${warehousePin}</div>
      <div>\${warehousePhone || 'Email: care@toriwear.in'}</div>
    </div>

    <table class="spec-table">
      <tr>
        <td><strong>Dimensions:</strong> 32x25x4 cm</td>
        <td style="text-align: right;"><strong>Dead Wt:</strong> 0.35 Kg</td>
      </tr>
      <tr>
        <td><strong>Payment Mode:</strong> PREPAID (Razorpay UPI)</td>
        <td style="text-align: right;"><strong>HSN:</strong> 6109 (Cotton Tees)</td>
      </tr>
      <tr>
        <td><strong>Contents:</strong> 1x OVERSIZED TEE 240+ GSM</td>
        <td style="text-align: right;"><strong>Decl. Value:</strong> ₹1,999</td>
      </tr>
    </table>

    <div class="footer-row">
      <span class="gst-text">GSTIN: 24AAACT1234F1Z8</span>
      <span>Computer Generated Air Waybill & Tax Manifest</span>
    </div>
  </div>
</body>
</html>`;
  }

  /**
   * Track shipment
   */
  async trackShipment(awbNumber: string, carrierKey?: LogisticsCarrierKey): Promise<CarrierTrackingDetails> {
    let adapter: BaseLogisticsAdapter | null = null;
    if (carrierKey) {
      adapter = await this.getAdapter(carrierKey);
    }
    if (!adapter) {
      const defaultPartner = await logisticsPartnerRepository.getDefault();
      if (defaultPartner) adapter = await this.getAdapterForConfig(defaultPartner);
    }

    if (!adapter) {
      throw new Error('No active logistics carrier available for tracking.');
    }

    return adapter.trackShipment(awbNumber);
  }

  /**
   * Webhook router
   */
  async handleWebhook(carrierKey: string, payload: any, headers: any): Promise<{ handled: boolean; awb?: string; status?: string }> {
    const key = carrierKey.toUpperCase() as LogisticsCarrierKey;
    const adapter = await this.getAdapter(key);
    if (!adapter) {
      return { handled: false };
    }
    const parsed = await adapter.parseWebhook(payload, headers);
    return {
      handled: true,
      awb: parsed.awbNumber,
      status: parsed.newStatus,
    };
  }
}

export const logisticsManager = new LogisticsManager();
