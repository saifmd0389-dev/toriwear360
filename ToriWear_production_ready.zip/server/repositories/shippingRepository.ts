export interface ShipmentRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  carrier: 'DELHIVERY' | 'BLUEDART' | 'SHIPROCKET' | 'EKART' | 'MANUAL';
  trackingNumber: string;
  awbCode: string;
  shippingLabelUrl?: string;
  status: 'MANIFESTED' | 'PICKED_UP' | 'IN_TRANSIT' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'RTO_INITIATED' | 'RTO_DELIVERED';
  estimatedDeliveryDate?: Date;
  actualDeliveryDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface TrackingEventRecord {
  id: string;
  shipmentId: string;
  status: string;
  location: string;
  description: string;
  timestamp: Date;
}

export class ShippingRepository {
  private shipments = new Map<string, ShipmentRecord>();
  private trackingEvents = new Map<string, TrackingEventRecord[]>();

  async createShipment(shipment: ShipmentRecord): Promise<ShipmentRecord> {
    this.shipments.set(shipment.id, shipment);
    return shipment;
  }

  async findByOrderId(orderId: string): Promise<ShipmentRecord | null> {
    for (const sh of this.shipments.values()) {
      if (sh.orderId === orderId) return sh;
    }
    return null;
  }

  async findByTrackingNumber(trackingNumber: string): Promise<ShipmentRecord | null> {
    for (const sh of this.shipments.values()) {
      if (sh.trackingNumber.toUpperCase() === trackingNumber.toUpperCase()) return sh;
    }
    return null;
  }

  async findByAwbCode(awbCode: string): Promise<ShipmentRecord | null> {
    for (const sh of this.shipments.values()) {
      if (sh.awbCode.toUpperCase() === awbCode.toUpperCase()) return sh;
    }
    return null;
  }

  async updateShipment(id: string, updates: Partial<ShipmentRecord>): Promise<ShipmentRecord | null> {
    const existing = this.shipments.get(id);
    if (!existing) return null;
    const updated = { ...existing, ...updates, updatedAt: new Date() };
    this.shipments.set(id, updated);
    return updated;
  }

  async addTrackingEvent(event: TrackingEventRecord): Promise<void> {
    const list = this.trackingEvents.get(event.shipmentId) || [];
    list.push(event);
    this.trackingEvents.set(event.shipmentId, list);
  }

  async getTrackingEvents(shipmentId: string): Promise<TrackingEventRecord[]> {
    return this.trackingEvents.get(shipmentId) || [];
  }
}

export const shippingRepository = new ShippingRepository();
