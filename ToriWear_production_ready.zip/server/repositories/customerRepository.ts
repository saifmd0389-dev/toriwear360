export interface CustomerAddressRecord {
  id: string;
  customerId: string;
  fullName: string;
  phone: string;
  pincode: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  addressType: 'HOME' | 'WORK' | 'OTHER';
  isDefault: boolean;
}

export interface CustomerRecord {
  id: string;
  email?: string;
  phone?: string;
  name?: string;
  avatarUrl?: string;
  firebaseUid?: string;
  isGuest: boolean;
  status: 'ACTIVE' | 'SUSPENDED';
  toriCredit: number;
  insiderTier: string;
  insiderPoints: number;
  addresses: CustomerAddressRecord[];
  createdAt: Date;
  updatedAt: Date;
}

export class CustomerRepository {
  private customers = new Map<string, CustomerRecord>();

  async findById(id: string): Promise<CustomerRecord | null> {
    return this.customers.get(id) || null;
  }

  async findByFirebaseUid(uid: string): Promise<CustomerRecord | null> {
    for (const c of this.customers.values()) {
      if (c.firebaseUid === uid) return c;
    }
    return null;
  }

  async findByEmailOrPhone(identifier: string): Promise<CustomerRecord | null> {
    const clean = identifier.trim().toLowerCase();
    for (const c of this.customers.values()) {
      if (c.email?.toLowerCase() === clean || c.phone === clean) return c;
    }
    return null;
  }

  async save(customer: CustomerRecord): Promise<CustomerRecord> {
    this.customers.set(customer.id, customer);
    return customer;
  }

  async getAll(): Promise<CustomerRecord[]> {
    return Array.from(this.customers.values());
  }
}

export const customerRepository = new CustomerRepository();
