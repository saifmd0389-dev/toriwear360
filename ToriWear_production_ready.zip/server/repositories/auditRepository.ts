export interface AuditLogRecord {
  id: string;
  userId: string;
  userName: string;
  userRole: string;
  module: string;
  action: string;
  recordAffected: string;
  oldValue?: string;
  newValue?: string;
  ipAddress?: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  timestamp: Date;
}

export class AuditRepository {
  private logs: AuditLogRecord[] = [];

  async record(entry: Omit<AuditLogRecord, 'id' | 'timestamp'>): Promise<AuditLogRecord> {
    const item: AuditLogRecord = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date(),
      ipAddress: entry.ipAddress || '127.0.0.1',
      ...entry,
    };
    this.logs.unshift(item);
    if (this.logs.length > 2000) {
      this.logs.pop();
    }
    return item;
  }

  async getAll(filter?: { module?: string; severity?: string; limit?: number }): Promise<AuditLogRecord[]> {
    let result = this.logs;
    if (filter?.module && filter.module !== 'ALL') {
      result = result.filter((l) => l.module === filter.module);
    }
    if (filter?.severity && filter.severity !== 'ALL') {
      result = result.filter((l) => l.severity === filter.severity);
    }
    return result.slice(0, filter?.limit || 100);
  }
}

export const auditRepository = new AuditRepository();
