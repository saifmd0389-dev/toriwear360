import fs from 'fs';
import path from 'path';

const STORE_PATH = path.resolve(process.cwd(), 'public/generated-assets/payments-store.json');

export interface PaymentTransactionRecord {
  id: string;
  orderId: string;
  orderNumber: string;
  gateway: 'RAZORPAY' | 'CASHFREE' | 'STRIPE' | 'COD' | 'SIMULATED_SANDBOX';
  gatewayOrderId?: string;
  gatewayPaymentId?: string;
  amount: number;
  currency: string;
  status: 'INITIATED' | 'AUTHORIZED' | 'CAPTURED' | 'FAILED' | 'REFUNDED';
  method: 'UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'NET_BANKING' | 'WALLET' | 'COD';
  upiVpa?: string;
  bankRefNumber?: string;
  failureReason?: string;
  isSimulated: boolean;
  signatureVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentWebhookRecord {
  id: string;
  gateway: string;
  eventId: string;
  eventType: string;
  payload: any;
  processed: boolean;
  receivedAt: Date;
}

export class PaymentRepository {
  private transactions = new Map<string, PaymentTransactionRecord>();
  private webhooks: PaymentWebhookRecord[] = [];
  private initialized = false;

  constructor() {
    this.ensureLoaded();
  }

  private ensureLoaded() {
    if (this.initialized) return;
    try {
      if (fs.existsSync(STORE_PATH)) {
        const raw = fs.readFileSync(STORE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed) {
          if (Array.isArray(parsed.transactions)) {
            for (const tx of parsed.transactions) {
              this.transactions.set(tx.id, {
                ...tx,
                createdAt: new Date(tx.createdAt || Date.now()),
                updatedAt: new Date(tx.updatedAt || Date.now()),
              });
            }
          }
          if (Array.isArray(parsed.webhooks)) {
            this.webhooks = parsed.webhooks.map((w: any) => ({
              ...w,
              receivedAt: new Date(w.receivedAt || Date.now()),
            }));
          }
          this.initialized = true;
          return;
        }
      }
    } catch (err) {
      console.warn('[PaymentRepo] Could not load payments store file:', err);
    }
    this.initialized = true;
  }

  private saveToDisk() {
    try {
      const dir = path.dirname(STORE_PATH);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const data = {
        transactions: Array.from(this.transactions.values()),
        webhooks: this.webhooks.slice(-500),
        lastUpdated: new Date().toISOString(),
      };
      const tempPath = `${STORE_PATH}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempPath, STORE_PATH);
    } catch (err) {
      console.error('[PaymentRepo] Failed to persist payments to disk:', err);
    }
  }

  async createTransaction(record: PaymentTransactionRecord): Promise<PaymentTransactionRecord> {
    this.ensureLoaded();
    this.transactions.set(record.id, record);
    this.saveToDisk();
    return record;
  }

  async findByOrderId(orderId: string): Promise<PaymentTransactionRecord | null> {
    this.ensureLoaded();
    for (const tx of this.transactions.values()) {
      if (tx.orderId === orderId) return tx;
    }
    return null;
  }

  async findByGatewayOrderId(gatewayOrderId: string): Promise<PaymentTransactionRecord | null> {
    this.ensureLoaded();
    for (const tx of this.transactions.values()) {
      if (tx.gatewayOrderId === gatewayOrderId) return tx;
    }
    return null;
  }

  async findByGatewayPaymentId(gatewayPaymentId: string): Promise<PaymentTransactionRecord | null> {
    this.ensureLoaded();
    for (const tx of this.transactions.values()) {
      if (tx.gatewayPaymentId === gatewayPaymentId) return tx;
    }
    return null;
  }

  async updateTransaction(id: string, updates: Partial<PaymentTransactionRecord>): Promise<PaymentTransactionRecord | null> {
    this.ensureLoaded();
    const existing = this.transactions.get(id);
    if (!existing) return null;
    const merged = { ...existing, ...updates, updatedAt: new Date() };
    this.transactions.set(id, merged);
    this.saveToDisk();
    return merged;
  }

  async findWebhookByEventId(eventId: string): Promise<PaymentWebhookRecord | null> {
    this.ensureLoaded();
    const cleanId = eventId.trim();
    return this.webhooks.find((w) => w.eventId === cleanId) || null;
  }

  async logWebhook(webhook: PaymentWebhookRecord): Promise<{ alreadyProcessed: boolean }> {
    this.ensureLoaded();
    const existing = this.webhooks.find((w) => w.eventId === webhook.eventId);
    if (existing) {
      return { alreadyProcessed: true };
    }
    this.webhooks.push(webhook);
    this.saveToDisk();
    return { alreadyProcessed: false };
  }

  async getAllTransactions(): Promise<PaymentTransactionRecord[]> {
    this.ensureLoaded();
    return Array.from(this.transactions.values());
  }

  async getAllWebhooks(): Promise<PaymentWebhookRecord[]> {
    this.ensureLoaded();
    return [...this.webhooks];
  }
}

export const paymentRepository = new PaymentRepository();
